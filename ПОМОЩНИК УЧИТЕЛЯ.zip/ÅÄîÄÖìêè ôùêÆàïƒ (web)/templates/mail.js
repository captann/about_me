function sendcodejs() {
                  alert("Hello")};