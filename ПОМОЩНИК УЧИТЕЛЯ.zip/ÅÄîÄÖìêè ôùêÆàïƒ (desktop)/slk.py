import datetime
import sqlite3
import sys
import webbrowser
from tkinter import messagebox, Tk
import datetime as dt


from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QMainWindow, QCheckBox, QTableWidgetItem, \
    QHBoxLayout, QWidget, QApplication, QMessageBox

from interfaces import Newslk as Slkui
def expect_hook(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)

class Slk(QMainWindow, Slkui):
    def __init__(self, file, obj):
        super().__init__()
        self.setWindowIcon(QIcon('icons\icon.png'))
        self.obj = obj
        ##сортировка
        self.revers = False
        self.looklist = {}
        self.key_sorting = self.sort_by_date
        self.file = file
        self.flag = True
        self.CONST = 0
        self.setFixedSize(625, 360)
        self.setupUi(self)
        self.setWindowTitle('Ссылки')
        self.lineEdit.textChanged[str].connect(self.showresults)
        self.label.setStyleSheet("font: bold 11pt \"Arial\";")
        self.label_5.setStyleSheet("font: bold 11pt \"Arial\";")
        self.checkBox.clicked.connect(self.cbc)
        self.pushButton_3.clicked.connect(self.adslk)
        self.pushButton.clicked.connect(self.open_all)
        self.comboBox.currentTextChanged.connect(self.sorting)
        self.pushButton_2.clicked.connect(self.delete)
        self.days = {
        0: 'Пн',
        1: 'Вт',
        2: 'Ср',
        3: 'Чт',
        4: 'Пт',
        5: 'Сб',
        6: 'Вс'
        }
        self.months = {
            1: 'янв',
            2: 'фев',
            3: 'мар',
            4: 'апр',
            5: 'май',
            6: 'июн',
            7: 'июл',
            8: 'авг',
            9: 'сен',
            10: 'окт',
            11: 'ноя',
            12: 'дек'
        }

    def update_theme(self, children, name, color_theme, size):
        self.size = size
        if name == 'Windows':
            stl = ''
            for i in color_theme['Windows']:
                stl += i + ': ' + color_theme['Windows'][i]
            children.setStyleSheet(stl)
            return
        a = self.findChildren(children)
        for i in range(len(a)):
            b = a[i].styleSheet()
            b = [j.strip('\n') for j in b.split(';') if j.strip('\n')]
            d = {}
            for j in b:
                try:
                    if j.split(':')[0] not in d:
                        d[j.split(':')[0]] = j.split(':')[1]
                except Exception:
                    return

            d['background-color'] = color_theme[name]['background-color']
            d['color'] = color_theme[name]['color']
            styles = ''
            if self.obj.color.radioButton_7.isChecked():
                font = 'Arial'
            else:
                font = color_theme['Windows']['font'].split()[2:]
                font[0] = font[0][1:]
                font[-1] = font[-1][:-2]
                font = ' '.join(font)
            if 'font' in d:
                if 'bold' in d['font']:
                    d['font'] = (f'''bold {size[int((d['font'].split())[1][:-2])]}pt "{font}";''')
                else:
                    d['font'] = (
                        f'''bold {size[int((d['font'].split())[0][:-2])]}pt "{font}";''')
            for t in d:
                styles += (t + ':' + d[t] + ';' + '\n')
            a[i].setStyleSheet(styles)


        a = self.tableWidget.font()
        self.tableWidget.setStyleSheet(f"background-color: {self.obj.color.color_theme['Windows']['background-color']}color: {self.obj.color.color_theme['Tables']['color']}")
        self.tableWidget.setFont(a)

        a = self.checkBox.font()
        self.checkBox.setStyleSheet(f"background-color: {self.obj.color.color_theme['CheckBoxes']['background-color']}color: {self.obj.color.color_theme['CheckBoxes']['color']}")
        self.checkBox.setFont(a)
        a = self.lineEdit.font()
        self.lineEdit.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['LineEdits']['background-color']}color: {self.obj.color.color_theme['LineEdits']['color']}")
        self.lineEdit.setFont(a)

        a = self.lineEdit_2.font()
        self.lineEdit_2.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['LineEdits']['background-color']}color: {self.obj.color.color_theme['LineEdits']['color']}")
        self.lineEdit_2.setFont(a)
        a = self.comboBox.font()
        self.comboBox.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Windows']['background-color']}color: {self.obj.color.color_theme['LineEdits']['color']}")
        self.comboBox.setFont(a)
        a = self.lineEdit_3.font()
        self.lineEdit_3.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['LineEdits']['background-color']}color: {self.obj.color.color_theme['LineEdits']['color']}")
        self.lineEdit_3.setFont(a)
    def get_datas(self):
        ## работа с БД
        if self.file == 'None.sqlite3':
            return
        self.con = sqlite3.connect(self.file)
        cur = self.con.cursor()
        vals = [list(item) for item in
                cur.execute("""SELECT * FROM slk""").fetchall()]
        self.con.close()
        ## конец работы с БД
        self.CONST = len(vals)
        for i in range(len(vals)):
            vals[i][1], vals[i][2] = vals[i][2], vals[i][1]
        vals = self.key_sorting(vals)
        self.looklist = {}
        self.tableWidget.setRowCount(self.CONST)
        if not len(vals):
            self.checkBox.setChecked(False)
            return
        for i in range(len(vals)):
            if ''.join(vals[i]).lower() not in self.looklist:
                self.looklist[''.join(vals[i]).lower()] = []
                self.looklist[''.join(vals[i]).lower()].append(vals[i])
            else:
                self.looklist[''.join(vals[i]).lower()].append(vals[i])
            for j in range(3):
                locals().update({f'c_b{i + 1}': QCheckBox(self)})
                locals().get(f'c_b{i + 1}').setChecked(
                    self.checkBox.isChecked())
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                cell_widget = QWidget()
                lay_out = QHBoxLayout(cell_widget)
                lay_out.addWidget(locals().get(f'c_b{i + 1}'))
                lay_out.setAlignment(Qt.AlignCenter)
                lay_out.setContentsMargins(0, 0, 0, 0)
                cell_widget.setLayout(lay_out)
                cell_widget.installEventFilter(self)
                self.tableWidget.setCellWidget(i, 0, cell_widget)
                self.tableWidget.setItem(i, j + 1,
                                         QTableWidgetItem(vals[i][j]))

    def adslk(self):
        dayw = str(self.days[dt.date.today().weekday()])
        month = str(self.months[dt.date.today().month])
        day = str(dt.date.today().day)
        year = str(dt.date.today().year)
        date = f'{dayw} {month} {day} {year}'
        name, slk = self.lineEdit_3.text().strip(), self.lineEdit_2.text().strip()
        time = dt.datetime.today().strftime('%H:%M')
        date = date + '\n' + time
        if not name and not slk:
            self.lineEdit_3.setText('')
            self.lineEdit_2.setText('')
            QMessageBox.critical(self, 'Ссылки', 'Введите название ссылки и саму ссылку')
            return
        if not name:
            self.lineEdit_3.setText('')
            QMessageBox.critical(self, 'Ссылки', 'Введите название ссылки')
            return
        if not slk:
            self.lineEdit_2.setText('')
            QMessageBox.critical(self, 'Ссылки', 'Введите ссылку')
            return
        ## работа с БД
        self.con = sqlite3.connect(self.file)
        cur = self.con.cursor()
        cur.execute(
                """INSERT INTO slk VALUES('{}', '{}', '{}')""".format(
                    name, slk, date))
        self.con.commit()
        vals = [list(item) for item in
                    cur.execute("""SELECT * FROM slk""").fetchall()]
        self.con.close()
        ## конец работы с БД
        self.looklist = {}
        self.tableWidget.setRowCount(len(vals))
        for i in range(len(vals)):
            if ''.join(vals[i]).lower() not in self.looklist:
                self.looklist[''.join(vals[i]).lower()] = []
                self.looklist[''.join(vals[i]).lower()].append(vals[i])
            else:
                self.looklist[''.join(vals[i]).lower()].append(vals[i])
        if vals:
            if '\n' not in vals[0][1]:
                for i in range(len(vals)):
                    vals[i][1], vals[i][2] = vals[i][2], vals[i][1]
        vals = self.key_sorting(vals)
        for i in range(len(vals)):
            for j in range(3):
                locals().update({f'c_b{i + 1}': QCheckBox(self)})
                locals().get(f'c_b{i + 1}').setChecked(
                    self.checkBox.isChecked())
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                cell_widget = QWidget()
                lay_out = QHBoxLayout(cell_widget)
                lay_out.addWidget(locals().get(f'c_b{i + 1}'))
                lay_out.setAlignment(Qt.AlignCenter)
                lay_out.setContentsMargins(0, 0, 0, 0)
                cell_widget.setLayout(lay_out)
                cell_widget.installEventFilter(self)
                self.tableWidget.setCellWidget(i, 0, cell_widget)
                self.tableWidget.setItem(i, j + 1,
                                         QTableWidgetItem(vals[i][j]))
            if ''.join(vals[i]).lower() not in self.looklist:
                self.looklist[''.join(vals[i]).lower()] = []
                self.looklist[''.join(vals[i]).lower()].append(vals[i])
            else:
                self.looklist[''.join(vals[i]).lower()].append(vals[i])
        self.lineEdit_3.setText('')
        self.lineEdit_2.setText('')

    def eventFilter(self, obj, e):  ## обработка чекбоксов
        if e.type() == 2:
            obj.children()[1].setChecked(not obj.children()[1].isChecked())
            self.cbc_update()
        return super(Slk, self).eventFilter(obj, e)

    def cbc(self):  ## обработка чекбоксов
        checkboxes = self.tableWidget.findChildren(QCheckBox)
        if not(len(checkboxes)):
            self.checkBox.setChecked(False)
            return
        if self.checkBox.isChecked():
            for i in checkboxes:
                i.setChecked(True)
            return
        else:
            for i in checkboxes:
                i.setChecked(False)
            return

    def cbc_update(self):  ## обработка чекбоксов
        checkboxes = self.tableWidget.findChildren(QCheckBox)
        if all([i.isChecked() for i in checkboxes]):
            self.checkBox.setChecked(True)
            return
        else:
            self.checkBox.setChecked(False)
            return

    def sorting(self):
        if self.comboBox.currentText() == 'дате и времени':
            self.key_sorting = self.sort_by_date
            self.revers = True
        elif self.comboBox.currentText() == 'дате и времени (R)':
            self.key_sorting = self.sort_by_date
            self.revers = False
        elif self.comboBox.currentText() == 'названию':
            self.key_sorting = self.sort_by_theme
            self.revers = False
        elif self.comboBox.currentText() == 'названию (R)':
            self.key_sorting = self.sort_by_theme
            self.revers = True
        self.get_datas()

    def sort_by_date(self, lst, revers=False):
        revers = self.revers
        diction = {'янв': '01',
                   'фев': '02',
                   'мар': '03',
                   'апр': '04',
                   'май': '05',
                   'июн': '06',
                   'июл': '07',
                   'авг': '08',
                   'сен': '09',
                   'окт': '10',
                   'ноя': '11',
                   'дек': '12'}
        results = {}
        for i in range(len(lst)):
            a = lst[i][1].split('\n')[0]
            b = lst[i][1].split('\n')[1]
            d_f = ('%d.%m.%Y %H:%M')
            time1 = datetime.datetime.today().strftime(d_f)
            time2 = a.split()[2] + '.' + diction[a.split()[1]] + '.' + \
                    a.split()[3] + ' ' + b
            result = datetime.datetime.strptime(time2,
                                                d_f) - datetime.datetime.strptime(
                time1, d_f)
            result = int(result.total_seconds())
            if result not in results:
                results[result] = []
                results[result].append(lst[i])
            else:
                results[result].append(lst[i])
        for i in results:
            results[i] = list(sorted(results[i], key=lambda x: x[2]))
        a = [i for i in results]
        a.sort(reverse=revers)
        sortes_vals = []
        for i in a:
            for j in results[i]:
                sortes_vals.append(j)
        return sortes_vals


    def sort_by_theme(self, lst, revers=False):
        revers = self.revers
        for i in self.looklist:
            self.looklist[i] = sorted(self.looklist[i], key=lambda x: x[0])
        titles = sorted([i for i in self.looklist], reverse=revers)
        vals = []
        for i in titles:
            for j in self.sort_by_date(self.looklist[i]):
                vals.append(j)

        return vals

    def sortt(self, times, values):
        sort_vals = []
        while times:
            a = min(times)
            b = times.index(a)
            sort_vals.append(values[b])
            del times[b]
            del values[b]
        return sort_vals


    def time_return(self, lst):
        diction = {'янв': '01',
                   'фев': '02',
                   'мар': '03',
                   'апр': '04',
                   'май': '05',
                   'июн': '06',
                   'июл': '07',
                   'авг': '08',
                   'сен': '09',
                   'окт': '10',
                   'ноя': '11',
                   'дек': '12'}
        a = lst[2].split('\n')[0]
        b = lst[2].split('\n')[1]
        d_f = ('%d.%m.%Y %H:%M')
        time1 = datetime.datetime.today().strftime(d_f)
        time2 = a.split()[2] + '.' + diction[a.split()[1]] + '.' + \
                a.split()[3] + ' ' + b
        result = datetime.datetime.strptime(time2,
                                            d_f) - datetime.datetime.strptime(
            time1, d_f)
        result = int(result.total_seconds())
        return result

    def showresults(self):
        a = [self.looklist[i] for i in list(
            filter(lambda x: self.lineEdit.text().lower() in x,
                   [i for i in self.looklist]))]
        vals = []
        for i in a:
            for j in i:
                vals.append(j)
        vals = self.key_sorting(vals)
        self.tableWidget.setRowCount(len(vals))
        for i in range(len(vals)):
            for j in range(3):
                locals().update({f'c_b{i + 1}': QCheckBox(self)})
                locals().get(f'c_b{i + 1}').setChecked(
                    self.checkBox.isChecked())
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                cell_widget = QWidget()
                lay_out = QHBoxLayout(cell_widget)
                lay_out.addWidget(locals().get(f'c_b{i + 1}'))
                lay_out.setAlignment(Qt.AlignCenter)
                lay_out.setContentsMargins(0, 0, 0, 0)
                cell_widget.setLayout(lay_out)
                cell_widget.installEventFilter(self)
                self.tableWidget.setCellWidget(i, 0, cell_widget)
                self.tableWidget.setItem(i, j + 1,
                                         QTableWidgetItem(vals[i][j]))

    def open_all(self):
        checkboxes = self.tableWidget.findChildren(QCheckBox)
        for i in range(len(checkboxes)):
            if checkboxes[i].isChecked():
                webbrowser.open(self.tableWidget.item(i, 3).text(), new=0,
                                autoraise=True)

    def delete(self):
        checkboxes = self.tableWidget.findChildren(QCheckBox)
        count = 0
        rc = []
        for i in range(len(checkboxes)):

            if checkboxes[i].isChecked():
                rc.append(i)
                count += 1
        if count == 0:
            return
        msg = QMessageBox(self)
        msg.setWindowTitle('Ссылки')
        msg.setText(
            f'Вы действтельно хотите удалить выбранные ссылки?')

        play = msg.addButton(
            'Да', QMessageBox.AcceptRole)
        change = msg.addButton(
            'Нет', QMessageBox.AcceptRole)
        msg.setDefaultButton(play)
        msg.setIcon(QMessageBox.Question)
        msg.exec_()
        msg.deleteLater()
        if msg.clickedButton() is play:
            for i in rc:
                ps = []
                for j in range(3):
                    ps.append(self.tableWidget.item(i, j + 1).text())
                ## работа с БД
                self.con = sqlite3.connect(self.file)
                cur = self.con.cursor()
                cur.execute("""DELETE FROM slk WHERE tema = '{}' AND text = '{}' AND 
                    time = '{}'""".format(ps[0], ps[2], ps[1]))
                self.con.commit()
                self.con.close()
                # конец работы с БД
                if (ps[0] + ps[1] + ps[2]).lower() in self.looklist:
                    del self.looklist[(ps[0] + ps[1] + ps[2]).lower()]
            self.lineEdit.setText('')
            self.get_datas()
        return

if __name__ == '__main__':
    sys.excepthook = expect_hook
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    work_class = Slk('nick.sqlite3')
    work_class.show()
    work_class.get_datas()
    sys.exit(app.exec())