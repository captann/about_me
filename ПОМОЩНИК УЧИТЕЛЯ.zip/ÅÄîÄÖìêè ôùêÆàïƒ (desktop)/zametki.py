import sqlite3

from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QCheckBox, QTableWidgetItem, QWidget, QHBoxLayout, \
    QMainWindow, QApplication, QMessageBox
from tkinter import *
import sys
from PyQt5.QtCore import QTimer, QTime, Qt
import datetime

from interfaces import Nzui as ZMui


def expect_hook(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)

class ZM(QMainWindow, ZMui):
    def __init__(self, file, obj):
        super().__init__()
        self.setWindowIcon(QIcon('icons\icon.png'))
        self.looklist = {}
        self.file = file
        self.obj = obj
        self.setFixedSize(560, 400)
        self.setupUi(self)
        self.sw = []
        self.setWindowTitle('Заметки')
        self.checkBox.clicked.connect(self.cbc)
        self.lineEdit_2.textChanged[str].connect(self.showresults)
        self.pushButton_2.clicked.connect(self.adz)
        self.pushButton.clicked.connect(self.delete)
        self.pushButton_3.clicked.connect(self.shotext)
        self.comboBox.currentTextChanged.connect(self.get_dates)

    def update_theme(self, children, name, color_theme, size):
        self.size = size
        if name == 'Windows':
            stl = ''
            for i in color_theme['Windows']:
                stl += i + ': ' + color_theme['Windows'][i]
            children.setStyleSheet(stl)
            return
        a = self.findChildren(children)
        for i in range(len(a)):
            b = a[i].styleSheet()
            b = [j.strip('\n') for j in b.split(';') if j.strip('\n')]
            d = {}
            for j in b:
                try:
                    if j.split(':')[0] not in d:
                        d[j.split(':')[0]] = j.split(':')[1]
                except Exception:
                    return

            d['background-color'] = color_theme[name]['background-color']
            d['color'] = color_theme[name]['color']
            styles = ''
            if self.obj.color.radioButton_7.isChecked():
                font = 'Arial'
            else:
                font = color_theme['Windows']['font'].split()[2:]
                font[0] = font[0][1:]
                font[-1] = font[-1][:-2]
                font = ' '.join(font)
            if 'font' in d:
                if 'bold' in d['font']:
                    d['font'] = (f'''bold {size[int((d['font'].split())[1][:-2])]}pt "{font}";''')
                else:
                    d['font'] = (
                        f'''bold {size[int((d['font'].split())[0][:-2])]}pt "{font}";''')
            for t in d:
                styles += (t + ':' + d[t] + ';' + '\n')
            a[i].setStyleSheet(styles)


        a = self.tableWidget.font()
        self.tableWidget.setStyleSheet(f"background-color: {self.obj.color.color_theme['Windows']['background-color']}color: {self.obj.color.color_theme['Tables']['color']}")
        self.tableWidget.setFont(a)

        a = self.checkBox.font()
        self.checkBox.setStyleSheet(f"background-color: {self.obj.color.color_theme['CheckBoxes']['background-color']}color: {self.obj.color.color_theme['CheckBoxes']['color']}")
        self.checkBox.setFont(a)
        a = self.lineEdit.font()
        self.lineEdit.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['LineEdits']['background-color']}color: {self.obj.color.color_theme['LineEdits']['color']}")
        self.lineEdit.setFont(a)

        a = self.lineEdit_2.font()
        self.lineEdit_2.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['LineEdits']['background-color']}color: {self.obj.color.color_theme['LineEdits']['color']}")
        self.lineEdit_2.setFont(a)
        a = self.comboBox.font()
        self.comboBox.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Windows']['background-color']}color: {self.obj.color.color_theme['LineEdits']['color']}")
        self.comboBox.setFont(a)
        a = (self.plainTextEdit.font())
        self.plainTextEdit.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Windows']['background-color']}color: {self.obj.color.color_theme['PlainTextEdits']['color']}")
        self.plainTextEdit.setFont(a)


    def cbc(self):  ## обработка чекбоксов
        checkboxes = self.tableWidget.findChildren(QCheckBox)
        if not(len(checkboxes)):
            self.checkBox.setChecked(False)
            return
        if self.checkBox.isChecked():
            for i in checkboxes:
                i.setChecked(True)
            return
        else:
            for i in checkboxes:
                i.setChecked(False)
            return

    def cbc_update(self):  ## обработка чекбоксов
        checkboxes = self.tableWidget.findChildren(QCheckBox)
        if all([i.isChecked() for i in checkboxes]):
            self.checkBox.setChecked(True)
            return
        else:
            self.checkBox.setChecked(False)
            return

    def showresults(self):
        a = [self.looklist[i] for i in list(
            filter(lambda x: self.lineEdit_2.text().lower() in x,
                   [i for i in self.looklist]))]
        vals = []
        for i in a:
            for j in i:
                vals.append(j)
        vals = self.h_s(vals)
        self.tableWidget.setRowCount(len(vals))
        for i in range(len(vals)):
            for j in range(2):
                locals().update({f'c_b{i + 1}': QCheckBox(self)})
                locals().get(f'c_b{i + 1}').setChecked(
                    self.checkBox.isChecked())
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                cell_widget = QWidget()
                lay_out = QHBoxLayout(cell_widget)
                lay_out.addWidget(locals().get(f'c_b{i + 1}'))
                lay_out.setAlignment(Qt.AlignCenter)
                lay_out.setContentsMargins(0, 0, 0, 0)
                cell_widget.setLayout(lay_out)
                cell_widget.installEventFilter(self)
                self.tableWidget.setCellWidget(i, 0, cell_widget)
                self.tableWidget.setItem(i, j + 1,
                                         QTableWidgetItem(vals[i][j]))

    def delete(self):
        checkboxes = self.tableWidget.findChildren(QCheckBox)
        count = 0
        rc = []
        for i in range(len(checkboxes)):

            if checkboxes[i].isChecked():
                rc.append(i)
                count += 1
        if count == 0:
            return
        msg = QMessageBox(self)
        msg.setWindowTitle('Заметки')
        msg.setText(
            f'Вы действтельно хотите удалить выбранные заметки?')

        play = msg.addButton(
            'Да', QMessageBox.AcceptRole)
        change = msg.addButton(
            'Нет', QMessageBox.AcceptRole)
        msg.setDefaultButton(play)
        msg.setIcon(QMessageBox.Question)
        msg.exec_()
        msg.deleteLater()
        if msg.clickedButton() is play:
            for i in rc:
                ps = []
                for j in range(2):
                    ps.append(self.tableWidget.item(i, j + 1).text())
                ## работа с БД
                self.con = sqlite3.connect(self.file)
                cur = self.con.cursor()
                cur.execute("""DELETE FROM zametki WHERE name = '{}' AND text = '{}' """.format(ps[0], ps[1]))
                self.con.commit()
                self.con.close()
                # конец работы с БД
                if (ps[0] + ps[1]).lower() in self.looklist:
                    del self.looklist[(ps[0] + ps[1]).lower()]
            self.lineEdit.setText('')
            checkboxes = self.tableWidget.findChildren(QCheckBox)
            self.get_dates()
        return

    def adz(self):
        tema = self.lineEdit.text().strip()
        text = self.plainTextEdit.toPlainText().strip()
        if not tema and not text:
            QMessageBox.critical(self, 'Заметки', 'Введите тему и текст заметки')
            return
        if not tema:
            QMessageBox.critical(self, 'Заметки', 'Введите тему заметки')
            return
        if not text:
            QMessageBox.critical(self, 'Заметки', 'Введите текст заметки')
            return
        ## работа с БД
        self.con = sqlite3.connect(self.file)
        cur = self.con.cursor()
        cur.execute(
                """INSERT INTO zametki VALUES('{}', '{}')""".format(
                    tema, text))
        self.con.commit()
        vals = [list(item) for item in
                    cur.execute("""SELECT * FROM zametki""").fetchall()]
        self.con.close()
            ## конец работы с БД
        self.looklist = {}
        self.tableWidget.setRowCount(len(vals))
        for i in range(len(vals)):
            if ''.join(vals[i]).lower() not in self.looklist:
                self.looklist[''.join(vals[i]).lower()] = []
                self.looklist[''.join(vals[i]).lower()].append(vals[i])
            else:
                self.looklist[''.join(vals[i]).lower()].append(vals[i])
        vals = self.sorting(vals)
        for i in range(len(vals)):
            for j in range(2):
                locals().update({f'c_b{i + 1}': QCheckBox(self)})
                locals().get(f'c_b{i + 1}').setChecked(
                    self.checkBox.isChecked())
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                cell_widget = QWidget()
                lay_out = QHBoxLayout(cell_widget)
                lay_out.addWidget(locals().get(f'c_b{i + 1}'))
                lay_out.setAlignment(Qt.AlignCenter)
                lay_out.setContentsMargins(0, 0, 0, 0)
                cell_widget.setLayout(lay_out)
                cell_widget.installEventFilter(self)
                self.tableWidget.setCellWidget(i, 0, cell_widget)
                self.tableWidget.setItem(i, j + 1,
                                         QTableWidgetItem(vals[i][j]))
            if ''.join(vals[i]).lower() not in self.looklist:
                self.looklist[''.join(vals[i]).lower()] = []
                self.looklist[''.join(vals[i]).lower()].append(vals[i])
            else:
                self.looklist[''.join(vals[i]).lower()].append(vals[i])
        self.lineEdit.setText('')
        self.plainTextEdit.setPlainText('')

    def get_dates(self):
        if self.file == 'None.sqlite3':
            return
        ## работа с БД

        self.con = sqlite3.connect(self.file)
        cur = self.con.cursor()
        vals = [list(item) for item in
                cur.execute("""SELECT * FROM zametki""").fetchall()]
        self.con.close()
        ## конец работы с БД
        self.looklist = {}
        self.tableWidget.setRowCount(len(vals))
        for i in range(len(vals)):
            if ''.join(vals[i]).lower() not in self.looklist:
                self.looklist[''.join(vals[i]).lower()] = []
                self.looklist[''.join(vals[i]).lower()].append(vals[i])
            else:
                self.looklist[''.join(vals[i]).lower()].append(vals[i])
        vals = self.sorting(vals)
        if not len(vals):
            self.checkBox.setChecked(False)
            return
        for i in range(len(vals)):
            for j in range(2):
                locals().update({f'c_b{i + 1}': QCheckBox(self)})
                locals().get(f'c_b{i + 1}').setChecked(
                    self.checkBox.isChecked())
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                cell_widget = QWidget()
                lay_out = QHBoxLayout(cell_widget)
                lay_out.addWidget(locals().get(f'c_b{i + 1}'))
                lay_out.setAlignment(Qt.AlignCenter)
                lay_out.setContentsMargins(0, 0, 0, 0)
                cell_widget.setLayout(lay_out)
                cell_widget.installEventFilter(self)
                self.tableWidget.setCellWidget(i, 0, cell_widget)
                self.tableWidget.setItem(i, j + 1,
                                         QTableWidgetItem(vals[i][j]))

        self.lineEdit.setText('')
        self.plainTextEdit.setPlainText('')


    def eventFilter(self, obj, e):  ## обработка чекбоксов
        if e.type() == 2:
            obj.children()[1].setChecked(not obj.children()[1].isChecked())
            self.cbc_update()
        return super(ZM, self).eventFilter(obj, e)

    def sorting(self, lst):
        for i in self.looklist:
            self.looklist[i] = sorted(self.looklist[i], key=lambda x: x[0])
        titles = sorted([i for i in self.looklist], reverse='R' in self.comboBox.currentText())
        vals = []
        for i in titles:
            for j in self.looklist[i]:
                vals.append(j)
        return vals

    def h_s(self, lst):
        return sorted(lst, key=lambda x: x[0], reverse='R' in self.comboBox.currentText())

    def shotext(self):
        checkboxes = self.tableWidget.findChildren(QCheckBox)
        for i in range(len(checkboxes)):
            self.setDisabled(True)
            if checkboxes[i].isChecked():
                name, text = self.tableWidget.item(i, 1).text(), self.tableWidget.item(i, 2).text()
                root = Tk()
                root.geometry('600x400')
                root.title(name)
                sx, sy = Scrollbar(root, orient=HORIZONTAL), Scrollbar(
                    root)
                sx.pack(side=BOTTOM, fill=X)
                sy.pack(side=RIGHT, fill=Y)
                textw= Text(root,
                                 width=600,
                                 height=400,
                                 bg='white', fg='#5151ff',
                                 font=f'Arial 14',
                                 yscrollcommand=sy.set, xscrollcommand=sx.set,
                                 wrap=NONE)
                textw.insert(1.0, text.strip('\n'))
                textw.pack()
                self.sw.append(root)
                root.mainloop()

        self.setDisabled(False)

    def closeEvent(self, event):
        if self.sw:
            self.sw[-1].destroy()
        self.setDisabled(False)
        self.destroy()


if __name__ == '__main__':
    sys.excepthook = expect_hook
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    work_class = ZM('nick.sqlite3')
    work_class.get_dates()
    work_class.show()
    #work_class.get_dates()
    sys.exit(app.exec())