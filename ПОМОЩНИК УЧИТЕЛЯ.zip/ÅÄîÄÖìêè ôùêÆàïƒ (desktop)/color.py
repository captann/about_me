import sqlite3
import sys

from PyQt5.QtGui import QFont, QIcon
from PyQt5.QtWidgets import QApplication, QMainWindow, QButtonGroup, \
    QRadioButton, QLabel, QFontDialog, QPushButton, QColorDialog, QTableWidget, \
    QCheckBox, QLineEdit, QPlainTextEdit, QMessageBox
from interfaces import ColorClass
from interfaces import W2
from test1 import Test
from PyQt5.QtCore import QSize, Qt, QBasicTimer


def expect_hook(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)


class Colors(QMainWindow, ColorClass):
    def __init__(self, file, object):
        super().__init__()
        self.object = object
        self.setupUi(self)
        self.setWindowIcon(QIcon('icons\icon.png'))
        self.setFixedSize(410, 150)
        self.setWindowTitle('Вид приложения')
        self.work_dict = None
        self.file = file
        self.n = []
        self.big = {1: 1, 2: 3, 3: 4, 4: 5, 5: 6, 6: 7, 7: 8, 8: 9, 9: 10,
                    10: 11, 11: 12, 12: 13, 13: 14, 14: 15, 15: 16, 16: 17,
                    17: 18, 18: 19, 19: 20, 20: 20}
        self.small = {1: 1, 2: 1, 3: 2, 4: 3, 5: 4, 6: 5, 7: 6, 8: 7, 9: 8,
                      10: 9, 11: 10, 12: 11, 13: 12, 14: 13, 15: 14, 16: 15,
                      17: 16, 18: 17, 19: 18, 20: 20}
        self.norm = {1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9,
                     10: 10,
                     11: 11, 12: 12, 13: 13, 14: 14, 15: 15, 16: 16, 17: 17,
                     18: 18,
                     19: 19, 20: 20}
        self.size_dict = {-1: self.small, 0: self.norm, 1: self.big}
        self.color_theme = {
            'Windows': {"background-color": "rgb(224, 235, 250);",
                        "border-color": "rgb(18, 18, 18);",
                        "color": "rgb(81, 81, 255);",
                        "font": "bold 10pt \"Arial\";\n"},
            'RadioButtons': {'background-color': 'rgb(224, 235, 250);',
                             'color': 'rgb(81, 81, 255);'},
            'Labels': {'background-color': 'rgb(224, 235, 250);',
                       'color': 'rgb(81, 81, 255);'},
            'Buttons': {'background-color': 'rgb(234, 234, 234);',
                        'color': 'rgb(81, 81, 255);',
                        },
            'Tables': {'background-color': 'rgb(224, 235, 250);',
                       'color': 'rgb(81, 81, 255);'},
            'CheckBoxes': {'background-color': 'rgb(224, 235, 250);',
                           'color': 'rgb(81, 81, 255);'},
            'LineEdits': {'background-color': 'rgb(255, 255, 255);',
                          'color': 'rgb(81, 81, 255);'},
            'PlainTextEdits': {'background-color': 'rgb(255, 255, 255);',
                               'color': 'rgb(81, 81, 255);'},

        }
        self.sw = W22(self.color_theme, self)
        self.name = [(QRadioButton, 'RadioButtons'), (QLabel, 'Labels'),
                     (self, 'Windows'), (QTableWidget, 'Tables'),
                     (QCheckBox, "CheckBoxes"),
                     (QPushButton, 'Buttons'), (QLineEdit, 'LineEdits'),
                     (QPlainTextEdit, 'PlainTextEdits'), (self.sw, 'Windows'),
                     (self.sw.ex, 'Windows'), (self.object, 'Windows'), (self.object.exp, 'Windows'),
                     (self.object.account_worker, 'Windows'), (self.object.su, 'Windows'), (self.object.napominania, 'Windows'), (self.object.slk, 'Windows'), (self.object.zametki, 'Windows'),
                     (self.object.ap, 'Windows'), (self.object.back, 'Windows'),(self.object.b, 'Windows'), (self.object.su.docx, 'Windows')] #(self.object.su.docx.shabloni, 'Windows')
        ## 1 группа
        fg = QButtonGroup(self.centralwidget)
        fg.addButton(self.radioButton)
        fg.addButton(self.radioButton_2)
        fg.addButton(self.radioButton_3)
        fg.addButton(self.radioButton_4)
        ## 2 группа
        fg2 = QButtonGroup(self.centralwidget)
        fg2.addButton(self.radioButton_5)
        fg2.addButton(self.radioButton_6)
        fg2.addButton(self.radioButton_9)

        ## 3 группа
        fg3 = QButtonGroup(self.centralwidget)
        fg3.addButton(self.radioButton_8)
        fg3.addButton(self.radioButton_7)
        self.radioButton_5.clicked.connect(self.what)
        self.radioButton_6.clicked.connect(self.what)
        self.radioButton_9.clicked.connect(self.what)
        self.radioButton_2.clicked.connect(self.black_theme)
        self.radioButton.clicked.connect(self.white_theme)
        self.radioButton_3.clicked.connect(self.high_contrast)
        self.radioButton_8.clicked.connect(self.get_font)
        self.radioButton_4.clicked.connect(self.own_thene)
        self.radioButton_7.clicked.connect(self.arial)

    def own_thene(self):
        self.sw.show()



    def change_theme_database(self):
        font = self.color_theme['Windows']['font'].split()[2:]
        font[0] = font[0][1:]
        font[-1] = font[-1][:-2]
        font = ' '.join(font)
        background = self.color_theme['Windows']['background-color']
        button_color = self.color_theme['Buttons']['background-color']
        text = self.color_theme['Windows']['color']
        self.con = sqlite3.connect(self.file)
        cur = self.con.cursor()
        cur.execute(f"""UPDATE settings
        SET font = '{font}'""")
        self.con.commit()
        cur.execute(f"""UPDATE settings
                        SET k= '{self.k}'""")
        self.con.commit()

        cur.execute(f"""UPDATE settings
                SET buttoncolor= '{button_color}'""")
        self.con.commit()

        cur.execute(f"""UPDATE settings
                        SET backcolor= '{background}'""")
        # textcolor
        self.con.commit()
        cur.execute(f"""UPDATE settings
                                SET textcolor= '{text}'""")
        self.con.commit()
        self.con.close()
        self.get_dates()


    def arial(self):
        self.radioButton_7.setDisabled(True)
        new_theme = ' '.join(
            self.color_theme['Windows']['font'].split()[:2]) + ' ' + '"' + str(
            'Arial') + '"' + ';'
        self.color_theme['Windows']['font'] = new_theme
        self.radioButton_6.click()
        QMessageBox.information(self, 'Изменение шрифта',
                                'Для сохранения изменений будет произведён выход из аккаунта')
        self.close()
        self.sw.close()
        self.sw.ex.close()
        self.object.go_out()

    def get_font(self):
        self.radioButton_7.setDisabled(False)
        a, ok = QFontDialog.getFont()
        if ok:
            new_type = QFont.family(a)
            # \"Arial\";"
            new_theme = ' '.join(self.color_theme['Windows']['font'].split()[
                                 :2]) + ' ' + '"' + str(new_type) + '"' + ';'
            self.color_theme['Windows']['font'] = new_theme
            QMessageBox.information(self, 'Изменение шрифта',
                                    'Для сохранения изменений будет произведён выход из аккаунта')
            self.setDisabled(True)
            self.sw.setDisabled(True)
            self.sw.ex.setDisabled(True)
            self.change_theme_database()
            self.radioButton_9.click()
            self.close()
            self.sw.close()
            self.sw.ex.close()
            self.object.go_out()
            #self.work_dict = self.norm
            #self.change_theme_database()

    def what(self):
        self.object.hide()
        s = self.sender()
        self.radioButton_9.setDisabled(True)
        self.radioButton_5.setDisabled(True)
        self.radioButton_6.setDisabled(True)
        if s == self.radioButton_9:

            self.k = -1
            if abs(self.n[-1] - self.k) == 2:
                self.work_dict = self.size_dict[self.n[-1] * -1]
                for i in self.name * 2:
                    self.update_theme(i[0], i[1])
                self.change_theme_database()
            if self.k == self.n[-1]:
                self.work_dict = self.norm
                self.n.append(self.k)
                for i in self.name:
                    self.update_theme(i[0], i[1])
                self.change_theme_database()
            else:
                self.n.append(self.k)
                self.work_dict = self.size_dict[self.n[-1]]
                for i in self.name:
                    self.update_theme(i[0], i[1])
                self.change_theme_database()
        elif s == self.radioButton_5:
            self.k = 0
            self.work_dict = self.size_dict[self.n[-1] * -1]
            for i in self.name * 2:
                self.update_theme(i[0], i[1])
            self.change_theme_database()
            self.n.append(self.k)
            self.work_dict = self.size_dict[self.n[-1]]
            for i in self.name:
                self.update_theme(i[0], i[1])
            self.change_theme_database()
        elif s == self.radioButton_6:
            self.k = 1
            if abs(self.n[-1] - self.k) == 2:
                self.work_dict = self.size_dict[self.n[-1] * -1]
                for i in self.name * 2:
                    self.update_theme(i[0], i[1])
                self.change_theme_database()
            if self.k == self.n[-1]:
                self.work_dict = self.norm
                self.n.append(self.k)
                for i in self.name:
                    self.update_theme(i[0], i[1])
                self.change_theme_database()
            else:
                self.n.append(self.k)
                self.work_dict = self.size_dict[self.n[-1]]
                for i in self.name:
                    self.update_theme(i[0], i[1])
                self.change_theme_database()
        self.n = [self.n[-1]]
        self.radioButton_9.setDisabled(False)
        self.radioButton_5.setDisabled(False)
        self.radioButton_6.setDisabled(False)
        self.sender().setDisabled(True)
        QMessageBox.information(self, 'Изменение шрифта',
                                'Для сохранения изменений будет произведён выход из аккаунта')
        self.object.go_out()




    def change_font(self):

        pass

    def black_theme(self):
        self.radioButton_2.setDisabled(True)
        self.radioButton.setDisabled(False)
        self.radioButton_3.setDisabled(False)
        self.color_theme = {
            'Windows': {"background-color": "rgb(0, 10, 120);",
                        "border-color": "rgb(18, 18, 18);",
                        "color": "rgb(187, 187, 187);",
                        "font": "bold 10pt \"Arial\";\n"},
            'RadioButtons': {'background-color': 'rgb(0, 10, 120);',
                             'color': 'rgb(187, 187, 187);'},
            'Labels': {'background-color': 'rgb(0, 10, 120);',
                       'color': 'rgb(187, 187, 187);'},
            'Tables': {'background-color': 'rgb(0, 10, 120);',
                       'color': 'rgb(187, 187, 187);'},
            'Buttons': {'background-color': 'rgb(0, 10, 120);',
                        'color': 'rgb(187, 187, 187);'},
            'CheckBoxes': {'background-color': 'rgb(0, 10, 120);',
                           'color': 'rgb(187, 187, 187);'},
            'LineEdits': {'background-color': 'rgb(255, 255, 255);',
                          'color': 'rgb(0, 10, 120);'},
            'PlainTextEdits': {'background-color': 'rgb(0, 10, 120);',
                               'color': 'rgb(0, 10, 120);'},

        }
        # self.setStyleSheet(''.join([self.color_theme['Windows'][i] for i in self.color_theme['Windows']]))
        # self.change_theme_database()
        # return
        QMessageBox.information(self, 'Изменение темы',
                                'Для сохранения изменений будет произведён выход из аккаунта')
        for i in self.name:
            self.update_theme(i[0], i[1])
        self.change_theme_database()
        self.object.go_out()

    def white_theme(self):
        self.radioButton_2.setDisabled(False)
        self.radioButton.setDisabled(True)
        self.radioButton_3.setDisabled(False)
        self.color_theme = {
            'Windows': {"background-color": "rgb(224, 235, 250);",
                        "border-color": "rgb(18, 18, 18);",
                        "color": "rgb(81, 81, 255);",
                        "font": "bold 10pt \"Arial\";\n"},
            'RadioButtons': {'background-color': 'rgb(224, 235, 250);',
                             'color': 'rgb(81, 81, 255);'},
            'Labels': {'background-color': 'rgb(224, 235, 250);',
                       'color': 'rgb(81, 81, 255);'},
            'Buttons': {'background-color': 'rgb(234, 234, 234);',
                        'color': 'rgb(81, 81, 255);',
                        },
            'Tables': {'background-color': 'rgb(224, 235, 250);',
                       'color': 'rgb(81, 81, 255);'},
            'CheckBoxes': {'background-color': 'rgb(224, 235, 250);',
                           'color': 'rgb(81, 81, 255);'},
            'LineEdits': {'background-color': 'rgb(255, 255, 255);',
                          'color': 'rgb(81, 81, 255);'},
            'PlainTextEdits': {'background-color': 'rgb(255, 255, 255);',
                               'color': 'rgb(81, 81, 255);'},

        }
        # self.setStyleSheet(''.join([self.color_theme['Windows'][i] for i in self.color_theme['Windows']]))
        # self.change_theme_database()
        # return
        QMessageBox.information(self, 'Изменение темы',
                                'Для сохранения изменений будет произведён выход из аккаунта')
        for i in self.name:
            self.update_theme(i[0], i[1])
        self.change_theme_database()
        self.object.go_out()

    def high_contrast(self):
        self.radioButton_2.setDisabled(False)
        self.radioButton.setDisabled(False)
        self.radioButton_3.setDisabled(True)
        self.color_theme = {
            'Windows': {"background-color": "rgb(255, 255, 255);",
                        "border-color": "rgb(18, 18, 18);",
                        "color": "rgb(0, 0, 0);",
                        "font": "bold 10pt \"Arial\";\n"},
            'RadioButtons': {'background-color': 'rgb(255, 255, 255);',
                             'color': 'rgb(0, 0, 0);'},
            'Labels': {'background-color': 'rgb(255, 255, 255);',
                       'color': 'rgb(0, 0, 0)'},
            'Buttons': {'background-color': 'rgb(255, 255, 255);',
                        'color': 'rgb(0, 0, 0)'},
            'Tables': {'background-color': 'rgb(255, 255, 255);',
                       'color': 'rgb(0, 0, 0);'},
            'CheckBoxes': {'background-color': 'rgb(255, 255, 255);',
                           'color': 'rgb(0, 0, 0);'},
            'LineEdits': {'background-color': 'rgb(255, 255, 255);',
                          'color': 'rgb(0, 0, 0);'},
            'PlainTextEdits': {'background-color': 'rgb(255, 255, 255);',
                               'color': 'rgb(0, 0, 0);'}
        }
        QMessageBox.information(self, 'Изменение темы',
                                'Для сохранения изменений будет произведён выход из аккаунта')
        for i in self.name:
            self.update_theme(i[0], i[1])
        self.change_theme_database()
        self.object.go_out()

    def update_theme(self, children, name):
        if name == 'Windows':
            stl = ''
            if children == self.sw.ex:
                self.sw.ex.updating(self.color_theme, self.work_dict)
                return
            for i in self.color_theme['Windows']:
                stl += i + ': ' + self.color_theme['Windows'][i]
            children.setStyleSheet(stl)
            if children != self:
                a = children.isHidden()
                children.hide()
                name = [(QRadioButton, 'RadioButtons'), (QLabel, 'Labels'),
                        (self, 'Windows'), (self.sw, 'Windows'),
                        (QPushButton, 'Buttons')]
                for i in name:
                    children.update_theme(i[0], i[1], self.color_theme, self.work_dict)
                if not a:
                    children.show()
            return

        a = self.findChildren(children)
        for i in range(len(a)):
            b = a[i].styleSheet()
            b = [j.strip('\n') for j in b.split(';') if j.strip('\n')]
            d = {}
            for j in b:
                if j.split(':')[0] not in d:
                    d[j.split(':')[0]] = j.split(':')[1]
            d['background-color'] = self.color_theme[name]['background-color']
            d['color'] = self.color_theme[name]['color']
            if self.radioButton_7.isChecked():
                font = 'Arial'
            else:
                font = self.color_theme['Windows']['font'].split()[2:]
                font[0] = font[0][1:]
                font[-1] = font[-1][:-2]
                font = ' '.join(font)


            d['font'] = (f'''bold {self.work_dict[int((d['font'].split())[1][:-2])]}pt "{font}";''')
            styles = ''
            for t in d:
                styles += (t + ': ' + d[t] + ';' + '\n')
            # QFont.pointSizeF(a[i].font())
            a[i].setStyleSheet(styles)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Return:
            if self.radioButton.isChecked():
                self.radioButton_2.setChecked(True)
                self.radioButton_2.click()
            elif self.radioButton_2.isChecked():
                self.radioButton_3.setChecked(True)
                self.radioButton_3.click()
            elif self.radioButton_3.isChecked():
                self.radioButton.setChecked(True)
                self.radioButton.click()

    def update(self):
        ## конец аботы с БД
        if self.k == -1:
            self.radioButton_9.setChecked(True)
            #self.radioButton_9.click()
        elif self.k == 0:
            self.radioButton_5.setChecked(True)
            #self.radioButton_5.click()
        else:
            self.radioButton_6.setChecked(True)
            #self.radioButton_6.click()

    def closeEvent(self, event):
        self.sw.close()
        self.destroy()

    def get_dates(self):
        if self.file == 'None.sqlite3':
            return
        self.con = sqlite3.connect(self.file)
        cur = self.con.cursor()
        unable_names = cur.execute(
            'SELECT * from settings').fetchall()[0]
        self.con.close()
        ## конец аботы с БД
        font = unable_names[0]
        background_color = unable_names[1]
        button_color = unable_names[3]
        text_color = unable_names[2]
        self.k = int(unable_names[4])
        self.n.append(self.k)
        self.work_dict = self.size_dict[self.k]
        # self.radioButton_6.setChecked(True)
        self.radioButton_8.setChecked(font != 'Arial')
        self.radioButton_7.setChecked(font == 'Arial')
        # white
        a = background_color == 'rgb(224, 235, 250);'
        b = text_color == 'rgb(81, 81, 255);'
        c = button_color == 'rgb(234, 234, 234);'
        nor = [a, b, c]
        # contra
        a = background_color == 'rgb(255, 255, 255);'
        b = text_color == 'rgb(0, 0, 0);'
        c = button_color == 'rgb(255, 255, 255);'
        contr = [a, b, c]
        # black
        a = background_color == 'rgb(0, 10, 120);'
        b = text_color == 'rgb(187, 187, 187);'
        c = button_color == 'rgb(0, 10, 120);'
        black = [a, b, c]
        self.radioButton.setChecked(all(nor))
        self.radioButton_2.setChecked(all(black))
        self.radioButton_3.setChecked(all(contr))
        if not all(nor) and not all(black) and not all(contr):
            self.radioButton_4.setChecked(True)
        self.color_theme = {}
        for i in self.name:
            if i[1] not in self.color_theme:
                self.color_theme[i[1]] = {}

        for i in self.color_theme:
            if i != 'Buttons' and i != 'LineEdits' and i != 'PlainTextEdits':
                self.color_theme[i]['background-color'] = background_color
            elif i == 'Buttons':
                self.color_theme[i]['background-color'] = button_color
            else:
                self.color_theme[i]['background-color'] = 'rgb(255, 255, 255);'
            self.color_theme[i]['color'] = text_color
            self.color_theme[i]["border-color"] = 'rgb(18, 18, 18);'
            if i == 'Windows':
                self.color_theme[i]["font"] = f"bold 10pt \"{font}\";\n"
        for i in self.name:
            self.update_theme(i[0], i[1])
        self.sw.experemental_colors = self.color_theme
        self.sw.ecc = self.color_theme
        if self.radioButton_7.isChecked():
            self.radioButton_7.setDisabled(True)


class W22(QMainWindow, W2):
    def __init__(self, colors, obj):
        super().__init__()
        self.setWindowIcon(QIcon('icons\icon.png'))
        self.flag = None
        self.setupUi(self)
        self.obj = obj
        self.setFixedSize(400, 160)
        self.setWindowTitle('Собственная тема')
        self.ex = Test()
        self.ex.hide()
        self.experemental_colors = colors
        self.ecc = {i: self.experemental_colors[i] for i in
                    self.experemental_colors}
        self.pushButton_5.clicked.connect(self.testing)
        self.pushButton.clicked.connect(self.experemental_window)
        self.pushButton_2.clicked.connect(self.experemental_button)
        self.pushButton_3.clicked.connect(self.experemental_text)
        self.size = self.obj.work_dict
        self.ex.updating(self.ecc, self.size)
        self.pushButton_6.clicked.connect(self.confirm)

    def confirm(self):
        self.obj.color_theme = self.ecc
        self.obj.change_theme_database()
        QMessageBox.information(self, 'Изменение темы',
                                'Для сохранения изменений будет произведён выход из аккаунта')
        self.destroy()
        self.obj.destroy()

        self.obj.object.go_out()

    def testing(self):
        self.ex.hide()
        self.ex.updating(self.ecc, self.size)
        self.ex.show()



    def update_theme(self, children, name, color_theme, size):
        self.size = size
        if name == 'Windows':
            stl = ''
            for i in color_theme['Windows']:
                stl += i + ': ' + color_theme['Windows'][i]
            children.setStyleSheet(stl)
            return
        a = self.findChildren(children)
        for i in range(len(a)):
            b = a[i].styleSheet()
            b = [j.strip('\n') for j in b.split(';') if j.strip('\n')]
            d = {}
            for j in b:
                try:
                    if j.split(':')[0] not in d:
                        d[j.split(':')[0]] = j.split(':')[1]
                except Exception:
                    return

            d['background-color'] = color_theme[name]['background-color']
            d['color'] = color_theme[name]['color']
            styles = ''
            if self.obj.radioButton_7.isChecked():
                font = 'Arial'
            else:
                font = color_theme['Windows']['font'].split()[2:]
                font[0] = font[0][1:]
                font[-1] = font[-1][:-2]
                font = ' '.join(font)
            if 'font' in d:
                d['font'] = (f'''bold {size[int((d['font'].split())[1][:-2])]}pt "{font}";''')
            for t in d:
                styles += (t + ':' + d[t] + ';' + '\n')
            a[i].setStyleSheet(styles)
        self.label_6.setStyleSheet(

            f"""background-color:{color_theme['Windows']['color']}""")
        self.label.setStyleSheet(

            f"""background-color:{color_theme['Windows']['background-color']}""")
        self.label_2.setStyleSheet(

            f"""background-color:{color_theme['Buttons']['background-color']}""")

    def experemental_text(self):
        color = QColorDialog.getColor()
        if color.isValid():
            for i in self.ecc:
                if i != 'Texts':
                    self.ecc[i][
                        'color'] = f'rgb{color.red(), color.green(), color.blue()};'
            self.ex.updating(self.ecc, self.size)
        if color.isValid():
            self.label_6.setStyleSheet(

                f'background-color:rgb{color.red(), color.green(), color.blue()};')
        return

    def experemental_button(self):
        # ('button' + '\n')
        color = QColorDialog.getColor()
        if color.isValid():
            self.ecc['Buttons'][
                'background-color'] = f'rgb{color.red(), color.green(), color.blue()};'
            self.ex.updating(self.ecc, self.size)
        if color.isValid():
            self.label_2.setStyleSheet(

                f'background-color:rgb{color.red(), color.green(), color.blue()};')
        return

    def experemental_window(self):
        color = QColorDialog.getColor()
        if color.isValid():
            self.ecc['Windows'][
                'background-color'] = f'rgb{color.red(), color.green(), color.blue()};'
            self.ecc['RadioButtons'][
                'background-color'] = f'rgb{color.red(), color.green(), color.blue()};'
            self.ecc['Tables'][
                'background-color'] = f'rgb{color.red(), color.green(), color.blue()};'
            self.ecc['CheckBoxes'][
                'background-color'] = f'rgb{color.red(), color.green(), color.blue()};'
            self.ecc['Labels'][
                'background-color'] = f'rgb{color.red(), color.green(), color.blue()};'
            self.ex.updating(self.ecc, self.size)
        # self.experemental_colors['Windows'] = self.ecc['Windows']
        for i in self.ecc:
            if i != 'Windows' and i != 'LineEdits' and i != "Buttons" and i != 'Texts':
                self.ecc[i][
                    'background-color'] = f'rgb{color.red(), color.green(), color.blue()};'
        if color.isValid():
            self.label.setStyleSheet(
                f'background-color:rgb{color.red(), color.green(), color.blue()};')
        return

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Return:
            self.pushButton_5.click()

    def closeEvent(self, event):
        self.ex.close()
        self.ex.destroy()
        self.destroy()


if __name__ == '__main__':
    sys.excepthook = expect_hook
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    work_class = Colors('nick.3')
    work_class.get_dates()
    work_class.update()
    work_class.show()
    sys.exit(app.exec())
