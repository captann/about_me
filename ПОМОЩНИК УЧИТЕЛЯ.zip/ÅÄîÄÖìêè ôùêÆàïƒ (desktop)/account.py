import random
import string
import apiclient
import httplib2
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QApplication, QMainWindow, QLineEdit, QMessageBox, \
    QInputDialog
from oauth2client.service_account import ServiceAccountCredentials
from interfaces import Ac
from autorisation import get_accounts
import pathlib
import smtplib
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from tkinter import messagebox, Tk
import sys
from autorisation import delete_file, add_file
from googleapiclient.discovery import build


def expect_hook(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)

def stuff_mail(theme, text,
               to):  # отправка паролей для входа и проверочных кодов
    message = MIMEMultipart()
    message["Subject"] = theme
    message["From"] = 'shifrovalshchik@list.ru'
    body = text
    message.attach(MIMEText(body, 'plain'))
    try:
        server = smtplib.SMTP_SSL('smtp.mail.ru', 465)
        server.login('shifrovalshchik@list.ru', 'Zxoiet123')
    except Exception as e:
        pass

    try:
        server.sendmail(message['from'], to, message.as_string())
        server.quit()
        return True, 'ok'
    except Exception as e:
        try:
            import socket
            socket.gethostbyaddr("www.yandex.ru")
        except Exception:
            return False, 'no_internet'
        # print("Пароль не может быть отправлен на указанный адрес." + '\n' + "Введите корректный адрес.")
        return False, 'adress_error'

def send_code(self, email):
    first_part = 'На введённый адрес не удалось отправить код подтверждения' + '\n'
    errors = {'no_internet': 'Проверьте подключение к интернету.',
              'adress_error': 'Проверьте корректность введённых данных.'}
    QMessageBox.information(self, "Изменение email",
                            "На указанный Вами email будет отправлен код потверждения." + '\n' +
                            'Пожалуйста, введите его в появившееся поле ввода.')
    code = str(random.choice(range(1000, 10000)))
    text = ''
    text += f'Код подтверждения изменения email: {code}' + '\n' * 2
    text += 'С уважением, разработчики.'
    res = stuff_mail('Код подтверждения', text, email)
    if not res[0]:
        return False
    res, ok_pressed = QInputDialog.getText(self, "Изменение email",
                                           "Введите проверочный код:")
    while not ok_pressed:
        action, ok_pressed_2 = QInputDialog.getItem(
            self, "Выбор действия",
            "Вы не ввели проверочный код. Что сделать?",
            ("Отправить код повторно", "Отменить изменение email",
             "Завершить работу программы"), 1, False)

        while not ok_pressed_2:
            action, ok_pressed_2 = QInputDialog.getItem(
                self, "Выбор действия",
                "Вы не ввели проверочный код. Что сделать?",
                ("Отправить код повторно", "Отменить изменение email",
                 "Завершить работу программы"), 1, False)
        if action == "Отправить код повторно":
            QMessageBox.information(self, "Изменение email",
                                    "На указанный Вами email будет отправлен код потверждения." + '\n' +
                                    'Пожалуйста, введите его в появившееся поле ввода.')
            code = str(random.choice(range(1000, 10000)))
            res = stuff_mail('Код подтверждения', code,
                             email)
            if not res[0]:
                QMessageBox.critical(self, "Изменение email",
                                     first_part + errors[res[1]])
                return False
            res, ok_pressed = QInputDialog.getText(self, "Изменение email",
                                                   "Введите проверочный код:")
        if action == "Отменить изменение email":
            return False
        if action == "Завершить работу программы":
            sys.exit()
    while res != code:
        action, ok_pressed_2 = QInputDialog.getItem(
            self, "Выбор действия",
            "Введённый код не совпадает с отправленным. Что сделать?",
            ("Отправить код повторно", "Отменить изменение email",
             "Завершить работу программы"), 1, False)
        while not ok_pressed_2:
            action, ok_pressed_2 = QInputDialog.getItem(
                self, "Выбор действия",
                "Введённый код не совпадает с отправленным. Что сделать?",
                ("Отправить код повторно", "Отменить изменение email",
                 "Завершить работу программы"), 1, False)
        if action == "Отправить код повторно":
            QMessageBox.information(self, "Изменение email",
                                    "На указанный Вами email будет отправлен код потверждения." + '\n' +
                                    'Пожалуйста, введите его в появившееся поле ввода.')
            code = str(random.choice(range(1000, 10000)))
            res = stuff_mail('Код подтверждения', code,
                             email)
            if not res[0]:
                QMessageBox.critical(self, "Изменение email",
                                     first_part + errors[res[1]])
                return False
            res, ok_pressed = QInputDialog.getText(self, "Изменение email",
                                                   "Введите проверочный код:")
        if action == "Отменить изменение email":
            return False
        if action == "Завершить работу программы":
            sys.exit()
    return True

def change_param(param, line, column):
    try:
        # Файл, полученный в Google Developer Console
        if not os.path.isfile('creds.json'):
            with open('creds.json', 'w+', encoding='utf-8') as f:
                f.write(r'''{
  "type": "service_account",
  "project_id": "oauth-295813",
  "private_key_id": "ae9ba005a85bd0c230cdc752213ad1ef321e1ad1",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDT9TSA+4Fe78QQ\nMV+4H7TVNpZtTWZgnqH6gedktJKeyDfis0C1vbts+St/2GJSERj8HXTatrlZZ7Gm\nSCb+VShd15ks9wWvOEjpreL0awDC4+uk+xbqVrb7+jaqHbgPGZllalrjG06osOeQ\nQGYZ7pRxmFPun/yhdmLXQWKF5s79eWjdLKzZlsT5EJ7I0oCVt4ego5A0zkf1tlKw\n14stx8CKirmRzQI0E3WvVRisMFlTDkqLKLb15dSX3IAuAmMsjrP2l83m/ayAyBkV\nebMfqi7/Bc1b4wGjPy/PavBWT73qpA6ubZi/877kmMkTlqlROg0pg9L90ehjY17q\nkw3s5g0NAgMBAAECggEAJTxeRyuH8H70JXkbDPxq9wsCNb0Dd4VexOS12yP63xCi\n+r1NaLAmgVArw2em7C5rQn1FRlgT60AzfhgOW59nukayNutFkSD09DJzXMeAiHxk\nbSUcQzpNJqqwGEYky+hOIbojseKd+LYtVBLwLO2UH/moAxORnObwmcq3jXj9E5vD\nBxAdY91NC+zV8DMm1U3CgGzuFX6VGqulQKa1tanCDJD7KFT9f1MhAP329hBxzHnT\nVLX9cW+zyhg81+J1QiKW6kP7NZkzHLW0ULhZCVEcCGXrdRmq+j1yGyTrZDL1EX2V\nOTWk5/xxXxomreG4XngmoPaD3wGpXR/wjSLOzj6jMQKBgQDp8CKZohrpYZBNa1cA\n9wK2ioW690pc30DeQ+ScqRltSuKk28T99GKBR2hooeOSLMhWKHTZ3e2GWC5H4aZj\nSBhM1+X1Ak1p1u4w3ilWlIh0goiyNhZsHMadTMlP+YxZ1rd/vu4K/kvFeX9G9qNQ\nRs5BnZxnylZzOQUpfSjGlt4zkQKBgQDn8mlcFnGMVEf4n50ViVvAkSmRQfhDFtel\nucRbhhw8IL5LZEZKS0AxREbO5BimgoqN/znfQIjw4cOIpfBBaBIe5yz0CQRzEla2\nhwu/ucibfA/M/vC1hhsWbhXdrz4ieryKyDvW2hoCzPZIB0BPP1cs34tS8/0gG/sJ\nGvV3kZbLvQKBgQDgN9cR5XthwK8sZPtI43doOjCe2LIffaOQ5QXS2YiTZjkAxdtz\nhK59NlHuJ2wVCHMjkTceMkWchBwnrTFq6wjPbgbr5D8KeIRntids4oQ/F3WpSYoI\nKTR8Q8KXsplA6jmKaReC1eUN6ruA6pfxM0wxO71TBW4Cld5Ku7k/Tg6+4QKBgGpM\nk3KrqoBIg+9ynxgmqlEXdfhnRnLgvhXqjA3x6XC5BN0iaIBV+mZZxyW8LXvqKbun\n84rYVaonnWg7vF8NZfiZs+VnWI2wIuNmAsFsUH7JnagyUniurC1caFL/pDdDDrN/\nzsTJkdAkxN3/zL5E5hvfm0d6IFCd4i+rFkIlC/n1AoGAFp8OzAFNMMitGUjihWmo\nCiMq7b61Ax3HJOFnpOjjfm2hubt0Y9bff6+ZGtL7lYApRKLsbsUI2YFeVut/SdLt\nSnHV1ivvqI7WARYWr9ptCySoQd0ItJx/jWGRvkFbniKc7ExtMRjn3wbywUsxDc+A\nNCU2v305mkg7lyj+2mIYYj4=\n-----END PRIVATE KEY-----\n",
  "client_email": "account@oauth-295813.iam.gserviceaccount.com",
  "client_id": "108851297345893727832",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/account%40oauth-295813.iam.gserviceaccount.com"
}
''')
        CREDENTIALS_FILE = 'creds.json'
        # ID Google Sheets документа (можно взять из его URL)
        spreadsheet_id = '1Lpw-IZkFWylk8FL1Q0jEDhurokJtNlepX9sQAUp7bPw'

        # Авторизуемся и получаем service — экземпляр доступа к API
        credentials = ServiceAccountCredentials.from_json_keyfile_name(
            CREDENTIALS_FILE,
            ['https://www.googleapis.com/auth/spreadsheets',
             'https://www.googleapis.com/auth/drive'])
        httpAuth = credentials.authorize(httplib2.Http())
        service = build('sheets', 'v4', http=httpAuth)
        values = service.spreadsheets().values().batchUpdate(
            spreadsheetId=spreadsheet_id,
            body={
                "valueInputOption": "USER_ENTERED",
                "data": [
                    {"range": f"{column}{line}:{column}{line}",
                     "majorDimension": 'ROWS',
                     "values": [[f'{param}']]}
                ]
            }
        ).execute()
        file = pathlib.Path('creds.json')
        file.unlink()
    except Exception as e:
        root = Tk()
        root.withdraw()
        messagebox.showerror('Помощь учителю',
                             'Критическая ошибка: невозможно загрузить данные. Проверьте подключение к интернету.')
        root.destroy()
        try:
            file = pathlib.Path('creds.json')
            file.unlink()
        except Exception:
            pass
        sys.exit()


class Account(QMainWindow, Ac):
    def __init__(self, nick, email, password, nicks, emails, passwords, work_class, obj):
        super().__init__()
        self.setWindowIcon(QIcon('icons\icon.png'))
        self.obj = obj
        self.setupUi(self)
        self.setFixedSize(445, 178)
        self.setWindowTitle('Аккаунт')
        self.flag_nick = True
        self.flag_email = True
        self.work_class = work_class
        self.new_nick = ''
        self.new_email = ''
        self.new_password = ''
        self.nick = nick
        self.email = email
        self.nicks = nicks
        self.emails = emails
        self.passwords = passwords
        self.password = password
        if len(self.nick) <= 15:
            self.lineEdit.setText(self.nick)
        else:
            a = self.nick[:9]
            b = self.nick[-5:]
            self.lineEdit.setText(a + '...' + b)
        if len(self.email) <= 15:
            self.lineEdit_2.setText(self.email)
        else:
            a = self.email[:9]
            b = self.email[-5:]
            self.lineEdit_2.setText(a + '...' + b)
        self.lineEdit.setDisabled(True)
        self.lineEdit_2.setDisabled(True)
        self.pushButton.clicked.connect(self.change_nick)
        self.pushButton_2.clicked.connect(self.change_email)
        self.pushButton_4.clicked.connect(self.show_password)
        self.pushButton_3.clicked.connect(self.change_password)
        self.label_5.setText(' ')
        self.label_5.installEventFilter(self)
        self.label_6.setText(' ')
        self.label_6.installEventFilter(self)

    def update_theme(self, children, name, color_theme, size):
        self.size = size
        if name == 'Windows':
            stl = ''
            for i in color_theme['Windows']:
                stl += i + ': ' + color_theme['Windows'][i]
            children.setStyleSheet(stl)
            return
        a = self.findChildren(children)
        for i in range(len(a)):
            b = a[i].styleSheet()
            b = [j.strip('\n') for j in b.split(';') if j.strip('\n')]
            d = {}
            for j in b:
                try:
                    if j.split(':')[0] not in d:
                        d[j.split(':')[0]] = j.split(':')[1]
                except Exception:
                    return

            d['background-color'] = color_theme[name]['background-color']

            d['color'] = color_theme[name]['color']
            styles = ''
            if self.obj.color.radioButton_7.isChecked():
                font = 'Arial'
            else:
                font = color_theme['Windows']['font'].split()[2:]
                font[0] = font[0][1:]
                font[-1] = font[-1][:-2]
                font = ' '.join(font)
            if 'font' in d:
                if 'bold' in d['font']:
                    d['font'] = (f'''bold {size[int((d['font'].split())[1][:-2])]}pt "{font}";''')
                else:
                    d['font'] = (
                        f'''bold {size[int((d['font'].split())[0][:-2])]}pt "{font}";''')
            for t in d:
                styles += (t + ':' + d[t] + ';' + '\n')
            a[i].setStyleSheet(styles)


    def change_nick(self):
        self.pushButton_2.setDisabled(True)
        self.pushButton_3.setDisabled(True)
        self.lineEdit.setText('')
        self.lineEdit.setDisabled(False)
        self.label_2.setText('Новый никнейм:')
        self.pushButton.disconnect()
        self.pushButton.clicked.connect(self.old_nick)
        self.pushButton.setText('Отмена')
        self.lineEdit.textChanged[str].disconnect()
        self.lineEdit.textChanged[str].connect(self.nik_ok)

    def nik_ok(self):
        if len(
                self.lineEdit.text().strip()) >= 4 and self.lineEdit.text().strip() not in self.nicks:
            self.lineEdit.setStyleSheet(
                'background-color: rgb(255, 255, 255);'
                'border-color: rgb(18, 18, 18);'
                'color: rgb(0, 255, 0);'
                'font: bold 10pt "Arial";')
            self.pushButton.setText('Продолжить')
            self.pushButton.disconnect()
            self.pushButton.clicked.connect(self.permittion_nick)
            self.label_5.setText('Отмена')
        else:
            if self.flag_nick:
                self.lineEdit.setStyleSheet(
                    'background-color: rgb(255, 255, 255);'
                    'border-color: rgb(18, 18, 18);'
                    'color: rgb(255, 0, 0);'
                    'font: bold 10pt "Arial";')
                self.pushButton.setText('Отмена')
                self.pushButton.disconnect()
                self.pushButton.clicked.connect(self.old_nick)
                self.label_5.setText(' ')

    def ok(self):
        pass

    def permittion_nick(self):
        self.flag_nick = False
        self.new_nick = self.lineEdit.text()
        self.pushButton.disconnect()
        self.pushButton.clicked.connect(self.change_nick_final)
        self.pushButton.setText('Подтвердить')
        self.pushButton.update()
        self.lineEdit.setText('')
        self.label_5.setText('Отмена')
        a = self.lineEdit.font()
        self.lineEdit.setStyleSheet(f"background-color: {self.obj.color.color_theme['LineEdits']['background-color']}color: {self.obj.color.color_theme['LineEdits']['color']}")
        self.lineEdit.setFont(a)
        self.lineEdit.setEchoMode(QLineEdit.Password)
        self.label_2.setText('Пароль от аккаунта:')
        self.lineEdit.textChanged[str].disconnect()
        self.lineEdit.textChanged[str].connect(self.ok)

    def change_nick_final(self):
        if not self.lineEdit.text().strip():
            QMessageBox.critical(self, 'Изменение никнейма',
                                 'Пароль не был введён. Запрос на изменение никнейма отклонён')
            self.lineEdit.setText('')
            self.old_nick()
            return False
        elif self.lineEdit.text().strip() != self.password:
            QMessageBox.critical(self, 'Изменение никнейма',
                                 'Введён неверный пароль. Запрос на изменение никнейма отклонён')
            self.lineEdit.setText('')
            self.old_nick()
            return False
        else:
            self.hide()
            QMessageBox.information(self, 'Изменение никнейма',
                                    'Пожалуйста, подождите...')
            change_param(self.new_nick, self.nicks.index(self.nick) + 3, 'A')
            stuff_mail('Изменение никнейма',
                       f'Изменён никнейм от аккаунта {self.nick} в программе Помощник учителя.' + '\n' + f'Новый никнейм: {self.new_nick}',
                       self.email)
            os.rename(f'{self.nick}.sqlite3', f'{self.new_nick}.sqlite3')
            add_file(f'{self.new_nick}.sqlite3')
            delete_file(f'{self.nick}.sqlite3')
            self.work_class.name = self.new_nick
            self.nick = self.new_nick
            self.upate_datas()
            self.work_class.getname(self.nick, self.email, self.password)
            self.new_nick = ''
            QMessageBox.information(self, 'Изменение никнейма',
                                 'Никнейм успешно изменён')
            self.show()
            self.old_nick()
            return True

    def old_nick(self):
        if len(self.nick) <= 15:
            self.lineEdit.setText(self.nick)
        else:
            a = self.nick[:9]
            b = self.nick[-5:]
            self.lineEdit.setText(a + '...' + b)
        self.pushButton_2.setDisabled(False)
        self.pushButton_3.setDisabled(False)
        self.lineEdit.setDisabled(True)
        self.label_2.setText('Текущий никнейм:')
        self.pushButton.setText('Изменить')
        self.pushButton.disconnect()
        self.pushButton.clicked.connect(self.change_nick)
        #self.lineEdit.setStyleSheet("background-color: rgb(255, 255, 255);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 10pt \"Arial\";\n")
        self.lineEdit.setEchoMode(QLineEdit.Normal)
        self.label_5.setText(' ')
        self.label_6.setText(' ')
        self.lineEdit.update()
        self.lineEdit.disconnect()
        self.lineEdit.textChanged[str].connect(self.nik_ok)
        self.lineEdit.update()
        self.flag_nick = True
        for i in self.obj.color.name:
            self.update_theme(i[0], i[1], self.obj.color.color_theme, self.obj.color.norm)

    def old_email(self):
        if len(self.email) <= 15:
            self.lineEdit_2.setText(self.email)
        else:
            a = self.email[:9]
            b = self.email[-5:]
            self.lineEdit_2.setText(a + '...' + b)
        self.pushButton.setDisabled(False)
        self.pushButton_3.setDisabled(False)
        self.lineEdit_2.setDisabled(True)
        self.label.setText('Текущий email:')
        self.pushButton_2.setText('Изменить')
        self.pushButton_2.disconnect()
        self.pushButton_2.clicked.connect(self.change_email)
        #self.lineEdit_2.setStyleSheet("background-color: rgb(255, 255, 255);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 10pt \"Arial\";\n")
        self.lineEdit_2.setEchoMode(QLineEdit.Normal)
        self.label_5.setText(' ')
        self.label_6.setText(' ')
        self.lineEdit_2.disconnect()
        self.lineEdit_2.textChanged[str].connect(self.email_ok)
        self.flag_email = True
        self.lineEdit_2.update()
        for i in self.obj.color.name:
            self.update_theme(i[0], i[1], self.obj.color.color_theme, self.obj.color.norm)

    def upate_datas(self):
        a = get_accounts()
        self.nicks = a['account']
        self.emails = a['email']
        self.passwords = a['password']

    def change_email(self):
        self.pushButton.setDisabled(True)
        self.pushButton_3.setDisabled(True)
        self.lineEdit_2.setText('')
        self.lineEdit_2.setDisabled(False)
        self.label.setText('Новый email:')
        self.pushButton_2.disconnect()
        self.pushButton_2.clicked.connect(self.old_email)
        self.pushButton_2.setText('Отмена')
        self.lineEdit_2.textChanged[str].disconnect()
        self.lineEdit_2.textChanged[str].connect(self.email_ok)

    def change_email_final(self):
        if not self.lineEdit_2.text().strip():
            QMessageBox.critical(self, 'Изменение email',
                                 'Пароль не был введён. Запрос на изменение email отклонён')
            self.lineEdit_2.setText('')
            self.old_email()
        elif self.lineEdit_2.text().strip() != self.password:
            QMessageBox.critical(self, 'Изменение email',
                                 'Введён неверный пароль. Запрос на изменение email отклонён')
            self.lineEdit_2.setText('')
            self.old_nick()
        else:
            a = send_code(self, self.new_email)
            if not a:
                QMessageBox.critical(self, 'Изменение email',
                                     'Email не был подтверждён. Запрос на изменение email отклонён')
                self.lineEdit_2.setText('')
                self.old_email()
                return False
            self.hide()
            QMessageBox.information(self, 'Изменение email',
                                    'Пожалуйста, подождите...')
            change_param(self.new_email, self.emails.index(self.email) + 3, 'C')
            stuff_mail('Изменение email',
                       f'Изменён email от аккаунта {self.nick} в программе Помощник учителя.' + '\n' + f'Новый email: {self.new_email}',
                       self.email)
            self.email = self.new_email
            self.work_class.email = self.new_email
            self.upate_datas()
            self.work_class.getname(self.nick, self.email, self.password)
            self.new_email = ''
            QMessageBox.information(self, 'Изменение email',
                                 'Email успешно изменён')
            self.show()
            self.old_email()
            return True

    def permittion_email(self):
        self.flag_email = False
        self.new_email = self.lineEdit_2.text()
        self.pushButton_2.disconnect()
        self.pushButton_2.clicked.connect(self.change_email_final)
        self.pushButton_2.setText('Подтвердить')
        self.pushButton_2.update()
        self.lineEdit_2.setText('')
        a = self.lineEdit_2.font()
        self.lineEdit_2.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['LineEdits']['background-color']}color: {self.obj.color.color_theme['LineEdits']['color']}")
        self.lineEdit_2.setFont(a)

        """self.lineEdit_2.setStyleSheet(
            "background-color: rgb(255, 255, 255);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 10pt \"Arial\";\n")"""
        self.lineEdit_2.setEchoMode(QLineEdit.Password)
        self.label.setText('Пароль от аккаунта:')
        self.lineEdit_2.textChanged[str].disconnect()
        self.lineEdit_2.textChanged[str].connect(self.ok)

    def email_ok(self):
        if "@" in self.lineEdit_2.text() and self.lineEdit_2.text() not in self.emails and (
                '.ru' in self.lineEdit_2.text() \
                or '.com' in self.lineEdit_2.text()):
            self.lineEdit_2.setStyleSheet(
                'background-color: rgb(255, 255, 255);'
                'border-color: rgb(18, 18, 18);'
                'color: rgb(0, 255, 0);'
                'font: bold 10pt "Arial";')
            self.pushButton_2.setText('Продолжить')
            self.pushButton_2.disconnect()
            self.pushButton_2.clicked.connect(self.permittion_email)
            self.label_6.setText('Отмена')
        else:
            if self.flag_email:
                self.lineEdit_2.setStyleSheet(
                    'background-color: rgb(255, 255, 255);'
                    'border-color: rgb(18, 18, 18);'
                    'color: rgb(255, 0, 0);'
                    'font: bold 10pt "Arial";')
                self.pushButton_2.setText('Отмена')
                self.pushButton_2.disconnect()
                self.pushButton_2.clicked.connect(self.old_email)
                self.label_6.setText(' ')




    def show_password(self):
        text = f'Пароль от аккаунта {self.nick} в программе'
        text += f' Помощник учителя: {self.password}'
        a = stuff_mail('Просмотр пароля', text, self.email)
        if a[0]:
            QMessageBox.information(self, 'Просмотр пароля', 'Пароль от аккаунта выслан на текущий email')
            return True
        else:
            QMessageBox.critical(self, 'Просмотр пароля', 'Пароль не может быть выслан. Проверьте подключение к интернету')
            return False




    def change_password(self):
        self.lineEdit.setText('')
        self.lineEdit.setEchoMode(QLineEdit.Password)
        self.lineEdit.textChanged[str].disconnect()
        self.lineEdit.textChanged[str].connect(self.ok)
        self.lineEdit.setDisabled(False)
        a = self.lineEdit.font()
        self.lineEdit.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['LineEdits']['background-color']}color: {self.obj.color.color_theme['LineEdits']['color']}")
        self.lineEdit.setFont(a)
        a = self.lineEdit_2.font()
        self.lineEdit_2.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['LineEdits']['background-color']}color: {self.obj.color.color_theme['LineEdits']['color']}")
        self.lineEdit_2.setFont(a)

        #self.lineEdit.setStyleSheet("background-color: rgb(255, 255, 255);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 10pt \"Arial\";\n")

        self.lineEdit_2.setText('')
        self.lineEdit_2.textChanged[str].disconnect()
        self.lineEdit_2.textChanged[str].connect(self.ok_password)
        self.lineEdit_2.setDisabled(False)


        self.label.setText('Новый пароль:')
        self.label_2.setText('Текущий пароль:')

        self.pushButton.setText('Узнать')
        self.pushButton.disconnect()
        self.pushButton.clicked.connect(self.show_password)

        self.pushButton_2.setText('Сгенерировать')
        self.pushButton_2.disconnect()
        self.pushButton_2.clicked.connect(self.generate_password)

        self.pushButton_3.setText('Отмена')
        self.pushButton_3.disconnect()
        self.pushButton_3.clicked.connect(self.old_password)

        self.pushButton_4.setText('Изменить пароль')
        self.pushButton_4.disconnect()
        self.pushButton_4.clicked.connect(self.change_password_final)

        self.label_3.setText(' ')
        self.lineEdit.textChanged[str].disconnect()
        self.lineEdit.textChanged[str].connect(self.ok)

    def help_update(self):
        self.flag_nick = True
        self.flag_email = True
        if len(self.nick) <= 15:
            self.lineEdit.setText(self.nick)
        else:
            a = self.nick[:9]
            b = self.nick[-5:]
            self.lineEdit.setText(a + '...' + b)
        if len(self.email) <= 15:
            self.lineEdit_2.setText(self.email)
        else:
            a = self.email[:9]
            b = self.email[-5:]
            self.lineEdit_2.setText(a + '...' + b)
        self.lineEdit.textChanged[str].connect(self.nik_ok)
        self.lineEdit_2.textChanged[str].connect(self.email_ok)

    def change_password_final(self):
        self.new_password = self.lineEdit_2.text().strip()
        if not self.lineEdit.text().strip():
            QMessageBox.critical(self, 'Изменение пароля',
                                 'Пароль не был введён. Запрос на изменение пароля отклонён')
            self.lineEdit.setText('')
            self.lineEdit_2.setText('')
            self.old_password()
            return False
        if self.lineEdit.text().strip() != self.password:
            QMessageBox.critical(self, 'Изменение пароля', 'Введён неверный пароль. Запрос на изменение пароля отклонён')
            self.lineEdit.setText('')
            self.lineEdit_2.setText('')
            self.old_password()
            return False
        else:
            self.hide()
            QMessageBox.information(self, 'Изменение пароля',
                                    'Пожалуйста, подождите...')
            change_param(self.new_password, self.passwords.index(self.password) + 3, 'B')
            self.password = self.new_password
            self.upate_datas()

            self.work_class.password = self.new_password
            self.work_class.getname(self.nick, self.email, self.password)
            stuff_mail('Изменение пароля', f'Изменён пароль от аккаунта {self.nick} в программе Помощник учителя.' + '\n' + f'Новый пароль: {self.new_password}', self.email)
            QMessageBox.information(self, 'Изменение пароля',
                                    'Пароль успешно изменён')
            self.new_password = ''
            self.show()
            self.old_password()
            return True



    def old_password(self):
        if len(self.nick) <= 15:
            self.lineEdit.setText(self.nick)
        else:
            a = self.nick[:9]
            b = self.nick[-5:]
            self.lineEdit.setText(a + '...' + b)
        if len(self.email) <= 15:
            self.lineEdit_2.setText(self.email)
        else:
            a = self.email[:9]
            b = self.email[-5:]
            self.lineEdit_2.setText(a + '...' + b)
        self.lineEdit.setEchoMode(QLineEdit.Normal)
        self.lineEdit.textChanged[str].disconnect()
        self.lineEdit.textChanged[str].connect(self.nik_ok)
        self.lineEdit.setDisabled(True)

        self.label.setText('Текущий email:')
        self.label_2.setText('Текущий никнейм:')

        self.pushButton_4.setText('Узнать')
        self.pushButton_4.disconnect()
        self.pushButton_4.clicked.connect(self.show_password)

        self.pushButton.setText('Изменить')
        self.pushButton.disconnect()
        self.pushButton.clicked.connect(self.change_nick)

        self.pushButton_3.setText('Изменить')
        self.pushButton_3.disconnect()
        self.pushButton_3.clicked.connect(self.change_password)

        self.pushButton_2.setText('Изменить')
        self.pushButton_2.disconnect()
        self.pushButton_2.clicked.connect(self.change_email)

        self.label_5.setText(' ')
        self.label_6.setText(' ')
        self.label_3.setText('Текущий пароль:')
        for i in self.obj.color.name:
            self.update_theme(i[0], i[1], self.obj.color.color_theme, self.obj.color.norm)


    def generate_password(self):
        lenth = random.sample(range(8, 12), 1)[0]
        numbers = [['1', '2', '3', '4', '5', '6', '7', '8', '9', '0']]
        total_list = [list(string.ascii_lowercase)] + [
            list(string.ascii_uppercase)] + numbers
        count = 0
        final_list = []
        work_min = [0, 1, 2]
        work_max = [0, 1, 2]
        for i in range(lenth):
            count += 1
            if count <= 3:
                group_of_symbols = random.sample(work_min, 1)[0]
                work_min.remove(group_of_symbols)
                final_list.append(
                    random.sample(total_list[group_of_symbols], 1)[0])
            else:
                group_of_symbols = random.sample(work_max, 1)[0]
                final_list.append(
                    random.sample(total_list[group_of_symbols], 1)[0])
        random.shuffle(final_list)
        final_list.reverse()
        self.passwor = final_list
        self.lineEdit_2.setText(''.join(self.passwor))

    def ok_password(self):
        self.lineEdit_2.setText(self.lineEdit_2.text().strip())
        if self.password_level(self.lineEdit_2.text()).lower() == 'ok':
            self.lineEdit_2.setStyleSheet(
                'background-color: rgb(255, 255, 255);'
                'border-color: rgb(18, 18, 18);'
                'color: rgb(0, 255, 0);'
                'font: bold 10pt "Arial";')
            self.pushButton_4.setDisabled(False)
            return True

        else:
            self.lineEdit_2.setStyleSheet(
                'background-color: rgb(255, 255, 255);'
                'border-color: rgb(18, 18, 18);'
                'color: rgb(255, 0, 0);'
                'font: bold 10pt "Arial";')
            self.pushButton_4.setDisabled(True)
            return False

    def eventFilter(self, obj, e):
        if e.type() == 2:
            btn = e.button()
            if btn:
                if obj.text() == 'Отмена':
                    self.total_back()
        return super(QMainWindow, self).eventFilter(obj, e)

    def total_back(self):
        self.old_nick()
        self.old_email()
        self.old_password()
        self.label_5.setText(' ')
        self.label_6.setText(' ')
        return


    def password_level(self, password):
        if len(password) < 8:
            return "Пароль короче 8 символов."
        letters, numbers, up = False, False, False
        for i in password:
            if i.lower() == i and i.isalpha():
                letters = True
            if ord(i) in range(48, 58):
                numbers = True
            if i.upper() == i and ord(i) not in range(48, 58):
                up = True
        if letters and numbers and up:
            return 'Ok'
        elif letters and numbers and not up:
            return "Добавьте в пароль заглавных букв."
        elif letters and up and not numbers:
            return "Добавьтев пароль цифр."
        elif numbers and up and not letters:
            return "Добавьте в пароль строчных букв."
        elif numbers and not letters and not up:
            return "Добавьтев пароль  букв разных регистров."
        elif letters and not numbers and not up:
            return "Добавьте в пароль цифр и заглавных букв."
        else:
            return "Добавьте в пароль прописных букв и цифр."

    def what_to_do(self):
        if self.label.text() == 'Новый пароль:':
            if self.ok_password():
                self.pushButton_4.click()
            return
        else:
            if self.pushButton.text() != 'Изменить':
                self.pushButton.click()
                return
            elif self.pushButton_2.text() != 'Изменить':
                self.pushButton_2.click()
                return
            else:
                self.pushButton_4.click()
                return

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Return:
            self.what_to_do()

if __name__ == '__main__':
    sys.excepthook = expect_hook
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    a = get_accounts()
    work_class = Account(a['account'][0], a['email'][0], a['password'][0], a['account'], a['email'], a['password'])
    work_class.show()
    sys.exit(app.exec())
