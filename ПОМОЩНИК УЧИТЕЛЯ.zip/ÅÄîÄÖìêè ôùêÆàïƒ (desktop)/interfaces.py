from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import Qt


class Slkui(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.setFixedSize(760, 353)
        MainWindow.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                 "border-color: rgb(18, 18, 18);\n"
                                 "color: rgb(81, 81, 255);\n"
                                 "font: bold 12pt \"Arial\";")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.horizontalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.horizontalLayoutWidget.setGeometry(QtCore.QRect(0, 0, 761, 311))
        self.horizontalLayoutWidget.setObjectName("horizontalLayoutWidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.label_2 = QtWidgets.QLabel(self.horizontalLayoutWidget)
        self.label_2.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 12pt \"Arial\";")
        self.label_2.setObjectName("label_2")
        self.verticalLayout.addWidget(self.label_2)
        self.lineEdit = QtWidgets.QLineEdit(self.horizontalLayoutWidget)
        self.lineEdit.setStyleSheet("background-color: rgb(255, 255, 255);\n"
                                    "border-color: rgb(18, 18, 18);\n"
                                    "color: rgb(81, 81, 255);\n"
                                    "font: bold 12pt \"Arial\";")
        self.lineEdit.setObjectName("lineEdit")
        self.verticalLayout.addWidget(self.lineEdit)
        self.label_3 = QtWidgets.QLabel(self.horizontalLayoutWidget)
        self.label_3.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 12pt \"Arial\";")
        self.label_3.setObjectName("label_3")
        self.verticalLayout.addWidget(self.label_3)
        self.lineEdit_2 = QtWidgets.QLineEdit(self.horizontalLayoutWidget)
        self.lineEdit_2.setStyleSheet("background-color: rgb(255, 255, 255);\n"
                                      "border-color: rgb(18, 18, 18);\n"
                                      "color: rgb(81, 81, 255);\n"
                                      "font: bold 12pt \"Arial\";")
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.verticalLayout.addWidget(self.lineEdit_2)
        self.pushButton_2 = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.pushButton_2.setStyleSheet("background-color: rgb(234, 234, 234);\n"
                                        "border-color: rgb(18, 18, 18);\n"
                                        "color: rgb(81, 81, 255);\n"
                                        "font: bold 12pt \"Arial\";\n"
                                        "")
        self.pushButton_2.setObjectName("pushButton_2")
        self.verticalLayout.addWidget(self.pushButton_2)
        spacerItem1 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem1)
        self.horizontalLayout.addLayout(self.verticalLayout)
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.label = QtWidgets.QLabel(self.horizontalLayoutWidget)
        self.label.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                 "border-color: rgb(18, 18, 18);\n"
                                 "color: rgb(81, 81, 255);\n"
                                 "font: bold 12pt \"Arial\";")
        self.label.setObjectName("label")
        self.verticalLayout_2.addWidget(self.label)
        self.checkBox = QtWidgets.QCheckBox(self.horizontalLayoutWidget)
        self.checkBox.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                    "border-color: rgb(18, 18, 18);\n"
                                    "color: rgb(81, 81, 255);\n"
                                    "font: bold 10pt \"Arial\";")
        self.checkBox.setObjectName("checkBox")
        self.verticalLayout_2.addWidget(self.checkBox)
        self.tableWidget = QtWidgets.QTableWidget(self.horizontalLayoutWidget)
        self.tableWidget.setStyleSheet("background-color: rgb(255, 255, 255);\n"
                                       "border-color: rgb(18, 18, 18);\n"
                                       "color: rgb(81, 81, 255);\n"
                                       "font: bold 8pt \"Arial\";")
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(4)
        self.tableWidget.setRowCount(0)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(3, item)
        self.verticalLayout_2.addWidget(self.tableWidget)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.pushButton_3 = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.pushButton_3.setStyleSheet("background-color: rgb(234, 234, 234);\n"
                                        "border-color: rgb(18, 18, 18);\n"
                                        "color: rgb(81, 81, 255);\n"
                                        "font: bold 12pt \"Arial\";\n"
                                        "")
        self.pushButton_3.setObjectName("pushButton_3")
        self.horizontalLayout_2.addWidget(self.pushButton_3)
        spacerItem2 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem2)
        self.pushButton = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.pushButton.setStyleSheet("background-color: rgb(234, 234, 234);\n"
                                      "border-color: rgb(18, 18, 18);\n"
                                      "color: rgb(81, 81, 255);\n"
                                      "font: bold 12pt \"Arial\";\n"
                                      "")
        self.pushButton.setObjectName("pushButton")
        self.horizontalLayout_2.addWidget(self.pushButton)
        self.verticalLayout_2.addLayout(self.horizontalLayout_2)
        self.horizontalLayout.addLayout(self.verticalLayout_2)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 763, 25))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label_2.setText(_translate("MainWindow", "Название ссылки:"))
        self.label_3.setText(_translate("MainWindow", "Ссылка:"))
        self.pushButton_2.setText(_translate("MainWindow", "Добавить сссылку"))
        self.label.setText(_translate("MainWindow", "Доступные ссылки:"))
        self.checkBox.setText(_translate("MainWindow", "Выбрать все"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "Выбрать"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "Название"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "Ссылка"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "Добавлена"))
        self.pushButton_3.setText(_translate("MainWindow", "Открыть выбранные"))
        self.pushButton.setText(_translate("MainWindow", "Удалить выбранные"))


class Zametkiui(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(619, 381)
        MainWindow.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                 "border-color: rgb(18, 18, 18);\n"
                                 "color: rgb(81, 81, 255);\n"
                                 "font: bold 12pt \"Arial\";")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.horizontalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.horizontalLayoutWidget.setGeometry(QtCore.QRect(10, 10, 611, 321))
        self.horizontalLayoutWidget.setObjectName("horizontalLayoutWidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.label_2 = QtWidgets.QLabel(self.horizontalLayoutWidget)
        self.label_2.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 12pt \"Arial\";")
        self.label_2.setObjectName("label_2")
        self.verticalLayout.addWidget(self.label_2)
        self.lineEdit = QtWidgets.QLineEdit(self.horizontalLayoutWidget)
        self.lineEdit.setStyleSheet("background-color: rgb(255, 255, 255);\n"
                                    "border-color: rgb(18, 18, 18);\n"
                                    "color: rgb(81, 81, 255);\n"
                                    "font: bold 12pt \"Arial\";\n"
                                    "")
        self.lineEdit.setObjectName("lineEdit")
        self.verticalLayout.addWidget(self.lineEdit)
        self.label = QtWidgets.QLabel(self.horizontalLayoutWidget)
        self.label.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                 "border-color: rgb(18, 18, 18);\n"
                                 "color: rgb(81, 81, 255);\n"
                                 "font: bold 12pt \"Arial\";")
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)
        self.plainTextEdit = QtWidgets.QPlainTextEdit(self.horizontalLayoutWidget)
        self.plainTextEdit.setStyleSheet("background-color: rgb(255, 255, 255);\n"
                                         "border-color: rgb(18, 18, 18);\n"
                                         "color: rgb(81, 81, 255);\n"
                                         "font: bold 12pt \"Arial\";")
        self.plainTextEdit.setObjectName("plainTextEdit")
        self.verticalLayout.addWidget(self.plainTextEdit)
        self.pushButton_2 = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.pushButton_2.setStyleSheet("background-color: rgb(234, 234, 234);\n"
                                        "border-color: rgb(18, 18, 18);\n"
                                        "color: rgb(81, 81, 255);\n"
                                        "font: bold 10pt \"Arial\";")
        self.pushButton_2.setObjectName("pushButton_2")
        self.verticalLayout.addWidget(self.pushButton_2)
        self.horizontalLayout.addLayout(self.verticalLayout)
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.label_3 = QtWidgets.QLabel(self.horizontalLayoutWidget)
        self.label_3.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 12pt \"Arial\";")
        self.label_3.setObjectName("label_3")
        self.verticalLayout_2.addWidget(self.label_3)
        self.checkBox = QtWidgets.QCheckBox(self.horizontalLayoutWidget)
        self.checkBox.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                    "border-color: rgb(18, 18, 18);\n"
                                    "color: rgb(81, 81, 255);\n"
                                    "font: bold 10pt \"Arial\";")
        self.checkBox.setObjectName("checkBox")
        self.verticalLayout_2.addWidget(self.checkBox)
        self.tableWidget = QtWidgets.QTableWidget(self.horizontalLayoutWidget)
        self.tableWidget.setStyleSheet("background-color: rgb(255, 255, 255);\n"
                                       "border-color: rgb(18, 18, 18);\n"
                                       "color: rgb(81, 81, 255);\n"
                                       "font: bold 8pt \"Arial\";")
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(3)
        self.tableWidget.setRowCount(0)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, item)
        self.verticalLayout_2.addWidget(self.tableWidget)
        self.pushButton_show = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.pushButton_show.setStyleSheet("background-color: rgb(234, 234, 234);\n"
                                      "border-color: rgb(18, 18, 18);\n"
                                      "color: rgb(81, 81, 255);\n"
                                      "font: bold 10pt \"Arial\";")
        self.pushButton_show.setObjectName("pushButton_show")
        self.verticalLayout_2.addWidget(self.pushButton_show)
        self.pushButton = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.pushButton.setStyleSheet("background-color: rgb(234, 234, 234);\n"
                                      "border-color: rgb(18, 18, 18);\n"
                                      "color: rgb(81, 81, 255);\n"
                                      "font: bold 10pt \"Arial\";")
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout_2.addWidget(self.pushButton)
        self.horizontalLayout.addLayout(self.verticalLayout_2)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 619, 25))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label_2.setText(_translate("MainWindow", "Тема заметки:"))
        self.label.setText(_translate("MainWindow", "Текст заметки:"))
        self.pushButton_2.setText(_translate("MainWindow", "Добавить заметку"))
        self.label_3.setText(_translate("MainWindow", "Доступные заметки:"))
        self.checkBox.setText(_translate("MainWindow", "Выбрать все"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "Выбрать"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "Тема заметки"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "Заметка"))
        self.pushButton.setText(_translate("MainWindow", "Удалить выбранные"))
        self.pushButton_show.setText(_translate("MainWindow", "Посмтореть последнюю выбранную"))


class Napominanieui(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(960, 505)
        MainWindow.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                 "border-color: rgb(18, 18, 18);\n"
                                 "color: rgb(81, 81, 255);\n"
                                 "font: bold 12pt \"Arial\";")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.horizontalLayoutWidget_2 = QtWidgets.QWidget(self.centralwidget)
        self.horizontalLayoutWidget_2.setGeometry(
            QtCore.QRect(10, 10, 945, 475))
        self.horizontalLayoutWidget_2.setObjectName("horizontalLayoutWidget_2")
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout(
            self.horizontalLayoutWidget_2)
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.verticalLayout_5 = QtWidgets.QVBoxLayout()
        self.verticalLayout_5.setObjectName("verticalLayout_5")
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.label_3 = QtWidgets.QLabel(self.horizontalLayoutWidget_2)
        self.label_3.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 12pt \"Arial\";")
        self.label_3.setObjectName("label_3")
        self.verticalLayout.addWidget(self.label_3)
        self.calendarWidget = QtWidgets.QCalendarWidget(
            self.horizontalLayoutWidget_2)
        self.calendarWidget.setStyleSheet(
            "alternate-background-color: rgb(85, 170, 255);\n"
            "color: rgb(81, 81, 81);\n"
            "selection-background-color: rgb(255, 0, 55);\n"
            "")
        self.calendarWidget.setObjectName("calendarWidget")
        self.verticalLayout.addWidget(self.calendarWidget)
        self.label_4 = QtWidgets.QLabel(self.horizontalLayoutWidget_2)
        self.label_4.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 12pt \"Arial\";")
        self.label_4.setObjectName("label_4")
        self.verticalLayout.addWidget(self.label_4)
        self.timeEdit = QtWidgets.QTimeEdit(self.horizontalLayoutWidget_2)
        self.timeEdit.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                    "border-color: rgb(18, 18, 18);\n"
                                    "color: rgb(81, 81, 255);\n"
                                    "font: bold 12pt \"Arial\";")
        self.timeEdit.setObjectName("timeEdit")
        self.verticalLayout.addWidget(self.timeEdit)
        self.horizontalLayout_2.addLayout(self.verticalLayout)
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.label = QtWidgets.QLabel(self.horizontalLayoutWidget_2)
        self.label.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                 "border-color: rgb(18, 18, 18);\n"
                                 "color: rgb(81, 81, 255);\n"
                                 "font: bold 12pt \"Arial\";")
        self.label.setObjectName("label")
        self.verticalLayout_2.addWidget(self.label)
        self.lineEdit = QtWidgets.QLineEdit(self.horizontalLayoutWidget_2)
        self.lineEdit.setStyleSheet("background-color: rgb(255, 255, 255);\n"
                                    "border-color: rgb(18, 18, 18);\n"
                                    "color: rgb(81, 81, 255);\n"
                                    "font: bold 12pt \"Arial\";")
        self.lineEdit.setObjectName("lineEdit")
        self.verticalLayout_2.addWidget(self.lineEdit)
        self.label_2 = QtWidgets.QLabel(self.horizontalLayoutWidget_2)
        self.label_2.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 12pt \"Arial\";")
        self.label_2.setObjectName("label_2")
        self.verticalLayout_2.addWidget(self.label_2)
        self.plainTextEdit = QtWidgets.QPlainTextEdit(
            self.horizontalLayoutWidget_2)
        self.plainTextEdit.setStyleSheet(
            "background-color: rgb(255, 255, 255);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 12pt \"Arial\";")
        self.plainTextEdit.setObjectName("plainTextEdit")
        self.verticalLayout_2.addWidget(self.plainTextEdit)
        self.horizontalLayout_2.addLayout(self.verticalLayout_2)
        self.verticalLayout_3.addLayout(self.horizontalLayout_2)
        self.pushButton = QtWidgets.QPushButton(self.horizontalLayoutWidget_2)
        self.pushButton.setStyleSheet("background-color: rgb(234, 234, 234);\n"
                                      "border-color: rgb(18, 18, 18);\n"
                                      "color: rgb(81, 81, 255);\n"
                                      "font: bold 10pt \"Arial\";")
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout_3.addWidget(self.pushButton)
        self.verticalLayout_5.addLayout(self.verticalLayout_3)
        self.horizontalLayout_3.addLayout(self.verticalLayout_5)
        self.verticalLayout_4 = QtWidgets.QVBoxLayout()
        self.verticalLayout_4.setObjectName("verticalLayout_4")
        self.label_5 = QtWidgets.QLabel(self.horizontalLayoutWidget_2)
        self.label_5.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 12pt \"Arial\";")
        self.label_5.setObjectName("label_5")
        self.verticalLayout_4.addWidget(self.label_5)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label_6 = QtWidgets.QLabel(self.horizontalLayoutWidget_2)
        self.label_6.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 10pt \"Arial\";")
        self.label_6.setObjectName("label_6")
        self.horizontalLayout.addWidget(self.label_6)
        self.lineEdit_2 = QtWidgets.QLineEdit(self.horizontalLayoutWidget_2)
        self.lineEdit_2.setStyleSheet("background-color: rgb(255, 255, 255);\n"
                                      "border-color: rgb(18, 18, 18);\n"
                                      "color: rgb(81, 81, 255);\n"
                                      "font: bold 12pt \"Arial\";")
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.horizontalLayout.addWidget(self.lineEdit_2)
        spacerItem = QtWidgets.QSpacerItem(40, 20,
                                           QtWidgets.QSizePolicy.Expanding,
                                           QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.verticalLayout_4.addLayout(self.horizontalLayout)
        self.horizontalLayout_4 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        self.label_7 = QtWidgets.QLabel(self.horizontalLayoutWidget_2)
        self.label_7.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 10pt \"Arial\";")
        self.label_7.setObjectName("label_7")
        self.horizontalLayout_4.addWidget(self.label_7)
        self.comboBox = QtWidgets.QComboBox(self.horizontalLayoutWidget_2)
        self.comboBox.setStyleSheet("font: 10pt \"Arial\";\n"
"background-color: rgb(255, 255, 255);\n"
                                    "color: rgb(81, 81, 255);\n"
                                    "font: bold 10pt \"Arial\";"
                                    )
        self.comboBox.setObjectName("comboBox")
        self.comboBox.addItem('дате и времени')
        self.comboBox.addItem('теме')
        self.comboBox.addItem('дате и времени (R)')
        self.comboBox.addItem('теме (R)')
        self.horizontalLayout_4.addWidget(self.comboBox)
        self.checkBox = QtWidgets.QCheckBox(self.horizontalLayoutWidget_2)
        self.checkBox.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                    "border-color: rgb(18, 18, 18);\n"
                                    "color: rgb(81, 81, 255);\n"
                                    "font: bold 10pt \"Arial\";")
        self.checkBox.setObjectName("checkBox")
        self.horizontalLayout_4.addWidget(self.checkBox)
        spacerItem = QtWidgets.QSpacerItem(40, 20,
                                           QtWidgets.QSizePolicy.Expanding,
                                           QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem)
        self.verticalLayout_4.addLayout(self.horizontalLayout_4)
        self.tableWidget = QtWidgets.QTableWidget(
            self.horizontalLayoutWidget_2)
        self.tableWidget.setStyleSheet(
            "background-color: rgb(255, 255, 255);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 8pt \"Arial\";")
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(4)
        self.tableWidget.setRowCount(0)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(3, item)
        self.verticalLayout_4.addWidget(self.tableWidget)
        self.pushButton_2 = QtWidgets.QPushButton(
            self.horizontalLayoutWidget_2)
        self.pushButton_2.setStyleSheet(
            "background-color: rgb(234, 234, 234);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 10pt \"Arial\";")
        self.pushButton_2.setObjectName("pushButton_2")
        self.verticalLayout_4.addWidget(self.pushButton_2)
        self.horizontalLayout_3.addLayout(self.verticalLayout_4)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1028, 25))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label_3.setText(
            _translate("MainWindow", "Дата отправления напоминания:"))
        self.label_4.setText(
            _translate("MainWindow", "Время отправления напоминания:"))
        self.label.setText(_translate("MainWindow", "Тема напоминания:"))
        self.label_2.setText(_translate("MainWindow", "Текст напоминания:"))
        self.pushButton.setText(
            _translate("MainWindow", "Добавить напоминание"))
        self.label_5.setText(
            _translate("MainWindow", "Доступные напоминания:"))
        self.label_6.setText(_translate("MainWindow", "Поиск напоминания:"))
        self.checkBox.setText(_translate("MainWindow", "Выбрать все"))
        self.label_7.setText(_translate("MainWindow", "Сортировать по:"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "Выбрать"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "Дата"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "Время"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "Тема"))
        self.pushButton_2.setText(
            _translate("MainWindow", "Удалить выбранные"))


class MainWindowui(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.setFixedSize(1045, 848)
        MainWindow.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"font: 10pt \"Arial\";\n"
"color: rgb(81, 81, 255);\n"
"")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayoutWidget_2 = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget_2.setGeometry(QtCore.QRect(10, 0, 1050, 801))
        self.verticalLayoutWidget_2.setObjectName("verticalLayoutWidget_2")
        self.gridLayout = QtWidgets.QGridLayout(self.verticalLayoutWidget_2)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.gridLayout.setObjectName("gridLayout")
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setSpacing(2)
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.nowclasslabel = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        self.nowclasslabel.setStyleSheet("font: 16pt \"Arial\";\n"
"color: rgb(81, 81, 255);")
        self.nowclasslabel.setObjectName("nowclasslabel")
        self.horizontalLayout_2.addWidget(self.nowclasslabel)
        self.choiceclass = QtWidgets.QComboBox(self.verticalLayoutWidget_2)
        self.choiceclass.setStyleSheet("font: bold 10pt \"Arial\";\n")
        self.choiceclass.setObjectName("choiceclass")
        self.horizontalLayout_2.addWidget(self.choiceclass)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem)
        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem1)
        spacerItem2 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem2)
        spacerItem3 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem3)
        spacerItem4 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem4)
        spacerItem5 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem5)
        spacerItem6 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem6)
        spacerItem7 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem7)
        spacerItem8 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem8)
        for i in range(24):
            spacerItem8 = QtWidgets.QSpacerItem(40, 20,
                                                QtWidgets.QSizePolicy.Expanding,
                                                QtWidgets.QSizePolicy.Minimum)
            self.horizontalLayout_2.addItem(spacerItem8)
        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        self.label_2.setStyleSheet("font: 16pt \"Arial\";\n"
"color: rgb(81, 81, 255);")
        self.label_2.setObjectName("label_2")
        self.horizontalLayout_2.addWidget(self.label_2)
        self.lcdNumber = QtWidgets.QLCDNumber(self.verticalLayoutWidget_2)
        self.lcdNumber.setObjectName("lcdNumber")
        self.horizontalLayout_2.addWidget(self.lcdNumber)
        spacerItem8 = QtWidgets.QSpacerItem(40, 20,
                                            QtWidgets.QSizePolicy.Expanding,
                                            QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem8)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        self.verticalLayout_3.addLayout(self.verticalLayout)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.sortbylabel = QtWidgets.QLabel(self.verticalLayoutWidget_2)

        self.sortbylabel.setObjectName("sortbylabel")
        self.horizontalLayout.addWidget(self.sortbylabel)
        self.choicesort = QtWidgets.QComboBox(self.verticalLayoutWidget_2)

        self.choicesort.setObjectName("choicesort")
        self.choicesort.addItem("")
        self.choicesort.addItem("")
        self.choicesort.addItem("")
        self.choicesort.addItem("")
        self.choicesort.addItem("")
        self.horizontalLayout.addWidget(self.choicesort)
        spacerItem9 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem9)
        spacerItem10 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem10)
        self.uchlooklabel = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        self.uchlooklabel.setStyleSheet("font: 16pt \"Arial\";\n"
"color: rgb(81, 81, 255);")
        self.uchlooklabel.setObjectName("uchlooklabel")
        self.horizontalLayout.addWidget(self.uchlooklabel)
        self.uchlookedit = QtWidgets.QLineEdit(self.verticalLayoutWidget_2)
        self.uchlookedit.setStyleSheet("background-color: rgb(255, 255, 255);\n""font: bold 10pt \"Arial\";""background-color: rgb(255, 255, 255);")
        self.uchlookedit.setObjectName("uchlookedit")
        self.horizontalLayout.addWidget(self.uchlookedit)
        spacerItem11 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem11)
        spacerItem12 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem12)
        spacerItem13 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem13)
        spacerItem14 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem14)
        spacerItem15 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem15)
        spacerItem16 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem16)
        spacerItem17 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem17)
        self.verticalLayout_3.addLayout(self.horizontalLayout)
        self.reversebox = QtWidgets.QCheckBox(self.verticalLayoutWidget_2)

        self.reversebox.setObjectName("reversebox")
        self.verticalLayout_3.addWidget(self.reversebox)
        self.allok = QtWidgets.QCheckBox(self.verticalLayoutWidget_2)

        self.allok.setObjectName("allok")
        self.verticalLayout_3.addWidget(self.allok)
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.verticalLayout_13 = QtWidgets.QVBoxLayout()
        self.verticalLayout_13.setObjectName("verticalLayout_13")
        self.table = QtWidgets.QTableWidget(self.verticalLayoutWidget_2)
        #self.table.setStyleSheet("background-color: rgb(170, 85, 127);")
        self.table.setObjectName("table")
        self.table.setColumnCount(8)
        self.table.setRowCount(0)
        item = QtWidgets.QTableWidgetItem()
        self.table.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.table.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.table.setHorizontalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.table.setHorizontalHeaderItem(3, item)
        item = QtWidgets.QTableWidgetItem()
        self.table.setHorizontalHeaderItem(4, item)
        item = QtWidgets.QTableWidgetItem()
        self.table.setHorizontalHeaderItem(5, item)
        item = QtWidgets.QTableWidgetItem()
        self.table.setHorizontalHeaderItem(6, item)
        item = QtWidgets.QTableWidgetItem()
        self.table.setHorizontalHeaderItem(7, item)
        self.verticalLayout_13.addWidget(self.table)
        self.continue_2 = QtWidgets.QPushButton(self.verticalLayoutWidget_2)
        self.continue_2.setStyleSheet("font: 14pt \"Arial\";\n"
"background-color: rgb(234, 234, 234);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);")
        self.continue_2.setObjectName("continue_2")
        self.verticalLayout_13.addWidget(self.continue_2)
        self.horizontalLayout_3.addLayout(self.verticalLayout_13)
        self.verticalLayout_11 = QtWidgets.QVBoxLayout()
        self.verticalLayout_11.setObjectName("verticalLayout_11")
        self.verticalLayout_10 = QtWidgets.QVBoxLayout()
        self.verticalLayout_10.setObjectName("verticalLayout_10")
        self.verticalLayout_8 = QtWidgets.QVBoxLayout()
        self.verticalLayout_8.setObjectName("verticalLayout_8")
        self.verticalLayout_9 = QtWidgets.QVBoxLayout()
        self.verticalLayout_9.setObjectName("verticalLayout_9")
        spacerItem18 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_9.addItem(spacerItem18)
        self.mesh = QtWidgets.QPushButton(self.verticalLayoutWidget_2)
        self.mesh.setStyleSheet("font: 14pt \"Arial\";\n"
"background-color: rgb(234, 234, 234);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);")
        self.mesh.setObjectName("mesh")
        self.verticalLayout_9.addWidget(self.mesh)
        spacerItem19 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_9.addItem(spacerItem19)
        self.pushButton = QtWidgets.QPushButton(self.verticalLayoutWidget_2)
        self.pushButton.setStyleSheet("font: 14pt \"Arial\";\n"
"background-color: rgb(234, 234, 234);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);")
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout_9.addWidget(self.pushButton)
        spacerItem20 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_9.addItem(spacerItem20)
        self.verticalLayout_7 = QtWidgets.QVBoxLayout()
        self.verticalLayout_7.setObjectName("verticalLayout_7")
        spacerItem21 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_7.addItem(spacerItem21)
        self.usefullabel = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        self.usefullabel.setStyleSheet("font: 14pt \"Arial\";\n"
"color: rgb(81, 81, 255);")
        self.usefullabel.setObjectName("usefullabel")
        self.verticalLayout_7.addWidget(self.usefullabel)
        spacerItem22 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_7.addItem(spacerItem22)
        self.calc = QtWidgets.QPushButton(self.verticalLayoutWidget_2)
        self.calc.setStyleSheet("font: 14pt \"Arial\";\n"
"background-color: rgb(234, 234, 234);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);")
        self.calc.setObjectName("calc")
        self.verticalLayout_7.addWidget(self.calc)
        spacerItem23 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_7.addItem(spacerItem23)
        self.minipaint = QtWidgets.QPushButton(self.verticalLayoutWidget_2)
        self.minipaint.setStyleSheet("font: 14pt \"Arial\";\n"
"background-color: rgb(234, 234, 234);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);")
        self.minipaint.setObjectName("minipaint")
        self.verticalLayout_7.addWidget(self.minipaint)
        spacerItem24 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_7.addItem(spacerItem24)
        self.verticalLayout_9.addLayout(self.verticalLayout_7)
        self.verticalLayout_8.addLayout(self.verticalLayout_9)
        self.verticalLayout_10.addLayout(self.verticalLayout_8)
        spacerItem25 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_10.addItem(spacerItem25)
        spacerItem26 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_10.addItem(spacerItem26)
        self.label = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        self.label.setStyleSheet("font: 14pt \"Arial\";\n"
"color: rgb(81, 81, 255);")
        self.label.setObjectName("label")
        self.verticalLayout_10.addWidget(self.label)
        spacerItem27 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_10.addItem(spacerItem27)
        spacerItem28 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_10.addItem(spacerItem28)
        self.napadd = QtWidgets.QPushButton(self.verticalLayoutWidget_2)
        self.napadd.setStyleSheet("font: 14pt \"Arial\";\n"
"background-color: rgb(234, 234, 234);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);")
        self.napadd.setObjectName("napadd")
        self.verticalLayout_10.addWidget(self.napadd)
        spacerItem29 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_10.addItem(spacerItem29)
        spacerItem30 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_10.addItem(spacerItem30)
        self.sladd = QtWidgets.QPushButton(self.verticalLayoutWidget_2)
        self.sladd.setStyleSheet("font: 14pt \"Arial\";\n"
"background-color: rgb(234, 234, 234);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);")
        self.sladd.setObjectName("sladd")
        self.verticalLayout_10.addWidget(self.sladd)
        spacerItem31 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_10.addItem(spacerItem31)
        spacerItem32 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_10.addItem(spacerItem32)
        self.zapshow = QtWidgets.QPushButton(self.verticalLayoutWidget_2)
        self.zapshow.setStyleSheet("font: 14pt \"Arial\";\n"
"background-color: rgb(234, 234, 234);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);")
        self.zapshow.setObjectName("zapshow")
        self.verticalLayout_10.addWidget(self.zapshow)
        self.verticalLayout_11.addLayout(self.verticalLayout_10)
        self.horizontalLayout_3.addLayout(self.verticalLayout_11)
        spacerItem99 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.horizontalLayout_3.addItem(spacerItem99)
        self.verticalLayout_3.addLayout(self.horizontalLayout_3)
        spacerItem33 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem33)
        self.gridLayout.addLayout(self.verticalLayout_3, 0, 0, 1, 1)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1028, 25))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Помощник учителя"))
        self.nowclasslabel.setText(_translate("MainWindow", "Класс:"))
        self.label_2.setText(_translate("MainWindow", "Текущее время:"))
        self.sortbylabel.setText(_translate("MainWindow", "Сортировать по:"))
        self.choicesort.setItemText(0, _translate("MainWindow", "Фамилии"))
        self.choicesort.setItemText(1, _translate("MainWindow", "Имени"))
        self.choicesort.setItemText(2, _translate("MainWindow", "Дате рождения"))
        self.choicesort.setItemText(3, _translate("MainWindow", "Полу (мальчики)"))
        self.choicesort.setItemText(4, _translate("MainWindow", "Полу (девочки)"))
        self.uchlooklabel.setText(_translate("MainWindow", "Поиск ученика:"))
        self.reversebox.setText(_translate("MainWindow", "Показывать в обратном порядке"))
        self.allok.setText(_translate("MainWindow", "Выбрать всех"))
        item = self.table.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "Выбрать"))
        item.setTextAlignment(Qt.AlignHCenter)
        item = self.table.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "Имя"))
        item.setTextAlignment(Qt.AlignHCenter)
        item = self.table.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "Фамилия"))
        item.setTextAlignment(Qt.AlignHCenter)
        item = self.table.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "Дата рождения"))
        item.setTextAlignment(Qt.AlignHCenter)
        item = self.table.horizontalHeaderItem(4)
        item.setText(_translate("MainWindow", "Пол"))
        item.setTextAlignment(Qt.AlignHCenter)
        item = self.table.horizontalHeaderItem(5)
        item.setText(_translate("MainWindow", "Email"))
        item.setTextAlignment(Qt.AlignHCenter)
        item = self.table.horizontalHeaderItem(6)
        item.setText(_translate("MainWindow", "Телефон"))
        item.setTextAlignment(Qt.AlignHCenter)
        item = self.table.horizontalHeaderItem(7)
        item.setText(_translate("MainWindow", "Родитель"))
        item.setTextAlignment(Qt.AlignHCenter)
        self.continue_2.setText(_translate("MainWindow", "Продолжить"))
        self.mesh.setText(_translate("MainWindow", "Открыть МЭШ"))
        self.pushButton.setText(_translate("MainWindow", "Выйти из аккаунта"))
        self.usefullabel.setText(_translate("MainWindow", "Полезные инструменты:"))
        self.calc.setText(_translate("MainWindow", "Калькулятор"))
        self.minipaint.setText(_translate("MainWindow", "Mini Paint"))
        self.label.setText(_translate("MainWindow", "Работа с записями:"))
        self.napadd.setText(_translate("MainWindow", "Напоминания"))
        self.sladd.setText(_translate("MainWindow", "Ссылки"))
        self.zapshow.setText(_translate("MainWindow", "Заметки"))


class Showtextui(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(600, 400)
        MainWindow.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                 "border-color: rgb(18, 18, 18);\n"
                                 "color: rgb(81, 81, 255);\n"
                                 "font: bold 12pt \"Arial\";")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.gridLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.gridLayoutWidget.setGeometry(QtCore.QRect(10, 0, 600, 400))
        self.gridLayoutWidget.setObjectName("gridLayoutWidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.gridLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.plainTextEdit = QtWidgets.QPlainTextEdit(self.gridLayoutWidget)
        self.plainTextEdit.setStyleSheet("background-color: rgb(255, 255, 255);\n"
                                         "border-color: rgb(18, 18, 18);\n"
                                         "color: rgb(81, 81, 255);\n"
                                         "font: bold 12pt \"Arial\";\n"
                                         "")
        self.plainTextEdit.setObjectName("plainTextEdit")
        self.verticalLayout.addWidget(self.plainTextEdit)
        self.pushButton = QtWidgets.QPushButton(self.gridLayoutWidget)
        self.pushButton.setStyleSheet("background-color: rgb(234, 234, 234);\n"
                                      "border-color: rgb(18, 18, 18);\n"
                                      "color: rgb(81, 81, 255);\n"
                                      "font: bold 10pt \"Arial\";")
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout.addWidget(self.pushButton)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 600, 25))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.pushButton.setText(_translate("MainWindow", "PushButton"))


class Sendui(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(470, 510)
        MainWindow.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                 "border-color: rgb(18, 18, 18);\n"
                                 "color: rgb(81, 81, 255);\n"
                                 "font: bold 10pt \"Arial\";")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayoutWidget_2 = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget_2.setGeometry(QtCore.QRect(10, 0, 451, 481))
        self.verticalLayoutWidget_2.setObjectName("verticalLayoutWidget_2")
        self.verticalLayout_6 = QtWidgets.QVBoxLayout(
            self.verticalLayoutWidget_2)
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_6.setObjectName("verticalLayout_6")
        self.verticalLayout_5 = QtWidgets.QVBoxLayout()
        self.verticalLayout_5.setObjectName("verticalLayout_5")
        self.verticalLayout_4 = QtWidgets.QVBoxLayout()
        self.verticalLayout_4.setSpacing(10)
        self.verticalLayout_4.setObjectName("verticalLayout_4")
        self.horizontalLayout_5 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_5.setObjectName("horizontalLayout_5")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label_3 = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        self.label_3.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 12pt \"Arial\";")
        self.label_3.setObjectName("label_3")
        self.horizontalLayout.addWidget(self.label_3)
        self.lineEdit = QtWidgets.QLineEdit(self.verticalLayoutWidget_2)
        self.lineEdit.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.lineEdit.setObjectName("lineEdit")
        self.horizontalLayout.addWidget(self.lineEdit)
        spacerItem = QtWidgets.QSpacerItem(40, 20,
                                           QtWidgets.QSizePolicy.Expanding,
                                           QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setSpacing(10)
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.label_4 = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        self.label_4.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 12pt \"Arial\";")
        self.label_4.setObjectName("label_4")
        self.horizontalLayout_3.addWidget(self.label_4)
        self.comboBox = QtWidgets.QComboBox(self.verticalLayoutWidget_2)
        self.comboBox.setObjectName("comboBox")
        self.horizontalLayout_3.addWidget(self.comboBox)
        self.verticalLayout_3.addLayout(self.horizontalLayout_3)
        self.pushButton = QtWidgets.QPushButton(self.verticalLayoutWidget_2)
        self.pushButton.setStyleSheet("background-color: rgb(234, 234, 234);\n"
                                      "border-color: rgb(18, 18, 18);\n"
                                      "color: rgb(81, 81, 255);\n"
                                      "font: bold 10pt \"Arial\";")
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout_3.addWidget(self.pushButton)
        self.horizontalLayout.addLayout(self.verticalLayout_3)
        self.horizontalLayout_5.addLayout(self.horizontalLayout)
        self.verticalLayout_4.addLayout(self.horizontalLayout_5)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setSpacing(3)
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        self.label_2.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 12pt \"Arial\";")
        self.label_2.setObjectName("label_2")
        self.verticalLayout_2.addWidget(self.label_2)
        self.plainTextEdit = QtWidgets.QPlainTextEdit(
            self.verticalLayoutWidget_2)
        self.plainTextEdit.setStyleSheet(
            "background-color: rgb(255, 255, 255);")
        self.plainTextEdit.setObjectName("plainTextEdit")
        self.verticalLayout_2.addWidget(self.plainTextEdit)
        self.pushButton_2 = QtWidgets.QPushButton(self.verticalLayoutWidget_2)
        self.pushButton_2.setStyleSheet(
            "background-color: rgb(234, 234, 234);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 10pt \"Arial\";")
        self.pushButton_2.setObjectName("pushButton_2")
        self.verticalLayout_2.addWidget(self.pushButton_2)
        self.horizontalLayout_2.addLayout(self.verticalLayout_2)
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.label = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        self.label.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                 "border-color: rgb(18, 18, 18);\n"
                                 "color: rgb(81, 81, 255);\n"
                                 "font: bold 12pt \"Arial\";")
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)
        self.listWidget = QtWidgets.QListWidget(self.verticalLayoutWidget_2)
        self.listWidget.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.listWidget.setObjectName("listWidget")
        self.verticalLayout.addWidget(self.listWidget)
        self.pushButton_3 = QtWidgets.QPushButton(self.verticalLayoutWidget_2)
        self.pushButton_3.setStyleSheet(
            "background-color: rgb(234, 234, 234);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 10pt \"Arial\";")
        self.pushButton_3.setObjectName("pushButton_3")
        self.verticalLayout.addWidget(self.pushButton_3)
        self.horizontalLayout_2.addLayout(self.verticalLayout)
        self.horizontalLayout_2.setStretch(1, 5)
        self.verticalLayout_4.addLayout(self.horizontalLayout_2)
        self.verticalLayout_5.addLayout(self.verticalLayout_4)
        self.horizontalLayout_6 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_6.setObjectName("horizontalLayout_6")
        self.label_5 = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        self.label_5.setStyleSheet(
            "background-color: rgb(224, 235, 250);\\nborder-color: rgb(18, 18, 18);\\ncolor: rgb(81, 81, 255);\\nfont: bold 12pt \"Arial\";")
        self.label_5.setObjectName("label_5")
        self.horizontalLayout_6.addWidget(self.label_5)
        self.progressBar = QtWidgets.QProgressBar(self.verticalLayoutWidget_2)
        self.progressBar.setStyleSheet(
            "background-color: rgb(224, 235, 250);border-color: rgb(18, 18, 18);color: rgb(0, 189, 244);font: bold 12pt \"Arial\";")
        self.progressBar.setProperty("value", 24)
        self.progressBar.setObjectName("progressBar")
        self.horizontalLayout_6.addWidget(self.progressBar)
        self.verticalLayout_5.addLayout(self.horizontalLayout_6)
        self.horizontalLayout_4 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        self.verticalLayout_5.addLayout(self.horizontalLayout_4)
        self.verticalLayout_6.addLayout(self.verticalLayout_5)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 470, 22))
        self.menubar.setObjectName("menubar")
        self.menu = QtWidgets.QMenu(self.menubar)
        self.menu.setObjectName("menu")
        self.menu_2 = QtWidgets.QAction(self.menubar)
        self.menu_2.setObjectName("menu_2")
        self.menu_3 = QtWidgets.QMenu(self.menubar)
        self.menu_3.setObjectName("menu_3")
        MainWindow.setMenuBar(self.menubar)
        self.menubar.addAction(self.menu.menuAction())
        self.menubar.addAction(self.menu_2)
        self.menubar.addAction(self.menu_3.menuAction())

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label_3.setText(_translate("MainWindow", "Тема письма:"))
        self.label_4.setText(_translate("MainWindow", "Вложения:"))
        self.pushButton.setText(_translate("MainWindow", "Удалить последнее"))
        self.label_2.setText(_translate("MainWindow", "Текст письма:"))
        self.pushButton_2.setText(_translate("MainWindow", "Отправить"))
        self.label.setText(_translate("MainWindow", "Получатели:"))
        self.pushButton_3.setText(
            _translate("MainWindow", "Добавить вложение"))
        self.label_5.setText(_translate("MainWindow", "Завершено:"))
        self.menu.setTitle(_translate("MainWindow", "Отправка писем"))
        self.menu_2.setText(_translate("MainWindow", "Создание документов"))
        self.menu_3.setTitle(_translate("MainWindow", "Просмотр досье"))


from PyQt5 import QtCore, QtGui, QtWidgets


class Allproui(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(370, 140)
        MainWindow.setStyleSheet("background-color: rgb(224, 235, 250);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 14pt \"Arial\";\n"
"")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(0, 0, 361, 131))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.plainTextEdit = QtWidgets.QPlainTextEdit(self.verticalLayoutWidget)
        self.plainTextEdit.setStyleSheet("background-color: rgb(255, 255, 255);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 12pt \"Arial\";")
        self.plainTextEdit.setObjectName("plainTextEdit")
        self.verticalLayout.addWidget(self.plainTextEdit)
        self.pushButton = QtWidgets.QPushButton(self.verticalLayoutWidget)
        self.pushButton.setStyleSheet("background-color: rgb(234, 234, 234);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 10pt \"Arial\";")
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout.addWidget(self.pushButton)
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.plainTextEdit.setPlainText(_translate("MainWindow", "Данная программа была разработана учениками Яндекс.Лицея для помощи\n"
"учителям в их важном и ответственном\n"
"деле.\nОна находится в свободном доступе и каждый имеет право на её использование в своих целях."
""))
        self.pushButton.setText(_translate("MainWindow", "Понятно"))

class Backui(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(550, 355)
        MainWindow.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 10pt \"Arial\";")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayoutWidget_3 = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget_3.setGeometry(QtCore.QRect(10, 10, 533, 331))
        self.verticalLayoutWidget_3.setObjectName("verticalLayoutWidget_3")
        self.verticalLayout_4 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget_3)
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_4.setObjectName("verticalLayout_4")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label = QtWidgets.QLabel(self.verticalLayoutWidget_3)
        self.label.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 12pt \"Arial\";")
        self.label.setObjectName("label")
        self.horizontalLayout.addWidget(self.label)
        self.comboBox = QtWidgets.QComboBox(self.verticalLayoutWidget_3)
        self.comboBox.setObjectName("comboBox")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.horizontalLayout.addWidget(self.comboBox)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget_3)
        self.label_2.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 8pt \"Arial\";")
        self.label_2.setObjectName("label_2")
        self.verticalLayout.addWidget(self.label_2)
        self.verticalLayout_2.addLayout(self.verticalLayout)
        self.horizontalLayout_2.addLayout(self.verticalLayout_2)
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setSpacing(10)
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.label_4 = QtWidgets.QLabel(self.verticalLayoutWidget_3)
        self.label_4.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 12pt \"Arial\";")
        self.label_4.setObjectName("label_4")
        self.horizontalLayout_3.addWidget(self.label_4)
        self.comboBox_2 = QtWidgets.QComboBox(self.verticalLayoutWidget_3)
        self.comboBox_2.setObjectName("comboBox_2")
        self.horizontalLayout_3.addWidget(self.comboBox_2)
        self.verticalLayout_3.addLayout(self.horizontalLayout_3)
        self.pushButton = QtWidgets.QPushButton(self.verticalLayoutWidget_3)
        self.pushButton.setStyleSheet("background-color: rgb(234, 234, 234);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 10pt \"Arial\";")
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout_3.addWidget(self.pushButton)
        self.verticalLayout_3.setStretch(0, 5)
        self.horizontalLayout_2.addLayout(self.verticalLayout_3)
        self.horizontalLayout_2.setStretch(0, 5)
        self.verticalLayout_4.addLayout(self.horizontalLayout_2)
        self.plainTextEdit = QtWidgets.QPlainTextEdit(self.verticalLayoutWidget_3)
        self.plainTextEdit.setObjectName("plainTextEdit")
        self.verticalLayout_4.addWidget(self.plainTextEdit)
        self.horizontalLayout_4 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        self.pushButton_2 = QtWidgets.QPushButton(self.verticalLayoutWidget_3)
        self.pushButton_2.setStyleSheet("background-color: rgb(234, 234, 234);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 10pt \"Arial\";")
        self.pushButton_2.setObjectName("pushButton_2")
        self.horizontalLayout_4.addWidget(self.pushButton_2)
        self.pushButton_3 = QtWidgets.QPushButton(self.verticalLayoutWidget_3)
        self.pushButton_3.setStyleSheet("background-color: rgb(234, 234, 234);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 10pt \"Arial\";")
        self.pushButton_3.setObjectName("pushButton_3")
        self.horizontalLayout_4.addWidget(self.pushButton_3)
        self.horizontalLayout_4.setStretch(0, 5)
        self.verticalLayout_4.addLayout(self.horizontalLayout_4)
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "Тип обращения:"))
        self.comboBox.setItemText(0, _translate("MainWindow", "Идея для улучшения"))
        self.comboBox.setItemText(1, _translate("MainWindow", "Отзыв о программе"))
        self.comboBox.setItemText(2, _translate("MainWindow", "Сообщение об ошибке"))
        self.label_2.setText(_translate("MainWindow", "Пожалуйста, опишите Вашу идею:"))
        self.label_4.setText(_translate("MainWindow", "Вложения:"))
        self.pushButton.setText(_translate("MainWindow", "Удалить последнее"))
        self.pushButton_2.setText(_translate("MainWindow", "Отправить"))
        self.pushButton_3.setText(
            _translate("MainWindow", "      Добавить вложение      "))



class Bigui(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(950, 630)
        MainWindow.setStyleSheet("background-color: rgb(224, 235, 250);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 14pt \"Arial\";\n"
"")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(0, 0, 949, 623))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.plainTextEdit = QtWidgets.QPlainTextEdit(self.verticalLayoutWidget)
        self.plainTextEdit.setStyleSheet("background-color: rgb(255, 255, 255);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 12pt \"Arial\";")
        self.plainTextEdit.setObjectName("plainTextEdit")
        self.verticalLayout.addWidget(self.plainTextEdit)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        self.horizontalLayout_2.addWidget(self.label_2)
        self.pushButton = QtWidgets.QPushButton(self.verticalLayoutWidget)
        self.pushButton.setStyleSheet("background-color: rgb(234, 234, 234);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 10pt \"Arial\";")
        self.pushButton.setObjectName("pushButton")
        self.horizontalLayout_2.addWidget(self.pushButton)
        self.label = QtWidgets.QLabel(self.verticalLayoutWidget)
        self.label.setText("")
        self.label.setObjectName("label")
        self.horizontalLayout_2.addWidget(self.label)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.plainTextEdit.setPlainText(_translate("MainWindow", "    Приложение \"Помощник учителя\" - online-приложение. Это означает , что Вы сможете получить\n"
"доступ к своим классам на любом устройстве, где будет установлено данное приложене и доступ\n"
"в интернет.\n"
"    При успешной авторизации появится основное окно программы. В его правом верхнем углу\n"
"расположены часы. С правой стороны расположен столбец из кнопок.\n"
"\n"
"Кнопка \"Открыть МЭШ\":\n"
"    Открывает в браузере страницу авторизации московского электроного журнала. Если в данном\n"
"    браузере были сохранёны логин и пароль от аккаунта МЭШ, то будет произведён вход в в аккаунт МЭШ\n"
"    с сохранёнными данными.\n"
"\n"
"Кнопка \"Выйти из аккаунта\":\n"
"    Производит выход из аккаунта и открывает окно авторизации.\n"
"\n"
"Кнопка \"Калькулятор\":\n"
"    Открывает калькулятор, установленный на операционной системе компьютера. Если открыть калькулятор\n"
"    не получится, появится сообщение, уведомляющее Вас об этом.\n"
"\n"
"Кнопка \"Mini Paint\":\n"
"    Открывает виртуальную графическую доску.\n"
"\n"
"Кнопка \"Напоминания\":\n"
"    Открывает окно \"Напоминания\". В этом окне можно создать и удалить напоминание. При создании напоминания\n"
"    необходимо указать дату, время и тему напоминания. По желанию можно указать текст напоминания. В назначенную\n"
"    дату и время на почту аккаунта прийдёт письмо, в теме каторого будет указано тема напоминания, а при наличии\n"
"    текста напоминания, письмо будет содержать этот текст.\n"
"\n"
"Кнопка \"Ссылки\":\n"
"    Открывает окно \"Ссылки\". В этом окне можно сохранить ссылку на нужный видеоурок или материал, указав\n"
"    при сохранении ссылки название , под которым она будет храниться, и саму ссылку. \n"
"\n"
"Кнопка \"Заметки\":\n"
"    Открывет окно \"Заметки\". В этом окне можно сохранить нужные Вам данные, если Вы боитесь их забыть.\n"
"    Для этого необходимо указать название заметки и её текст. \n"
"\n"
"Кнопка \"Продолжить\":\n"
"     Для её активации нужно выбрать хотя бы одного ученика из класса. После того, как хотя бы один из учеников\n"
"     был выбран и нажата кнопка \"Продолжить\", появится окно \"Рассылка\".  Для отправки писем достаточно ввести\n"
"     либо тему сообщения, либо текст сообщения, либо добавить вложения. Обратите внимание, что в одном письме\n"
"     можно отправть не более 5 вложений. Важная деталь - при открытии данного окна основное окно становится\n"
"     неактивным. Для активации основного окна необходимо закрыть окно рассылок (после окончания рассылки оно\n"
"     закроектся само).\n"
"     В вверху появившегося окна также находятся вкладки меню \"Создание документов\" и \"Просмотр досье\". Данные\n"
"     функции появятся в приложении с выходом ближайшего обновления. Поэтому эти вкладки пока что не выполняют\n"
"     никаких функций.\n"
"\n"
"    В верхней части основного окна находятся инструмента для настройки отображения класса. В поисковой сторке\n"
"\"Поиск ученика:\" можно ввести нужную подстроку, и в таблице останутся только те ученики, в чьих данных содержится\n"
"введённая подстрока. В меню \"Сортировать по:\" можно выбрать порядок отображения класса. Чекбоксы\n"
"\"Показывать в обратном порядке\" и \"выбрать всех\" изменяют порядок отображения классс и выделяют всех учеников\n"
"соответсвенно.\n"
"\n"
"    В меню \"Класс\" можно переключаться между классами, доступными в аккаунте.\n"
"\n"
"    Для упарвления доступными классами нужно нажать на меню \"Классы\". В появившемя окне можно добавить класс,\n"
"экспортировать выбранный класс в exel-таблицу или удалить его.\n"
"\n"
"    В меню \"Настройки\", выбрать пункт \"Аккаунт\" можно изменить никнейм, email и пароль. Так как для работы этого\n"
"окна необходимо подключение к базе данных, оно может загружаться немного дольше остальных окон.\n"
"\n"
"    В меню \"Настройки\", выбрать пункт \"Внешний вид\" можно изменить цветовую тему приложения, тип шрифта\n"
"и его размер.\n"
"\n"
"    В меню \"О программе\", выбрав пункт \"Общая информация\", можно посмотреть информацию о разработчиках\n"
"данного приложения и узанть, какими правами обладает пользователь по отношению к этой программе.\n"
"\n"
"    В меню \"О программе\", выбрав пункт \"Помощь в работе\", можно вызвать данное окно.\n"
"\n"
"    В меню \"О программе\", выбрав пункт \"Обратная связь\", можно предложить идею для улучшения\n"
"программы \"Помощник учиетля\", оставить отзыв об этой программе либо сообщить об ошибке в работе программы."))
        self.pushButton.setText(_translate("MainWindow", "Понятно"))

class Ac(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(489, 184)
        MainWindow.setStyleSheet("background-color: rgb(224, 235, 250);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 10pt \"Arial\";\n"
"")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayoutWidget_4 = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget_4.setGeometry(QtCore.QRect(10, 10, 471, 208))
        self.verticalLayoutWidget_4.setObjectName("verticalLayoutWidget_4")
        self.verticalLayout_4 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget_4)
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_4.setObjectName("verticalLayout_4")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label_2.setStyleSheet("background-color: rgb(224, 235, 250);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);\n"
"font: bold 11pt \"Arial\";")
        self.label_2.setObjectName("label_2")
        self.verticalLayout.addWidget(self.label_2)
        self.label_10 = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label_10.setStyleSheet("background-color: rgb(224, 235, 250);border-color: rgb(18, 18, 18);color: rgb(60, 170, 255);font: bold 8pt \"Arial\";\n"
"")
        self.label_10.setObjectName("label_10")
        self.verticalLayout.addWidget(self.label_10)
        self.label = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label.setStyleSheet("background-color: rgb(224, 235, 250);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);\n"
"font: bold 11pt \"Arial\";")
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)
        self.label_9 = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label_9.setStyleSheet("background-color: rgb(224, 235, 250);border-color: rgb(18, 18, 18);color: rgb(60, 170, 255);font: bold 8pt \"Arial\";\n"
"")
        self.label_9.setText("")
        self.label_9.setObjectName("label_9")
        self.verticalLayout.addWidget(self.label_9)
        self.label_3 = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label_3.setStyleSheet("background-color: rgb(224, 235, 250);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);\n"
"font: bold 11pt \"Arial\";")
        self.label_3.setObjectName("label_3")
        self.verticalLayout.addWidget(self.label_3)
        self.horizontalLayout.addLayout(self.verticalLayout)
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.lineEdit = QtWidgets.QLineEdit(self.verticalLayoutWidget_4)
        self.lineEdit.setStyleSheet("background-color: rgb(255, 255, 255);border-color: rgb(18, 18, 18);font: bold 10pt \"Arial\";\n"
"")
        self.lineEdit.setObjectName("lineEdit")
        self.verticalLayout_3.addWidget(self.lineEdit)
        self.label_8 = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label_8.setStyleSheet("background-color: rgb(224, 235, 250);border-color: rgb(18, 18, 18);color: rgb(60, 170, 255);font: bold 8pt \"Arial\";\n"
"")
        self.label_8.setObjectName("label_8")
        self.verticalLayout_3.addWidget(self.label_8)
        self.lineEdit_2 = QtWidgets.QLineEdit(self.verticalLayoutWidget_4)
        self.lineEdit_2.setStyleSheet("background-color: rgb(255, 255, 255);border-color: rgb(18, 18, 18);font: bold 10pt \"Arial\";\n"
"")
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.verticalLayout_3.addWidget(self.lineEdit_2)
        self.label_7 = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label_7.setStyleSheet("background-color: rgb(224, 235, 250);border-color: rgb(18, 18, 18);color: rgb(60, 170, 255);font: bold 8pt \"Arial\";\n"
"")
        self.label_7.setObjectName("label_7")
        self.verticalLayout_3.addWidget(self.label_7)
        self.pushButton_4 = QtWidgets.QPushButton(self.verticalLayoutWidget_4)
        self.pushButton_4.setStyleSheet("background-color: rgb(234, 234, 234);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 10pt \"Arial\";\n"
"")
        self.pushButton_4.setObjectName("pushButton_4")
        self.verticalLayout_3.addWidget(self.pushButton_4)
        self.horizontalLayout.addLayout(self.verticalLayout_3)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.pushButton = QtWidgets.QPushButton(self.verticalLayoutWidget_4)
        self.pushButton.setStyleSheet("background-color: rgb(234, 234, 234);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 10pt \"Arial\";\n"
"")
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout_2.addWidget(self.pushButton)
        self.label_5 = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label_5.setStyleSheet("background-color: rgb(224, 235, 250);border-color: rgb(18, 18, 18);color: rgb(60, 170, 255);font: bold 8pt \"Arial\";\n"
"")
        self.label_5.setObjectName("label_5")
        self.verticalLayout_2.addWidget(self.label_5)
        self.pushButton_2 = QtWidgets.QPushButton(self.verticalLayoutWidget_4)
        self.pushButton_2.setStyleSheet("background-color: rgb(234, 234, 234);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 10pt \"Arial\";\n"
"")
        self.pushButton_2.setObjectName("pushButton_2")
        self.verticalLayout_2.addWidget(self.pushButton_2)
        self.label_6 = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label_6.setStyleSheet("background-color: rgb(224, 235, 250);border-color: rgb(18, 18, 18);color: rgb(60, 170, 255);font: bold 8pt \"Arial\";\n"
"")
        self.label_6.setObjectName("label_6")
        self.verticalLayout_2.addWidget(self.label_6)
        self.pushButton_3 = QtWidgets.QPushButton(self.verticalLayoutWidget_4)
        self.pushButton_3.setStyleSheet("background-color: rgb(234, 234, 234);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 10pt \"Arial\";\n"
"")
        self.pushButton_3.setObjectName("pushButton_3")
        self.verticalLayout_2.addWidget(self.pushButton_3)
        self.horizontalLayout.addLayout(self.verticalLayout_2)
        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.verticalLayout_4.addLayout(self.horizontalLayout)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.label_4 = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label_4.setStyleSheet("background-color: rgb(224, 235, 250);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 8pt \"Arial\";\n"
"")
        self.label_4.setObjectName("label_4")
        self.horizontalLayout_2.addWidget(self.label_4)
        spacerItem2 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem2)
        self.verticalLayout_4.addLayout(self.horizontalLayout_2)
        spacerItem3 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_4.addItem(spacerItem3)
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label_2.setText(_translate("MainWindow", "Текущий никнейм:"))
        self.label_10.setText(_translate("MainWindow", " "))
        self.label.setText(_translate("MainWindow", "Текущий emai:        "))
        self.label_3.setText(_translate("MainWindow", "Текущий пароль:   "))
        self.label_8.setText(_translate("MainWindow", " "))
        self.label_7.setText(_translate("MainWindow", " "))
        self.pushButton_4.setText(_translate("MainWindow", "          Узанть          "))
        self.pushButton.setText(_translate("MainWindow", "Изменить"))
        self.label_5.setText(_translate("MainWindow", "Отмена"))
        self.pushButton_2.setText(_translate("MainWindow", "Изменить"))
        self.label_6.setText(_translate("MainWindow", "Отмена"))
        self.pushButton_3.setText(_translate("MainWindow", "Изменить"))
        self.label_4.setText(_translate("MainWindow", " нажав \"Узнать\", на email прийдёт письмо, в котором будет указан пароль"))


class Newslk(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(630, 345)
        MainWindow.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                 "border-color: rgb(18, 18, 18);\n"
                                 "color: rgb(81, 81, 255);\n"
                                 "font: bold 12pt \"Arial\";")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayoutWidget_3 = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget_3.setGeometry(QtCore.QRect(210, 8, 400, 340))
        self.verticalLayoutWidget_3.setObjectName("verticalLayoutWidget_3")
        self.verticalLayout_3 = QtWidgets.QVBoxLayout(
            self.verticalLayoutWidget_3)
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.horizontalLayout_11 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_11.setObjectName("horizontalLayout_11")
        self.label_4 = QtWidgets.QLabel(self.verticalLayoutWidget_3)
        self.label_4.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 12pt \"Arial\";")
        self.label_4.setObjectName("label_4")
        self.horizontalLayout_11.addWidget(self.label_4)
        spacerItem = QtWidgets.QSpacerItem(40, 20,
                                           QtWidgets.QSizePolicy.Expanding,
                                           QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_11.addItem(spacerItem)
        self.verticalLayout_3.addLayout(self.horizontalLayout_11)
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget_3)
        self.label_2.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 10pt \"Arial\";")
        self.label_2.setObjectName("label_2")
        self.horizontalLayout.addWidget(self.label_2)
        self.lineEdit = QtWidgets.QLineEdit(self.verticalLayoutWidget_3)
        self.lineEdit.setStyleSheet("background-color: rgb(255, 255, 255);\n"
                                    "border-color: rgb(18, 18, 18);\n"
                                    "color: rgb(81, 81, 255);\n"
                                    "font: bold 12pt \"Arial\";")
        self.lineEdit.setObjectName("lineEdit")
        self.horizontalLayout.addWidget(self.lineEdit)
        spacerItem1 = QtWidgets.QSpacerItem(40, 20,
                                            QtWidgets.QSizePolicy.Expanding,
                                            QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        spacerItem2 = QtWidgets.QSpacerItem(40, 20,
                                            QtWidgets.QSizePolicy.Expanding,
                                            QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem2)
        spacerItem3 = QtWidgets.QSpacerItem(40, 20,
                                            QtWidgets.QSizePolicy.Expanding,
                                            QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem3)
        spacerItem4 = QtWidgets.QSpacerItem(40, 20,
                                            QtWidgets.QSizePolicy.Expanding,
                                            QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem4)
        self.verticalLayout_2.addLayout(self.horizontalLayout)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.label_3 = QtWidgets.QLabel(self.verticalLayoutWidget_3)
        self.label_3.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 10pt \"Arial\";")
        self.label_3.setObjectName("label_3")
        self.horizontalLayout_2.addWidget(self.label_3)
        self.comboBox = QtWidgets.QComboBox(self.verticalLayoutWidget_3)
        self.comboBox.setStyleSheet("font: 10pt \"Arial\";\n"
                                    "background-color: rgb(255, 255, 255);\n"
                                    "color: rgb(81, 81, 255);\n"
                                    "font: bold 10pt \"Arial\";")
        self.comboBox.setObjectName("comboBox")
        self.comboBox.addItem("дате и времени")
        self.comboBox.addItem("названию")
        self.comboBox.addItem("дате и времени (R)")
        self.comboBox.addItem("названию (R)")
        self.horizontalLayout_2.addWidget(self.comboBox)
        self.checkBox = QtWidgets.QCheckBox(self.verticalLayoutWidget_3)
        self.checkBox.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                    "border-color: rgb(18, 18, 18);\n"
                                    "color: rgb(81, 81, 255);\n"
                                    "font: bold 10pt \"Arial\";")
        self.checkBox.setObjectName("checkBox")
        self.horizontalLayout_2.addWidget(self.checkBox)
        spacerItem5 = QtWidgets.QSpacerItem(40, 20,
                                            QtWidgets.QSizePolicy.Expanding,
                                            QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem5)
        self.verticalLayout_2.addLayout(self.horizontalLayout_2)
        self.verticalLayout_3.addLayout(self.verticalLayout_2)
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.tableWidget = QtWidgets.QTableWidget(self.verticalLayoutWidget_3)
        self.tableWidget.setStyleSheet(
            "background-color: rgb(255, 255, 255);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 8pt \"Arial\";")
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(4)
        self.tableWidget.setRowCount(0)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(3, item)
        self.verticalLayout.addWidget(self.tableWidget)
        self.pushButton = QtWidgets.QPushButton(self.verticalLayoutWidget_3)
        self.pushButton.setStyleSheet("background-color: rgb(234, 234, 234);\n"
                                      "border-color: rgb(18, 18, 18);\n"
                                      "color: rgb(81, 81, 255);\n"
                                      "font: bold 10pt \"Arial\";")
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout.addWidget(self.pushButton)
        self.pushButton_2 = QtWidgets.QPushButton(self.verticalLayoutWidget_3)
        self.pushButton_2.setStyleSheet(
            "background-color: rgb(234, 234, 234);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 10pt \"Arial\";")
        self.pushButton_2.setObjectName("pushButton_2")
        self.verticalLayout.addWidget(self.pushButton_2)
        self.verticalLayout_3.addLayout(self.verticalLayout)
        self.verticalLayoutWidget_4 = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget_4.setGeometry(QtCore.QRect(10, 10, 192, 321))
        self.verticalLayoutWidget_4.setObjectName("verticalLayoutWidget_4")
        self.verticalLayout_4 = QtWidgets.QVBoxLayout(
            self.verticalLayoutWidget_4)
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_4.setObjectName("verticalLayout_4")
        self.label_6 = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label_6.setObjectName("label_6")
        self.verticalLayout_4.addWidget(self.label_6)
        self.verticalLayout_9 = QtWidgets.QVBoxLayout()
        self.verticalLayout_9.setObjectName("verticalLayout_9")
        self.verticalLayout_6 = QtWidgets.QVBoxLayout()
        self.verticalLayout_6.setObjectName("verticalLayout_6")
        self.verticalLayout_5 = QtWidgets.QVBoxLayout()
        self.verticalLayout_5.setObjectName("verticalLayout_5")
        spacerItem6 = QtWidgets.QSpacerItem(20, 40,
                                            QtWidgets.QSizePolicy.Minimum,
                                            QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_5.addItem(spacerItem6)
        self.label = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                 "border-color: rgb(18, 18, 18);\n"
                                 "color: rgb(81, 81, 255);\n"
                                 "font: bold 10pt \"Arial\";")
        self.label.setObjectName("label")
        self.verticalLayout_5.addWidget(self.label)
        self.lineEdit_3 = QtWidgets.QLineEdit(self.verticalLayoutWidget_4)
        self.lineEdit_3.setStyleSheet("background-color: rgb(255, 255, 255);\n"
                                      "border-color: rgb(18, 18, 18);\n"
                                      "color: rgb(81, 81, 255);\n"
                                      "font: bold 12pt \"Arial\";")
        self.lineEdit_3.setObjectName("lineEdit_3")
        self.verticalLayout_5.addWidget(self.lineEdit_3)
        self.verticalLayout_6.addLayout(self.verticalLayout_5)
        spacerItem7 = QtWidgets.QSpacerItem(20, 40,
                                            QtWidgets.QSizePolicy.Minimum,
                                            QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_6.addItem(spacerItem7)
        self.label_5 = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label_5.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 10pt \"Arial\";")
        self.label_5.setObjectName("label_5")
        self.verticalLayout_6.addWidget(self.label_5)
        self.lineEdit_2 = QtWidgets.QLineEdit(self.verticalLayoutWidget_4)
        self.lineEdit_2.setStyleSheet("background-color: rgb(255, 255, 255);\n"
                                      "border-color: rgb(18, 18, 18);\n"
                                      "color: rgb(81, 81, 255);\n"
                                      "font: bold 12pt \"Arial\";")
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.verticalLayout_6.addWidget(self.lineEdit_2)
        spacerItem8 = QtWidgets.QSpacerItem(20, 40,
                                            QtWidgets.QSizePolicy.Minimum,
                                            QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_6.addItem(spacerItem8)
        self.verticalLayout_9.addLayout(self.verticalLayout_6)
        self.pushButton_3 = QtWidgets.QPushButton(self.verticalLayoutWidget_4)
        self.pushButton_3.setStyleSheet(
            "background-color: rgb(234, 234, 234);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 10pt \"Arial\";")
        self.pushButton_3.setObjectName("pushButton_3")
        self.verticalLayout_9.addWidget(self.pushButton_3)
        spacerItem9 = QtWidgets.QSpacerItem(20, 40,
                                            QtWidgets.QSizePolicy.Minimum,
                                            QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_9.addItem(spacerItem9)
        self.verticalLayout_4.addLayout(self.verticalLayout_9)
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label_4.setText(_translate("MainWindow", "Доступные ссылки:"))
        self.label_2.setText(_translate("MainWindow", "Поиск ссылки:"))
        self.label_3.setText(_translate("MainWindow", "Сортировать по:"))
        self.checkBox.setText(_translate("MainWindow", "Выбрать все"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "Выбрать"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "Название"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "Добавлена"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "Ссылка"))
        self.pushButton.setText(_translate("MainWindow", "Открыть выбранные"))
        self.pushButton_2.setText(
            _translate("MainWindow", "Удалить выбранные"))
        self.label_6.setText(_translate("MainWindow", "Добавление ссылки:"))
        self.label.setText(_translate("MainWindow", "Название ссылки:"))
        self.label_5.setText(_translate("MainWindow", "Ссылка:"))
        self.pushButton_3.setText(_translate("MainWindow", "Добавить ссылку"))

class Nzui(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(560, 400)
        MainWindow.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                 "border-color: rgb(18, 18, 18);\n"
                                 "color: rgb(81, 81, 255);\n"
                                 "font: bold 12pt \"Arial\";")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.horizontalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.horizontalLayoutWidget.setGeometry(QtCore.QRect(10, 10, 540, 370))
        self.horizontalLayoutWidget.setObjectName("horizontalLayoutWidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(
            self.horizontalLayoutWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setSpacing(10)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.label_2 = QtWidgets.QLabel(self.horizontalLayoutWidget)
        self.label_2.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 12pt \"Arial\";")
        self.label_2.setObjectName("label_2")
        self.verticalLayout.addWidget(self.label_2)
        self.lineEdit = QtWidgets.QLineEdit(self.horizontalLayoutWidget)
        self.lineEdit.setStyleSheet("background-color: rgb(255, 255, 255);\n"
                                    "border-color: rgb(18, 18, 18);\n"
                                    "color: rgb(81, 81, 255);\n"
                                    "font: bold 12pt \"Arial\";\n"
                                    "")
        self.lineEdit.setObjectName("lineEdit")
        self.verticalLayout.addWidget(self.lineEdit)
        self.label = QtWidgets.QLabel(self.horizontalLayoutWidget)
        self.label.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                 "border-color: rgb(18, 18, 18);\n"
                                 "color: rgb(81, 81, 255);\n"
                                 "font: bold 12pt \"Arial\";")
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)
        self.plainTextEdit = QtWidgets.QPlainTextEdit(
            self.horizontalLayoutWidget)
        self.plainTextEdit.setStyleSheet(
            "background-color: rgb(255, 255, 255);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 12pt \"Arial\";")
        self.plainTextEdit.setObjectName("plainTextEdit")
        self.verticalLayout.addWidget(self.plainTextEdit)
        self.pushButton_2 = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.pushButton_2.setStyleSheet(
            "background-color: rgb(234, 234, 234);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 10pt \"Arial\";")
        self.pushButton_2.setObjectName("pushButton_2")
        self.verticalLayout.addWidget(self.pushButton_2)
        self.horizontalLayout.addLayout(self.verticalLayout)
        spacerItem = QtWidgets.QSpacerItem(40, 20,
                                           QtWidgets.QSizePolicy.Expanding,
                                           QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.label_3 = QtWidgets.QLabel(self.horizontalLayoutWidget)
        self.label_3.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 12pt \"Arial\";")
        self.label_3.setObjectName("label_3")
        self.verticalLayout_2.addWidget(self.label_3)
        self.horizontalLayout_4 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        self.verticalLayout_2.addLayout(self.horizontalLayout_4)
        self.verticalLayout_4 = QtWidgets.QVBoxLayout()
        self.verticalLayout_4.setObjectName("verticalLayout_4")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.label_5 = QtWidgets.QLabel(self.horizontalLayoutWidget)
        self.label_5.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 9pt \"Arial\";")
        self.label_5.setObjectName("label_5")
        self.horizontalLayout_2.addWidget(self.label_5)
        self.lineEdit_2 = QtWidgets.QLineEdit(self.horizontalLayoutWidget)
        self.lineEdit_2.setStyleSheet("background-color: rgb(255, 255, 255);\n"
                                      "border-color: rgb(18, 18, 18);\n"
                                      "color: rgb(81, 81, 255);\n"
                                      "font: bold 11pt \"Arial\";")
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.horizontalLayout_2.addWidget(self.lineEdit_2)
        spacerItem1 = QtWidgets.QSpacerItem(40, 20,
                                            QtWidgets.QSizePolicy.Expanding,
                                            QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem1)
        self.verticalLayout_4.addLayout(self.horizontalLayout_2)
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.label_4 = QtWidgets.QLabel(self.horizontalLayoutWidget)
        self.label_4.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 9pt \"Arial\";")
        self.label_4.setObjectName("label_4")
        self.horizontalLayout_3.addWidget(self.label_4)
        self.comboBox = QtWidgets.QComboBox(self.horizontalLayoutWidget)
        self.comboBox.setStyleSheet("font: 10pt \"Arial\";\n"
                                    "background-color: rgb(255, 255, 255);\n"
                                    "color: rgb(81, 81, 255);\n"
                                    "font: bold 10pt \"Arial\";")
        self.comboBox.setObjectName("comboBox")
        self.comboBox.addItem('теме')
        self.comboBox.addItem('теме (R)')
        self.horizontalLayout_3.addWidget(self.comboBox)
        self.checkBox = QtWidgets.QCheckBox(self.horizontalLayoutWidget)
        self.checkBox.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                    "border-color: rgb(18, 18, 18);\n"
                                    "color: rgb(81, 81, 255);\n"
                                    "font: bold 9pt \"Arial\";\n"
                                    "")
        self.checkBox.setObjectName("checkBox")
        self.horizontalLayout_3.addWidget(self.checkBox)
        spacerItem2 = QtWidgets.QSpacerItem(40, 20,
                                            QtWidgets.QSizePolicy.Expanding,
                                            QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem2)
        self.verticalLayout_4.addLayout(self.horizontalLayout_3)
        self.verticalLayout_2.addLayout(self.verticalLayout_4)
        self.tableWidget = QtWidgets.QTableWidget(self.horizontalLayoutWidget)
        self.tableWidget.setStyleSheet(
            "background-color: rgb(255, 255, 255);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 8pt \"Arial\";")
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(3)
        self.tableWidget.setRowCount(0)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, item)
        self.verticalLayout_2.addWidget(self.tableWidget)
        self.pushButton_3 = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.pushButton_3.setStyleSheet(
            "background-color: rgb(234, 234, 234);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 10pt \"Arial\";")
        self.pushButton_3.setObjectName("pushButton_3")
        self.verticalLayout_2.addWidget(self.pushButton_3)
        self.pushButton = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.pushButton.setStyleSheet("background-color: rgb(234, 234, 234);\n"
                                      "border-color: rgb(18, 18, 18);\n"
                                      "color: rgb(81, 81, 255);\n"
                                      "font: bold 10pt \"Arial\";")
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout_2.addWidget(self.pushButton)
        self.horizontalLayout.addLayout(self.verticalLayout_2)
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label_2.setText(_translate("MainWindow", "Тема заметки:"))
        self.label.setText(_translate("MainWindow", "Текст заметки:"))
        self.pushButton_2.setText(_translate("MainWindow", "Добавить заметку"))
        self.label_3.setText(_translate("MainWindow", "Доступные заметки:"))
        self.label_5.setText(_translate("MainWindow", "Поиск заметки:"))
        self.label_4.setText(_translate("MainWindow", "Сортировать по:"))
        self.checkBox.setText(_translate("MainWindow", "Выбрать все"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "Выделить все"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "Тема заметки"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "Заметка"))
        self.pushButton_3.setText(
            _translate("MainWindow", "Посмотреть выделенные"))
        self.pushButton.setText(_translate("MainWindow", "Удалить выбранные"))

class Ex(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(857, 619)
        MainWindow.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 12pt \"Arial\";")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.horizontalLayoutWidget_4 = QtWidgets.QWidget(self.centralwidget)
        self.horizontalLayoutWidget_4.setGeometry(QtCore.QRect(10, 10, 531, 444))
        self.horizontalLayoutWidget_4.setObjectName("horizontalLayoutWidget_4")
        self.horizontalLayout_4 = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget_4)
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        self.verticalLayout_5 = QtWidgets.QVBoxLayout()
        self.verticalLayout_5.setObjectName("verticalLayout_5")
        self.label_4 = QtWidgets.QLabel(self.horizontalLayoutWidget_4)
        self.label_4.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 12pt \"Arial\";")
        self.label_4.setObjectName("label_4")
        self.verticalLayout_5.addWidget(self.label_4)
        self.tableWidget = QtWidgets.QTableWidget(self.horizontalLayoutWidget_4)
        self.tableWidget.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 8pt \"Arial\";")
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(2)
        self.tableWidget.setRowCount(0)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, item)
        self.verticalLayout_5.addWidget(self.tableWidget)
        self.horizontalLayout_4.addLayout(self.verticalLayout_5)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem)
        self.verticalLayout_7 = QtWidgets.QVBoxLayout()
        self.verticalLayout_7.setObjectName("verticalLayout_7")
        self.verticalLayout_6 = QtWidgets.QVBoxLayout()
        self.verticalLayout_6.setObjectName("verticalLayout_6")
        self.verticalLayout_8 = QtWidgets.QVBoxLayout()
        self.verticalLayout_8.setObjectName("verticalLayout_8")
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.label_3 = QtWidgets.QLabel(self.horizontalLayoutWidget_4)
        self.label_3.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 12pt \"Arial\";")
        self.label_3.setObjectName("label_3")
        self.verticalLayout_3.addWidget(self.label_3)
        self.verticalLayout_8.addLayout(self.verticalLayout_3)
        self.horizontalLayout_7 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_7.setObjectName("horizontalLayout_7")
        self.label_5 = QtWidgets.QLabel(self.horizontalLayoutWidget_4)
        self.label_5.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 10pt \"Arial\";")
        self.label_5.setObjectName("label_5")
        self.horizontalLayout_7.addWidget(self.label_5)
        self.lineEdit_2 = QtWidgets.QLineEdit(self.horizontalLayoutWidget_4)
        self.lineEdit_2.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 12pt \"Arial\";")
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.horizontalLayout_7.addWidget(self.lineEdit_2)
        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_7.addItem(spacerItem1)
        spacerItem2 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_7.addItem(spacerItem2)
        self.verticalLayout_8.addLayout(self.horizontalLayout_7)
        self.horizontalLayout_9 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_9.setObjectName("horizontalLayout_9")
        self.verticalLayout_8.addLayout(self.horizontalLayout_9)
        self.horizontalLayout_10 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_10.setObjectName("horizontalLayout_10")
        self.label_10 = QtWidgets.QLabel(self.horizontalLayoutWidget_4)
        self.label_10.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 10pt \"Arial\";")
        self.label_10.setObjectName("label_10")
        self.horizontalLayout_10.addWidget(self.label_10)
        self.pushButton_4 = QtWidgets.QPushButton(self.horizontalLayoutWidget_4)
        self.pushButton_4.setStyleSheet("background-color: rgb(234, 234, 234);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 9pt \"Arial\";")
        self.pushButton_4.setObjectName("pushButton_4")
        self.horizontalLayout_10.addWidget(self.pushButton_4)
        self.label_11 = QtWidgets.QLabel(self.horizontalLayoutWidget_4)
        self.label_11.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 9pt \"Arial\";")
        self.label_11.setText("")
        self.label_11.setObjectName("label_11")
        self.horizontalLayout_10.addWidget(self.label_11)
        self.verticalLayout_8.addLayout(self.horizontalLayout_10)
        self.horizontalLayout_8 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_8.setObjectName("horizontalLayout_8")
        self.label_9 = QtWidgets.QLabel(self.horizontalLayoutWidget_4)
        self.label_9.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 10pt \"Arial\";")
        self.label_9.setObjectName("label_9")
        self.horizontalLayout_8.addWidget(self.label_9)
        self.radioButton_5 = QtWidgets.QRadioButton(self.horizontalLayoutWidget_4)
        self.radioButton_5.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 9pt \"Arial\";")
        self.radioButton_5.setObjectName("radioButton_5")
        self.horizontalLayout_8.addWidget(self.radioButton_5)
        spacerItem3 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_8.addItem(spacerItem3)
        self.radioButton_6 = QtWidgets.QRadioButton(self.horizontalLayoutWidget_4)
        self.radioButton_6.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 9pt \"Arial\";")
        self.radioButton_6.setObjectName("radioButton_6")
        self.horizontalLayout_8.addWidget(self.radioButton_6)
        spacerItem4 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_8.addItem(spacerItem4)
        self.verticalLayout_8.addLayout(self.horizontalLayout_8)
        self.pushButton_3 = QtWidgets.QPushButton(self.horizontalLayoutWidget_4)
        self.pushButton_3.setStyleSheet("background-color: rgb(234, 234, 234);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 10pt \"Arial\";")
        self.pushButton_3.setObjectName("pushButton_3")
        self.verticalLayout_8.addWidget(self.pushButton_3)
        spacerItem5 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_8.addItem(spacerItem5)
        self.verticalLayout_6.addLayout(self.verticalLayout_8)
        self.label_7 = QtWidgets.QLabel(self.horizontalLayoutWidget_4)
        self.label_7.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 12pt \"Arial\";")
        self.label_7.setObjectName("label_7")
        self.verticalLayout_6.addWidget(self.label_7)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.label = QtWidgets.QLabel(self.horizontalLayoutWidget_4)
        self.label.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 10pt \"Arial\";")
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)
        spacerItem6 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem6)
        self.radioButton = QtWidgets.QRadioButton(self.horizontalLayoutWidget_4)
        self.radioButton.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 9pt \"Arial\";")
        self.radioButton.setObjectName("radioButton")
        self.verticalLayout.addWidget(self.radioButton)
        self.radioButton_2 = QtWidgets.QRadioButton(self.horizontalLayoutWidget_4)
        self.radioButton_2.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 9pt \"Arial\";")
        self.radioButton_2.setObjectName("radioButton_2")
        self.verticalLayout.addWidget(self.radioButton_2)
        spacerItem7 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem7)
        self.horizontalLayout.addLayout(self.verticalLayout)
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.label_2 = QtWidgets.QLabel(self.horizontalLayoutWidget_4)
        self.label_2.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 10pt \"Arial\";")
        self.label_2.setObjectName("label_2")
        self.verticalLayout_2.addWidget(self.label_2)
        spacerItem8 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_2.addItem(spacerItem8)
        self.radioButton_3 = QtWidgets.QRadioButton(self.horizontalLayoutWidget_4)
        self.radioButton_3.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 9pt \"Arial\";")
        self.radioButton_3.setObjectName("radioButton_3")
        self.verticalLayout_2.addWidget(self.radioButton_3)
        self.radioButton_4 = QtWidgets.QRadioButton(self.horizontalLayoutWidget_4)
        self.radioButton_4.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 9pt \"Arial\";")
        self.radioButton_4.setObjectName("radioButton_4")
        self.verticalLayout_2.addWidget(self.radioButton_4)
        spacerItem9 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_2.addItem(spacerItem9)
        self.horizontalLayout.addLayout(self.verticalLayout_2)
        self.verticalLayout_6.addLayout(self.horizontalLayout)
        spacerItem10 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_6.addItem(spacerItem10)
        self.horizontalLayout_5 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_5.setObjectName("horizontalLayout_5")
        self.pushButton = QtWidgets.QPushButton(self.horizontalLayoutWidget_4)
        self.pushButton.setStyleSheet("background-color: rgb(234, 234, 234);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 10pt \"Arial\";")
        self.pushButton.setObjectName("pushButton")
        self.horizontalLayout_5.addWidget(self.pushButton)
        self.verticalLayout_6.addLayout(self.horizontalLayout_5)
        spacerItem11 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_6.addItem(spacerItem11)
        spacerItem12 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_6.addItem(spacerItem12)
        self.verticalLayout_4 = QtWidgets.QVBoxLayout()
        self.verticalLayout_4.setObjectName("verticalLayout_4")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.label_8 = QtWidgets.QLabel(self.horizontalLayoutWidget_4)
        self.label_8.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 12pt \"Arial\";")
        self.label_8.setObjectName("label_8")
        self.horizontalLayout_2.addWidget(self.label_8)
        self.verticalLayout_4.addLayout(self.horizontalLayout_2)
        spacerItem13 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_4.addItem(spacerItem13)
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.label_6 = QtWidgets.QLabel(self.horizontalLayoutWidget_4)
        self.label_6.setStyleSheet("background-color: rgb(224, 235, 250);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 10pt \"Arial\";")
        self.label_6.setObjectName("label_6")
        self.horizontalLayout_3.addWidget(self.label_6)
        self.lineEdit = QtWidgets.QLineEdit(self.horizontalLayoutWidget_4)
        self.lineEdit.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 12pt \"Arial\";")
        self.lineEdit.setObjectName("lineEdit")
        self.horizontalLayout_3.addWidget(self.lineEdit)
        spacerItem14 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem14)
        spacerItem15 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem15)
        self.verticalLayout_4.addLayout(self.horizontalLayout_3)
        spacerItem16 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_4.addItem(spacerItem16)
        self.horizontalLayout_6 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_6.setObjectName("horizontalLayout_6")
        self.pushButton_2 = QtWidgets.QPushButton(self.horizontalLayoutWidget_4)
        self.pushButton_2.setStyleSheet("background-color: rgb(234, 234, 234);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(81, 81, 255);\n"
"font: bold 10pt \"Arial\";")
        self.pushButton_2.setObjectName("pushButton_2")
        self.horizontalLayout_6.addWidget(self.pushButton_2)
        self.verticalLayout_4.addLayout(self.horizontalLayout_6)
        self.verticalLayout_6.addLayout(self.verticalLayout_4)
        self.verticalLayout_7.addLayout(self.verticalLayout_6)
        self.horizontalLayout_4.addLayout(self.verticalLayout_7)
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label_4.setText(_translate("MainWindow", "Доступные классы:"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "Выбрать"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "Класс"))
        self.label_3.setText(_translate("MainWindow", "Добавление класса:"))
        self.label_5.setText(_translate("MainWindow", "Название класса:"))
        self.label_10.setText(_translate("MainWindow", "Файл с данными:"))
        self.pushButton_4.setText(_translate("MainWindow", "Выбрать"))
        self.label_9.setText(_translate("MainWindow", "Шапка докумета:"))
        self.radioButton_5.setText(_translate("MainWindow", "Нет"))
        self.radioButton_6.setText(_translate("MainWindow", "Есть"))
        self.pushButton_3.setText(_translate("MainWindow", "Добавить класс"))
        self.label_7.setText(_translate("MainWindow", "Экспорт класса:"))
        self.label.setText(_translate("MainWindow", "Создать шапку класса?"))
        self.radioButton.setText(_translate("MainWindow", "Не создавать"))
        self.radioButton_2.setText(_translate("MainWindow", "Создать"))
        self.label_2.setText(_translate("MainWindow", "Название файла:"))
        self.radioButton_3.setText(_translate("MainWindow", "Текущее"))
        self.radioButton_4.setText(_translate("MainWindow", "Новое (не введено)"))
        self.pushButton.setText(_translate("MainWindow", "Экспортировать выбранный класс"))
        self.label_8.setText(_translate("MainWindow", "Удаление класса:"))
        self.label_6.setText(_translate("MainWindow", "Пароль от аккаунта:"))
        self.pushButton_2.setText(_translate("MainWindow", "Удалить выбранный класс"))


class W2(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(398, 161)
        MainWindow.setStyleSheet("background-color: rgb(224, 235, 250);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 10pt \"Arial\";\n"
"")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayoutWidget_4 = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget_4.setGeometry(QtCore.QRect(0, 10, 400, 138))
        self.verticalLayoutWidget_4.setObjectName("verticalLayoutWidget_4")
        self.verticalLayout_5 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget_4)
        self.verticalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_5.setObjectName("verticalLayout_5")
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_5.addItem(spacerItem)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem1)
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.label_3 = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label_3.setStyleSheet("background-color: rgb(224, 235, 250);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);\n"
"font: bold 11pt \"Arial\";")
        self.label_3.setObjectName("label_3")
        self.verticalLayout_2.addWidget(self.label_3)
        self.label = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label.setObjectName("label")
        self.verticalLayout_2.addWidget(self.label)
        spacerItem2 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_2.addItem(spacerItem2)
        self.pushButton = QtWidgets.QPushButton(self.verticalLayoutWidget_4)
        self.pushButton.setStyleSheet("background-color: rgb(234, 234, 234);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 10pt \"Arial\";\n"
"")
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout_2.addWidget(self.pushButton)
        spacerItem3 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_2.addItem(spacerItem3)
        self.horizontalLayout_2.addLayout(self.verticalLayout_2)
        spacerItem4 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem4)
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.label_4 = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label_4.setStyleSheet("background-color: rgb(224, 235, 250);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);""font: bold 11pt \"Arial\";")
        self.label_4.setObjectName("label_4")
        self.verticalLayout_3.addWidget(self.label_4)
        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label_2.setObjectName("label_2")
        self.verticalLayout_3.addWidget(self.label_2)
        spacerItem5 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem5)
        self.pushButton_2 = QtWidgets.QPushButton(self.verticalLayoutWidget_4)
        self.pushButton_2.setStyleSheet("background-color: rgb(234, 234, 234);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 10pt \"Arial\";\n"
"")
        self.pushButton_2.setObjectName("pushButton_2")
        self.verticalLayout_3.addWidget(self.pushButton_2)
        spacerItem6 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem6)
        self.horizontalLayout_2.addLayout(self.verticalLayout_3)
        spacerItem7 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem7)
        self.verticalLayout_4 = QtWidgets.QVBoxLayout()
        self.verticalLayout_4.setObjectName("verticalLayout_4")
        self.label_5 = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label_5.setStyleSheet("background-color: rgb(224, 235, 250);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);\n"
"font: bold 11pt \"Arial\";")
        self.label_5.setObjectName("label_5")
        self.verticalLayout_4.addWidget(self.label_5)
        self.label_6 = QtWidgets.QLabel(self.verticalLayoutWidget_4)
        self.label_6.setObjectName("label_6")
        self.verticalLayout_4.addWidget(self.label_6)
        spacerItem8 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_4.addItem(spacerItem8)
        self.pushButton_3 = QtWidgets.QPushButton(self.verticalLayoutWidget_4)
        self.pushButton_3.setStyleSheet("background-color: rgb(234, 234, 234);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 10pt \"Arial\";\n"
"")
        self.pushButton_3.setObjectName("pushButton_3")
        self.verticalLayout_4.addWidget(self.pushButton_3)
        spacerItem9 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_4.addItem(spacerItem9)
        self.horizontalLayout_2.addLayout(self.verticalLayout_4)
        spacerItem10 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem10)
        self.verticalLayout_5.addLayout(self.horizontalLayout_2)
        spacerItem11 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_5.addItem(spacerItem11)
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        spacerItem12 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem12)
        spacerItem13 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem13)
        self.pushButton_5 = QtWidgets.QPushButton(self.verticalLayoutWidget_4)
        self.pushButton_5.setStyleSheet("background-color: rgb(234, 234, 234);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 10pt \"Arial\";\n"
"")
        self.pushButton_5.setObjectName("pushButton_5")
        self.horizontalLayout_3.addWidget(self.pushButton_5)
        spacerItem14 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem14)
        self.pushButton_6 = QtWidgets.QPushButton(self.verticalLayoutWidget_4)
        self.pushButton_6.setStyleSheet("background-color: rgb(234, 234, 234);border-color: rgb(18, 18, 18);color: rgb(81, 81, 255);font: bold 10pt \"Arial\";\n"
"")
        self.pushButton_6.setObjectName("pushButton_6")
        self.horizontalLayout_3.addWidget(self.pushButton_6)
        spacerItem15 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem15)
        spacerItem16 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem16)
        self.verticalLayout_5.addLayout(self.horizontalLayout_3)
        spacerItem17 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_5.addItem(spacerItem17)
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label_3.setText(_translate("MainWindow", "Цвет окон:"))
        self.label.setText(_translate("MainWindow", "          "))
        self.pushButton.setText(_translate("MainWindow", "Изменить"))
        self.label_4.setText(_translate("MainWindow", "Цвет кнопок:"))
        self.label_2.setText(_translate("MainWindow", "          "))
        self.pushButton_2.setText(_translate("MainWindow", "Изменить"))
        self.label_5.setText(_translate("MainWindow", "Цвет текста:"))
        self.label_6.setText(_translate("MainWindow", "          "))
        self.pushButton_3.setText(_translate("MainWindow", "Изменить"))
        self.pushButton_5.setText(_translate("MainWindow", "Протестировать сочетание"))
        self.pushButton_6.setText(_translate("MainWindow", "   Применить сочетание  "))


class Test2(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(434, 227)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.horizontalLayoutWidget_2 = QtWidgets.QWidget(self.centralwidget)
        self.horizontalLayoutWidget_2.setGeometry(QtCore.QRect(10, 0, 411, 221))
        self.horizontalLayoutWidget_2.setObjectName("horizontalLayoutWidget_2")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget_2)
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.verticalLayout_4 = QtWidgets.QVBoxLayout()
        self.verticalLayout_4.setObjectName("verticalLayout_4")
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_4.addItem(spacerItem)
        self.label = QtWidgets.QLabel(self.horizontalLayoutWidget_2)
        self.label.setObjectName("label")
        self.verticalLayout_4.addWidget(self.label)
        spacerItem1 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_4.addItem(spacerItem1)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label_2 = QtWidgets.QLabel(self.horizontalLayoutWidget_2)
        self.label_2.setObjectName("label_2")
        self.horizontalLayout.addWidget(self.label_2)
        spacerItem2 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem2)
        spacerItem3 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem3)
        self.lineEdit = QtWidgets.QLineEdit(self.horizontalLayoutWidget_2)
        self.lineEdit.setObjectName("lineEdit")
        self.horizontalLayout.addWidget(self.lineEdit)
        self.verticalLayout_4.addLayout(self.horizontalLayout)
        spacerItem4 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_4.addItem(spacerItem4)
        self.pushButton_4 = QtWidgets.QPushButton(self.horizontalLayoutWidget_2)
        self.pushButton_4.setObjectName("pushButton_4")
        self.verticalLayout_4.addWidget(self.pushButton_4)
        spacerItem5 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_4.addItem(spacerItem5)
        self.horizontalLayout_2.addLayout(self.verticalLayout_4)
        spacerItem6 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem6)
        spacerItem7 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem7)
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.checkBox = QtWidgets.QCheckBox(self.horizontalLayoutWidget_2)
        self.checkBox.setObjectName("checkBox")
        self.horizontalLayout_3.addWidget(self.checkBox)
        self.label_3 = QtWidgets.QLabel(self.horizontalLayoutWidget_2)
        self.label_3.setObjectName("label_3")
        self.horizontalLayout_3.addWidget(self.label_3)
        self.verticalLayout_2.addLayout(self.horizontalLayout_3)
        self.tableWidget = QtWidgets.QTableWidget(self.horizontalLayoutWidget_2)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(2)
        self.tableWidget.setRowCount(0)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, item)
        self.verticalLayout_2.addWidget(self.tableWidget)
        self.verticalLayout_3.addLayout(self.verticalLayout_2)
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.radioButton = QtWidgets.QRadioButton(self.horizontalLayoutWidget_2)
        self.radioButton.setObjectName("radioButton")
        self.verticalLayout.addWidget(self.radioButton)
        self.radioButton_2 = QtWidgets.QRadioButton(self.horizontalLayoutWidget_2)
        self.radioButton_2.setObjectName("radioButton_2")
        self.verticalLayout.addWidget(self.radioButton_2)
        self.verticalLayout_3.addLayout(self.verticalLayout)
        self.horizontalLayout_2.addLayout(self.verticalLayout_3)
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "Какая-то надпись:"))
        self.label_2.setText(_translate("MainWindow", "Поле ввода:"))
        self.pushButton_4.setText(_translate("MainWindow", "Кнопка"))
        self.checkBox.setText(_translate("MainWindow", "Чек-бокс"))
        self.label_3.setText(_translate("MainWindow", "Таблица"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "Таблица"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "Данные"))
        self.radioButton.setText(_translate("MainWindow", "Радио-кнопка 1"))
        self.radioButton_2.setText(_translate("MainWindow", "Радио-кнопка 2"))

class ColorClass(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(410, 150)
        MainWindow.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                 "border-color: rgb(18, 18, 18);\n"
                                 "color: rgb(81, 81, 255);\n"
                                 "font: bold 12pt \"Arial\";")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.horizontalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.horizontalLayoutWidget.setGeometry(QtCore.QRect(10, 10, 393, 136))
        self.horizontalLayoutWidget.setObjectName("horizontalLayoutWidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(
            self.horizontalLayoutWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.label = QtWidgets.QLabel(self.horizontalLayoutWidget)
        self.label.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                 "border-color: rgb(18, 18, 18);\n"
                                 "color: rgb(81, 81, 255);\n"
                                 "font: bold 11pt \"Arial\";")
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)
        spacerItem = QtWidgets.QSpacerItem(20, 40,
                                           QtWidgets.QSizePolicy.Minimum,
                                           QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.radioButton = QtWidgets.QRadioButton(self.horizontalLayoutWidget)
        self.radioButton.setStyleSheet(
            "background-color: rgb(224, 235, 250);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 9pt \"Arial\";")
        self.radioButton.setObjectName("radioButton")
        self.verticalLayout.addWidget(self.radioButton)
        spacerItem1 = QtWidgets.QSpacerItem(20, 40,
                                            QtWidgets.QSizePolicy.Minimum,
                                            QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem1)
        self.radioButton_2 = QtWidgets.QRadioButton(
            self.horizontalLayoutWidget)
        self.radioButton_2.setStyleSheet(
            "background-color: rgb(224, 235, 250);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 9pt \"Arial\";")
        self.radioButton_2.setObjectName("radioButton_2")
        self.verticalLayout.addWidget(self.radioButton_2)
        spacerItem2 = QtWidgets.QSpacerItem(20, 40,
                                            QtWidgets.QSizePolicy.Minimum,
                                            QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem2)
        self.radioButton_3 = QtWidgets.QRadioButton(
            self.horizontalLayoutWidget)
        self.radioButton_3.setStyleSheet(
            "background-color: rgb(224, 235, 250);\n"
            "selection-color: rgb(255, 255, 255);\n"
            "gridline-color: rgb(255, 255, 255);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 9pt \"Arial\";")
        self.radioButton_3.setObjectName("radioButton_3")
        self.verticalLayout.addWidget(self.radioButton_3)
        spacerItem3 = QtWidgets.QSpacerItem(20, 40,
                                            QtWidgets.QSizePolicy.Minimum,
                                            QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem3)
        self.radioButton_4 = QtWidgets.QRadioButton(
            self.horizontalLayoutWidget)
        self.radioButton_4.setStyleSheet(
            "background-color: rgb(224, 235, 250);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 9pt \"Arial\";")
        self.radioButton_4.setObjectName("radioButton_4")
        self.verticalLayout.addWidget(self.radioButton_4)
        spacerItem4 = QtWidgets.QSpacerItem(20, 40,
                                            QtWidgets.QSizePolicy.Minimum,
                                            QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem4)
        self.horizontalLayout.addLayout(self.verticalLayout)
        spacerItem5 = QtWidgets.QSpacerItem(40, 20,
                                            QtWidgets.QSizePolicy.Expanding,
                                            QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem5)
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.label_2 = QtWidgets.QLabel(self.horizontalLayoutWidget)
        self.label_2.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 11pt \"Arial\";")
        self.label_2.setObjectName("label_2")
        self.verticalLayout_2.addWidget(self.label_2)
        spacerItem6 = QtWidgets.QSpacerItem(20, 40,
                                            QtWidgets.QSizePolicy.Minimum,
                                            QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_2.addItem(spacerItem6)
        self.radioButton_9 = QtWidgets.QRadioButton(
            self.horizontalLayoutWidget)
        self.radioButton_9.setStyleSheet(
            "background-color: rgb(224, 235, 250);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 9pt \"Arial\";")
        self.radioButton_9.setObjectName("radioButton_9")
        self.verticalLayout_2.addWidget(self.radioButton_9)
        spacerItem7 = QtWidgets.QSpacerItem(20, 40,
                                            QtWidgets.QSizePolicy.Minimum,
                                            QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_2.addItem(spacerItem7)
        self.radioButton_5 = QtWidgets.QRadioButton(
            self.horizontalLayoutWidget)
        self.radioButton_5.setStyleSheet(
            "background-color: rgb(224, 235, 250);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 9pt \"Arial\";")
        self.radioButton_5.setObjectName("radioButton_5")
        self.verticalLayout_2.addWidget(self.radioButton_5)
        spacerItem8 = QtWidgets.QSpacerItem(20, 40,
                                            QtWidgets.QSizePolicy.Minimum,
                                            QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_2.addItem(spacerItem8)
        self.radioButton_6 = QtWidgets.QRadioButton(
            self.horizontalLayoutWidget)
        self.radioButton_6.setStyleSheet(
            "background-color: rgb(224, 235, 250);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 9pt \"Arial\";")
        self.radioButton_6.setObjectName("radioButton_6")
        self.verticalLayout_2.addWidget(self.radioButton_6)
        spacerItem9 = QtWidgets.QSpacerItem(20, 40,
                                            QtWidgets.QSizePolicy.Minimum,
                                            QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_2.addItem(spacerItem9)
        self.horizontalLayout.addLayout(self.verticalLayout_2)
        spacerItem10 = QtWidgets.QSpacerItem(40, 20,
                                             QtWidgets.QSizePolicy.Expanding,
                                             QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem10)
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.label_3 = QtWidgets.QLabel(self.horizontalLayoutWidget)
        self.label_3.setStyleSheet("background-color: rgb(224, 235, 250);\n"
                                   "border-color: rgb(18, 18, 18);\n"
                                   "color: rgb(81, 81, 255);\n"
                                   "font: bold 11pt \"Arial\";")
        self.label_3.setObjectName("label_3")
        self.verticalLayout_3.addWidget(self.label_3)
        spacerItem11 = QtWidgets.QSpacerItem(20, 40,
                                             QtWidgets.QSizePolicy.Minimum,
                                             QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem11)
        self.radioButton_7 = QtWidgets.QRadioButton(
            self.horizontalLayoutWidget)
        self.radioButton_7.setStyleSheet(
            "background-color: rgb(224, 235, 250);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 9pt \"Arial\";")
        self.radioButton_7.setObjectName("radioButton_7")
        self.verticalLayout_3.addWidget(self.radioButton_7)
        spacerItem12 = QtWidgets.QSpacerItem(20, 40,
                                             QtWidgets.QSizePolicy.Minimum,
                                             QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem12)
        self.radioButton_8 = QtWidgets.QRadioButton(
            self.horizontalLayoutWidget)
        self.radioButton_8.setStyleSheet(
            "background-color: rgb(224, 235, 250);\n"
            "border-color: rgb(18, 18, 18);\n"
            "color: rgb(81, 81, 255);\n"
            "font: bold 9pt \"Arial\";")
        self.radioButton_8.setObjectName("radioButton_8")
        self.verticalLayout_3.addWidget(self.radioButton_8)
        spacerItem13 = QtWidgets.QSpacerItem(20, 40,
                                             QtWidgets.QSizePolicy.Minimum,
                                             QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem13)
        self.horizontalLayout.addLayout(self.verticalLayout_3)
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "Цветовая тема:"))
        self.radioButton.setText(_translate("MainWindow", "Светлая"))
        self.radioButton_2.setText(_translate("MainWindow", "Тёмная"))
        self.radioButton_3.setText(_translate("MainWindow", "Контрастная"))
        self.radioButton_4.setText(_translate("MainWindow", "Собственная"))
        self.label_2.setText(_translate("MainWindow", "Размер шрифта:"))
        self.radioButton_9.setText(_translate("MainWindow", "Мелкий"))
        self.radioButton_5.setText(_translate("MainWindow", "Стандартный"))
        self.radioButton_6.setText(_translate("MainWindow", "Большой"))
        self.label_3.setText(_translate("MainWindow", "Тип шрифта:"))
        self.radioButton_7.setText(_translate("MainWindow", "Базовый"))
        self.radioButton_8.setText(_translate("MainWindow", "Собственный"))
