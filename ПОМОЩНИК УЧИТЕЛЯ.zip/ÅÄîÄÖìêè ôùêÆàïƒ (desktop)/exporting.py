import os
import sqlite3
import sys

import xlrd
import xlsxwriter as xlsxwriter
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QMainWindow, QApplication, QLineEdit, QRadioButton, \
    QTableWidgetItem, QWidget, QHBoxLayout, QButtonGroup, QInputDialog, \
    QMessageBox, QFileDialog, QCheckBox
from interfaces import Ex
def expect_hook(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)

class Exploring(QMainWindow, Ex):
    def __init__(self, file, password, obj):
        super().__init__()
        self.setWindowIcon(QIcon('icons\icon.png'))
        self.obj = obj
        self.way = False
        self.file = file
        self.res = ''
        self.password = password
        self.setupUi(self)
        fg = QButtonGroup(self.centralwidget)
        fg.addButton(self.radioButton)
        fg.addButton(self.radioButton_2)
        fg2 = QButtonGroup(self.centralwidget)
        fg2.addButton(self.radioButton_3)
        fg2.addButton(self.radioButton_4)
        fg3 = QButtonGroup(self.centralwidget)
        fg3.addButton(self.radioButton_5)
        self.pushButton_3.clicked.connect(self.add_class)
        fg3.addButton(self.radioButton_6)
        self.radioButton_5.setChecked(True)
        self.radioButton.setChecked(True)
        self.radioButton_3.setChecked(True)
        self.radioButton_4.clicked.connect(self.name)
        self.setWindowTitle('Работа с классами')
        self.setFixedSize(550, 465)
        self.lineEdit.setEchoMode(QLineEdit.Password)
        self.radioButton.setChecked(True)
        self.pushButton.clicked.connect(self.exporting)
        self.pushButton_2.clicked.connect(self.delete)
        self.lineEdit.textChanged[str].connect(self.showresults)
        self.lineEdit_2.textChanged[str].connect(self.showresults2)
        self.pushButton_4.clicked.connect(self.addway)
        self.radioButton_3.clicked.connect(self.clean)

    def clean(self):
        self.radioButton_4.setText("Новое (не введено)")

    def showresults(self):
        rb = self.tableWidget.findChildren(QRadioButton)
        if not rb:
            self.lineEdit.setText('')
            return
        self.lineEdit.setText(self.lineEdit.text().strip())

    def showresults2(self):
        self.lineEdit_2.setText(self.lineEdit_2.text().strip())
        if len(self.lineEdit_2.text().strip()) > 10:
            self.lineEdit_2.setText(self.lineEdit_2.text().strip()[:10])
        ## работа с БД
        self.con = sqlite3.connect(self.file)
        cur = self.con.cursor()
        unable_names = [i[0] for i in cur.execute(
                'SELECT name from sqlite_master where type= "table"').fetchall()]
        self.con.close()
        ## конец аботы с БД
        if self.lineEdit_2.text().strip() in unable_names or len(self.lineEdit_2.text().strip()) <= 1:
            self.lineEdit_2.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(255, 0, 0);\n"
"font: bold 12pt \"Arial\";")
        else:
            self.lineEdit_2.setStyleSheet(("background-color: rgb(255, 255, 255);\n"
"border-color: rgb(18, 18, 18);\n"
"color: rgb(0, 255, 0);\n"
"font: bold 12pt \"Arial\";"))



    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Return:
            if not self.lineEdit.text().strip() and not self.lineEdit_2.text().strip():
                self.exporting()
            elif self.lineEdit.text().strip() and not self.lineEdit_2.text().strip():
                self.delete()
            elif not self.lineEdit.text().strip() and self.lineEdit_2.text().strip():
                self.add_class()
            else:
                self.delete()

    def get_datas(self):
        ## работа с БД
        self.con = sqlite3.connect(self.file)
        cur = self.con.cursor()
        vals = [list(item)[0] for item in
                cur.execute("SELECT class FROM classes").fetchall()]
        vals.sort()

        self.con.close()
        ## конец работы с БД
        self.tableWidget.setRowCount(len(vals))
        for i in range(len(vals)):
            locals().update({f'r_b{i + 1}': QRadioButton(self)})
            cell_widget = QWidget()
            lay_out = QHBoxLayout(cell_widget)
            if not i:
                locals().get(f'r_b{i + 1}').setChecked(True)
            locals().get(f'r_b{i + 1}').clicked.connect(self.cbc_update)

            lay_out.addWidget(locals().get(f'r_b{i + 1}'))
            lay_out.setAlignment(Qt.AlignCenter)
            lay_out.setContentsMargins(0, 0, 0, 0)
            cell_widget.setLayout(lay_out)
            cell_widget.installEventFilter(self)
            self.tableWidget.setCellWidget(i, 0, cell_widget)
            self.tableWidget.setItem(i, 1,
                                     QTableWidgetItem(vals[i]))

    def eventFilter(self, obj, e):  ## обработка чекбоксов
        if True:
            if e.type() == 2:
                rb = self.tableWidget.findChildren(QRadioButton)
                if any([i.isChecked() for i in rb]):
                    for i in rb:
                        i.setChecked(False)
                try:
                    obj.children()[1].setChecked(True)
                except Exception:
                    obj.setChecked(True)
        return super(Exploring, self).eventFilter(obj, e)

    def cbc_update(self):
        rb = self.tableWidget.findChildren(QRadioButton)
        a = self.sender()
        if any([i.isChecked() for i in rb]):
            for i in rb:
                i.setChecked(False)
        a.setChecked(True)

    def name(self):
        res, ok_pressed = QInputDialog.getText(self, "Экспорт",
                                               "Введите название класса:")
        if not ok_pressed:
            self.radioButton_4.setChecked(False)
            self.radioButton_3.setChecked(True)
            return
        if not res.strip():
            self.radioButton_4.setChecked(False)
            self.radioButton_3.setChecked(True)
            return
        res = res.strip()
        self.res = res
        if len(res) <= 8:
            self.radioButton_4.setText(f"Новое ({res})")
        else:
            self.radioButton_4.setText(f"Новое ({res[:8]}...)")

    def exporting(self):
        rb = self.tableWidget.findChildren(QRadioButton)
        if not rb:
            return
        for i in range(len(rb)):
            if rb[i].isChecked():
                name = self.tableWidget.item(i, 1).text()
                break
        ## работа с БД
        self.con = sqlite3.connect(self.file)
        command = f"""SELECT * FROM '{name}'"""
        cur = self.con.cursor()
        data = cur.execute(
            command).fetchall()
        self.con.close()
        ## конец аботы с БД
        name_2 = name
        if self.radioButton_4.isChecked():
            name_2 = self.res
        if os.path.isfile(f'{name_2}.xlsx'):
            msg = QMessageBox(self)
            msg.setWindowTitle('Авторизация')
            msg.setText(
                f'Фал с таким именем существует. Заменить?')

            play = msg.addButton(
                'Да', QMessageBox.AcceptRole)
            change = msg.addButton(
                'Нет', QMessageBox.AcceptRole)
            msg.setIcon(QMessageBox.Question)
            msg.setDefaultButton(play)
            msg.exec_()
            msg.deleteLater()
            if msg.clickedButton() is change:
                return
        if self.radioButton_2.isChecked():
            count = 1
        else:
            count = 0
        workbook = xlsxwriter.Workbook(f'{name_2}.xlsx')
        worksheet = workbook.add_worksheet()
        if count:
            worksheet.write(0, 0, 'Имя')
            worksheet.write(0, 1, 'Фамилия')
            worksheet.write(0, 2, 'Дата рождения')
            worksheet.write(0, 3, 'Пол')
            worksheet.write(0, 4, 'Email')
            worksheet.write(0, 5, 'Телефон')
            worksheet.write(0, 6, 'Родитель')
        for row, (name, srname, date, pol, email, phone, parent) in enumerate(data):
            worksheet.write(row + count, 0, name)
            worksheet.write(row + count, 1, srname)
            worksheet.write(row + count, 2, date)
            worksheet.write(row + count, 3, pol)
            worksheet.write(row + count, 4, email)
            worksheet.write(row + count, 5, phone)
            worksheet.write(row + count, 6, parent)
        workbook.close()
        QMessageBox.information(self, 'Экспорт', 'Экспорт успешно произведён')
        return

    def delete(self):
        rb = self.tableWidget.findChildren(QRadioButton)
        if not rb:
            return
        text = self.lineEdit.text().strip()
        if not text:
            QMessageBox.critical(self, 'Удаление', 'Введите пароль')
            self.lineEdit.setText('')
            return
        if text != self.password:
            QMessageBox.critical(self, 'Удаление', 'Введён неверный пароль')
            self.lineEdit.setText('')
            return
        msg = QMessageBox(self)
        msg.setWindowTitle('Авторизация')
        msg.setText(
            f'Вы действительно хотите удалить выбранный файл?')

        play = msg.addButton(
            'Да', QMessageBox.AcceptRole)
        change = msg.addButton(
            'Нет', QMessageBox.AcceptRole)
        msg.setIcon(QMessageBox.Question)
        msg.setDefaultButton(play)
        msg.exec_()
        msg.deleteLater()
        if msg.clickedButton() is change:
            self.lineEdit.setText('')
            return
        rb = self.tableWidget.findChildren(QRadioButton)
        for i in range(len(rb)):
            if rb[i].isChecked():
                name = "'" + self.tableWidget.item(i, 1).text() + "'"
                break
        ## работа с БД
        self.con = sqlite3.connect(self.file)
        command = f"""DROP TABLE {name}"""
        cur = self.con.cursor()
        cur.execute(command)
        self.con.close()
        ## конец аботы с БД

        ## работа с БД
        self.con = sqlite3.connect(self.file)
        command = f"""DELETE FROM classes WHERE class = {name}"""
        cur = self.con.cursor()
        cur.execute(command)
        self.con.commit()
        self.con.close()
        ## конец аботы с БД

        self.get_datas()
        self.obj.setclasscombo()
        QMessageBox.information(self, 'Удалене', 'Класс успешно удалён')
        self.lineEdit.setText('')

    def addway(self):
        fname = QFileDialog.getOpenFileName(
            self, 'Выбор файла', '',
            'Класс (*.xlsx)')[0]
        if not fname:
            return
        self.way = fname
        a = os.path.basename(fname)
        if len(a[:-5]) <= 8:
            self.label_11.setText(os.path.basename(fname))
        else:
            self.label_11.setText(a[:8] + '...' + 'xlsx')
        self.pushButton_4.setText('Изменить')

    def add_class(self):
        if not self.way:
            return
        ## работа с БД
        self.con = sqlite3.connect(self.file)
        cur = self.con.cursor()
        unable_names = [i[0] for i in cur.execute(
            'SELECT name from sqlite_master where type= "table"').fetchall()]
        self.con.close()
        ## конец аботы с БД
        if self.lineEdit_2.text().strip() in unable_names or len(
            self.lineEdit_2.text().strip()) < 2:
            return
        ## работа с БД
        self.con = sqlite3.connect(self.file)
        cur = self.con.cursor()
        cur.execute("""CREATE TABLE '{}'
                              (фамилия text, имя text, дата_рождения time,
                               пол text, email text, телефон text, родтель text)
                           """.format(self.lineEdit_2.text().strip()))
        self.con.commit()
        self.con.close()
        ## конец работы с БД
        try:
            rb = xlrd.open_workbook(self.way)
        except Exception as e:
            return
        sheet = rb.sheet_by_index(0)
        vals = [[str(i) for i in list(sheet.row_values(rownum))] for rownum in
                range(sheet.nrows)][int(self.radioButton_6.isChecked()):]
        for i in range(len(vals)):
            a = []
            for j in range(7):
                if vals[i][j]:
                    a.append(vals[i][j])
                else:
                    a.append('Не определено')
            vals[i] = tuple(a)
        # INSERT INTO
            ## работа с БД
        self.con = sqlite3.connect(self.file)
        cur = self.con.cursor()
        cur.execute("""INSERT INTO  classes VALUES('{}')""".format(self.lineEdit_2.text().strip()))
        self.con.commit()
        self.con.close()
        ## конец работы с БД
        ## работа с БД
        self.con = sqlite3.connect(self.file)
        cur = self.con.cursor()
        cur.executemany(
            "INSERT INTO" + f""" '{self.lineEdit_2.text().strip()}'""" + "VALUES (?,?,?,?,?,?,?)", vals)
        self.con.commit()
        self.con.close()
        ## конец работы с БД
        self.obj.addclass(vals, self.lineEdit_2.text().strip())
        self.lineEdit_2.setText('')
        self.label_11.setText('')
        self.pushButton_4.setText('Добавить')
        self.radioButton_5.setChecked(True)
        self.get_datas()

    def update_theme(self, children, name, color_theme, size):
        self.size = size
        if name == 'Windows':
            stl = ''
            for i in color_theme['Windows']:
                stl += i + ': ' + color_theme['Windows'][i]
            children.setStyleSheet(stl)
            return
        a = self.findChildren(children)
        for i in range(len(a)):
            b = a[i].styleSheet()
            b = [j.strip('\n') for j in b.split(';') if j.strip('\n')]
            d = {}
            for j in b:
                try:
                    if j.split(':')[0] not in d:
                        d[j.split(':')[0]] = j.split(':')[1]
                except Exception:
                    return

            d['background-color'] = color_theme[name]['background-color']
            d['color'] = color_theme[name]['color']
            styles = ''
            if self.obj.color.radioButton_7.isChecked():
                font = 'Arial'
            else:
                font = color_theme['Windows']['font'].split()[2:]
                font[0] = font[0][1:]
                font[-1] = font[-1][:-2]
                font = ' '.join(font)
            if 'font' in d:
                if 'bold' in d['font']:
                    d['font'] = (f'''bold {size[int((d['font'].split())[1][:-2])]}pt "{font}";''')
                else:
                    d['font'] = (
                        f'''bold {size[int((d['font'].split())[0][:-2])]}pt "{font}";''')
            for t in d:
                styles += (t + ':' + d[t] + ';' + '\n')
            a[i].setStyleSheet(styles)
if __name__ == '__main__':
    sys.excepthook = expect_hook
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    work_class = Exploring('nick.sqlite3', 'Zxoiet123')
    work_class.get_datas()
    work_class.show()
    sys.exit(app.exec())