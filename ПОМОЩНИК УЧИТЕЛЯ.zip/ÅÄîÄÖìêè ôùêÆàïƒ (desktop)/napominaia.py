import sqlite3

from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QCheckBox, QTableWidgetItem, QWidget, QHBoxLayout, \
    QMainWindow, QApplication, QMessageBox
from tkinter import messagebox, Tk
import sys
from PyQt5.QtCore import QTimer, QTime, Qt
from datetime import datetime, timedelta

from autorisation import stuff_mail
from interfaces import Napominanieui
#from autorisation import stuff_mail
#from autorisation import *


def expect_hook(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)


class Napominanie(QMainWindow, Napominanieui):
    def __init__(self, email, file, obj):
        super().__init__()
        self.setWindowIcon(QIcon('icons\icon.png'))
        self.revers = False
        self.obj = obj
        self.looklist = {}
        self.key_sorting = self.sort_by_date
        self.email = email
        self.file = file
        self.setupUi(self)
        self.flag = True
        self.flag2 = True
        self.setFixedSize(960, 505)
        self.setWindowTitle('Напоминания')
        self.timer = QTimer(self)
        self.timer.setInterval(60 * 1000)
        self.timer.timeout.connect(self.send_napominanie)
        self.timer.start()
        self.active_datas = []
        self.timeEdit.setTime(QTime(int(datetime.now().hour), int(datetime.now().minute)))

        self.pushButton.clicked.connect(self.adnap)
        self.pushButton_2.clicked.connect(self.delete)
        self.checkBox.clicked.connect(self.cbc)
        self.lineEdit_2.textChanged[str].connect(self.showresults)
        self.comboBox.currentTextChanged.connect(self.sorting)
        self.month = {'янв': '01',
                   'фев': '02',
                   'мар': '03',
                   'апр': '04',
                   'май': '05',
                   'июн': '06',
                   'июл': '07',
                   'авг': '08',
                   'сен': '09',
                   'окт': '10',
                   'ноя': '11',
                   'дек': '12'}
        self.days = {'Пн': '0',
                     'Вт': '1',
                     'Ср': '2',
                     'Чт': '3',
                     'Пт': '4',
                     'Сб': '5',
                     'Вс': '6'}


    def cbc(self):  ## обработка чекбоксов
        checkboxes = self.tableWidget.findChildren(QCheckBox)
        if not len(checkboxes):
            self.checkBox.setChecked(False)
            return
        if self.flag:
            for item in checkboxes:
                item.setChecked(self.checkBox.isChecked())
                item.clicked.connect(self.cbc_update)
        self.flag = True
        return

    def cbc_update(self):  ## обработка чекбоксов
        checkboxes = self.tableWidget.findChildren(QCheckBox)
        if all([i.isChecked() for i in checkboxes]):
            self.flag2 = False
            self.checkBox.setChecked(True)
            return
        for item in checkboxes:
            if item.isChecked() != self.checkBox.isChecked():
                self.flag2 = False
                self.checkBox.setChecked(False)
                return

    def adnap(self):  ## добавление напоминания
        date = self.calendarWidget.selectedDate().toString()
        time = self.timeEdit.text()
        theme = self.lineEdit.text().strip()
        text = self.plainTextEdit.toPlainText().strip('\n')
        text = text.strip()
        dt = (str(date) + ' ' + str(time)).split()
        dt[0] = self.days[dt[0]]
        dt[1] = self.month[dt[1]]
        now_date = str(datetime.now().date()).split('-')
        now_time = (str(datetime.now().hour) + ':' + str(datetime.now().minute)).split()
        now_date.extend(now_time)
        del dt[0]
        dt[0], dt[1], dt[2] = dt[2], dt[0], dt[1]
        date_now = '.'.join(now_date[:3]) + ' ' + ':'.join(now_date[3:])
        date_new = '.'.join(dt[:3]) + ' ' + ':'.join(dt[3:])


        dt_fmt ='%Y.%m.%d %H:%M'
        date_now = (datetime.strptime(date_now, dt_fmt) + timedelta(hours=0))
        date_new = (datetime.strptime(date_new, dt_fmt) + timedelta(
            hours=0))
        a = -1
        try:
            a = int((date_new - date_now).total_seconds())
        except Exception as e:
            if (date_new - date_now).total_seconds() > 0:
                QMessageBox.critical(self, 'Напоминания', 'Временной примежуток слишком большой')
                return
            else:
                QMessageBox.critical(self, 'Напоминания',
                                     'Временной промежуток отрицательный')
                return
        if a > 0:
            if not theme:
                QMessageBox.critical(self, 'Напоминания', 'Введите тему напоминания')
                return

        else:
            QMessageBox.critical(self, 'Напоминания',
                                 'Временной промежуток отрицательный')
            return
        self.lineEdit.setText('')
        self.plainTextEdit.setPlainText('')
        self.timeEdit.setTime(QTime(int(datetime.now().hour), int(datetime.now().minute)))
        ## работа с бд
        self.con =sqlite3.connect(self.file)
        cursor = self.con.cursor()
        cursor.execute("""INSERT INTO napominaniya VALUES('{}', '{}', '{}', '{}')""".format(date, time, theme, text))
        self.con.commit()
        self.con.close()
        self.get_dates()
        ## конец работы с бд

    def send_napominanie(self):
        now_date = str(datetime.now().date()).split('-')
        now_time = (str(datetime.now().hour) + ':' + str(
            datetime.now().minute)).split()
        now_date.extend(now_time)
        date_now = '.'.join(now_date[:3]) + ' ' + ':'.join(now_date[3:])
        if date_now in self.looklist:
            for i in self.looklist[date_now]:

                ## работа с бд
                self.con = sqlite3.connect(self.file)
                cur = self.con.cursor()
                try:
                    cur.execute("""DELETE FROM napominaniya WHERE data = '{}' AND time = '{}' AND 
                                                                        tema = '{}' AND TEXT = '{}'""".format(
                        i[0], [1], i[2], i[3]))
                    self.con.commit()
                except Exception as e:
                    print(e.args)
                self.con.close()
            del self.looklist[date_now]
        self.timer.setInterval(60 * 1000)
        self.timer.timeout.connect(self.send_napominanie)
        self.timer.start()
        self.get_dates()

    def update_theme(self, children, name, color_theme, size):
        self.size = size
        if name == 'Windows':
            stl = ''
            for i in color_theme['Windows']:
                stl += i + ': ' + color_theme['Windows'][i]
            children.setStyleSheet(stl)
            return
        a = self.findChildren(children)
        for i in range(len(a)):
            b = a[i].styleSheet()
            b = [j.strip('\n') for j in b.split(';') if j.strip('\n')]
            d = {}
            for j in b:
                try:
                    if j.split(':')[0] not in d:
                        d[j.split(':')[0]] = j.split(':')[1]
                except Exception:
                    return

            d['background-color'] = color_theme[name]['background-color']
            d['color'] = color_theme[name]['color']
            styles = ''
            if self.obj.color.radioButton_7.isChecked():
                font = 'Arial'
            else:
                font = color_theme['Windows']['font'].split()[2:]
                font[0] = font[0][1:]
                font[-1] = font[-1][:-2]
                font = ' '.join(font)
            if 'font' in d:
                if 'bold' in d['font']:
                    d['font'] = (f'''bold {size[int((d['font'].split())[1][:-2])]}pt "{font}";''')
                else:
                    d['font'] = (
                        f'''bold {size[int((d['font'].split())[0][:-2])]}pt "{font}";''')
            for t in d:
                styles += (t + ':' + d[t] + ';' + '\n')
            a[i].setStyleSheet(styles)
        a = (self.plainTextEdit.font())
        self.plainTextEdit.setStyleSheet(f"background-color: {self.obj.color.color_theme['Windows']['background-color']}color: {self.obj.color.color_theme['PlainTextEdits']['color']}")
        self.plainTextEdit.setFont(a)
        a = self.tableWidget.font()
        self.tableWidget.setStyleSheet(f"background-color: {self.obj.color.color_theme['Windows']['background-color']}color: {self.obj.color.color_theme['Tables']['color']}")
        self.tableWidget.setFont(a)
        a = self.timeEdit.font()
        self.timeEdit.setStyleSheet(f"background-color: {self.obj.color.color_theme['Windows']['background-color']}color: {self.obj.color.color_theme['Tables']['color']}")
        self.timeEdit.setFont(a)
        a = self.checkBox.font()
        self.checkBox.setStyleSheet(f"background-color: {self.obj.color.color_theme['CheckBoxes']['background-color']}color: {self.obj.color.color_theme['CheckBoxes']['color']}")
        self.checkBox.setFont(a)
        a = self.lineEdit.font()
        self.lineEdit.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['LineEdits']['background-color']}color: {self.obj.color.color_theme['LineEdits']['color']}")
        self.lineEdit.setFont(a)

        a = self.lineEdit_2.font()
        self.lineEdit_2.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['LineEdits']['background-color']}color: {self.obj.color.color_theme['LineEdits']['color']}")
        self.lineEdit_2.setFont(a)
        a = self.comboBox.font()
        self.comboBox.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Windows']['background-color']}color: {self.obj.color.color_theme['LineEdits']['color']}")
        self.comboBox.setFont(a)





    def get_dates(self):
        ## работа с БД
        if self.file == 'None.sqlite3':
            return
        self.looklist = {}
        self.con = sqlite3.connect(self.file)
        cur = self.con.cursor()
        vals = [list(item) for item in
                cur.execute("""SELECT * FROM napominaniya""").fetchall()]
        self.con.close()
        ## конец работы с БД
        for i in vals:
            date = i[0]
            time = i[1]
            theme = i[2]
            text = i[3]
            dt = date
            dt = date.split()
            del dt[0]
            dt[0] = self.month[dt[0]]
            dt[0], dt[1], dt[2] = dt[2], dt[0], dt[1]
            dt = '.'.join(dt)
            date_new = dt
            now_date = str(datetime.now().date()).split('-')
            now_time = (str(datetime.now().hour) + ':' + str(datetime.now().minute)).split()
            now_date.extend(now_time)
            dt_fmt = '%Y.%m.%d %H:%M'
            date_now = '.'.join(now_date[:3]) + ' ' + ':'.join(now_date[3:])
            date_now = (datetime.strptime(date_now, dt_fmt) + timedelta(hours=0))
            date_new += ' ' + time
            #return
            date_new = (datetime.strptime(date_new, dt_fmt) + timedelta(
            hours=0))
            a = -1
            try:
                a = int((date_new - date_now).total_seconds())
            except Exception as e:
                pass
            if a > 0:
                if date_new.strftime(dt_fmt) not in self.looklist:
                    self.looklist[date_new.strftime(dt_fmt)] = []
                    self.looklist[date_new.strftime(dt_fmt)].append((date, time, theme, text))
                else:
                    self.looklist[date_new.strftime(dt_fmt)].append((date, time, theme, text))
            else:
                self.con = sqlite3.connect(self.file)
                cur = self.con.cursor()
                #         command = f"""DELETE FROM classes WHERE class = {name}"""
                cur.execute("""DELETE FROM napominaniya WHERE data = '{}' and time = '{}' and tema = '{}' and text = '{}'""".format(date, time, theme, text))
                self.con.commit()
                self.con.close()
        vals = []
        for i in self.looklist:
            for j in self.looklist[i]:
                vals.append(j)
        self.tableWidget.setRowCount(len(vals))

        vals = self.key_sorting(vals)

        for i in range(len(vals)):
            for j in range(4):
                locals().update({f'c_b{i + 1}': QCheckBox(self)})
                locals().get(f'c_b{i + 1}').setChecked(
                    self.checkBox.isChecked())
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                cell_widget = QWidget()
                lay_out = QHBoxLayout(cell_widget)
                lay_out.addWidget(locals().get(f'c_b{i + 1}'))
                lay_out.setAlignment(Qt.AlignCenter)
                lay_out.setContentsMargins(0, 0, 0, 0)
                cell_widget.setLayout(lay_out)
                cell_widget.installEventFilter(self)
                self.tableWidget.setCellWidget(i, 0, cell_widget)
                self.tableWidget.setItem(i, j + 1,
                                         QTableWidgetItem(vals[i][j]))

    def delete(self):
        checkboxes = self.tableWidget.findChildren(QCheckBox)
        count = 0
        rc = []
        for i in range(len(checkboxes)):

            if checkboxes[i].isChecked():
                rc.append(i)
                count += 1
        if count == 0:
            return
        root = Tk()
        root.withdraw()
        msg = QMessageBox(self)
        msg.setWindowTitle('Напоминания')
        msg.setText(
            f'Вы действтельно хотите удалить выбранные напоминания?')

        play = msg.addButton(
            'Да', QMessageBox.AcceptRole)
        change = msg.addButton(
            'Нет', QMessageBox.AcceptRole)
        msg.setIcon(QMessageBox.Question)
        msg.setDefaultButton(play)
        msg.exec_()
        msg.deleteLater()
        if msg.clickedButton() is play:
            for i in rc:
                ps = []
                for j in range(3):
                    ps.append(self.tableWidget.item(i, j + 1).text())

                ## работа с БД
                self.con = sqlite3.connect(self.file)
                cur = self.con.cursor()
                cur.execute("""DELETE FROM napominaniya WHERE data = '{}' AND time = '{}' AND 
                    tema = '{}'""".format(ps[0], ps[1], ps[2]))
                self.con.commit()
                self.con.close()
                # конец работы с БД
                if (ps[0] + ps[1] + ps[2]).lower() in self.looklist:
                    del self.looklist[(ps[0] + ps[1] + ps[2]).lower()]
                a = [i for i in self.active_datas]
                for j in a:
                    if (ps[0] + ps[1] + ps[2]).lower() == j[1]:
                        self.active_datas.pop(j)
            self.lineEdit_2.setText('')
            self.get_dates()
        return

    def eventFilter(self, obj, e):  ## обработка чекбоксов
        if e.type() == 2:
            obj.children()[1].setChecked(not obj.children()[1].isChecked())
            self.cbc_update()
        return super(Napominanie, self).eventFilter(obj, e)

    def sorting(self):
        if self.comboBox.currentText() == 'дате и времени':
            self.key_sorting = self.sort_by_date
            self.revers = False
        elif self.comboBox.currentText() == 'дате и времени (R)':
            self.key_sorting = self.sort_by_date
            self.revers = True
        elif self.comboBox.currentText() == 'теме':
            self.key_sorting = self.sort_by_theme
            self.revers = False
        elif self.comboBox.currentText() == 'теме (R)':
            self.key_sorting = self.sort_by_theme
            self.revers = True
        self.get_dates()

    def sort_by_date(self, lst, revers=False):
        revers = self.revers
        diction = {'янв': '01',
                   'фев': '02',
                   'мар': '03',
                   'апр': '04',
                   'май': '05',
                   'июн': '06',
                   'июл': '07',
                   'авг': '08',
                   'сен': '09',
                   'окт': '10',
                   'ноя': '11',
                   'дек': '12'}
        results = {}

        sorted_vals = []

        for i in range(len(lst)):

            d_f = ('%d.%m.%Y %H:%M')
            time1 = datetime.today().strftime(d_f)
            hp = lst[i][0].split()
            hp[1] = self.month[hp[1]]
            del hp[0]
            hp[0], hp[1], hp[2] = hp[1], hp[0], hp[2]
            time2 = '.'.join(hp) + ' ' + lst[i][1]
            result = datetime.strptime(time2,
                                                d_f) - datetime.strptime(
                time1, d_f)
            result = int(result.total_seconds())
            if result not in results:
                results[result] = []
                results[result].append(lst[i])
            else:
                results[result].append(lst[i])
        for i in results:
            results[i] = list(sorted(results[i], key=lambda x: x[2]))
        a = [i for i in results]
        a.sort(reverse=revers)
        sortes_vals = []
        for i in a:
            for j in results[i]:
                sortes_vals.append(j)
        return sortes_vals

    def sort_by_theme(self, lst, revers=False):
        revers = self.revers
        sorted_vals = []
        names = {}
        for i in range(len(lst)):
            a = lst[i][2]
            if a not in names:
                names[a] = []
                names[a].append(lst[i])
            else:
                names[a].append(lst[i])
        for i in names:
            names[i] = self.time_return(names[i])
        sorted_names = sorted([i for i in names], key=lambda x: x)
        for i in sorted_names:
            for j in names[i]:
                sorted_vals.append(j)
        if revers:
            sorted_vals = sorted_vals[::-1]
        return sorted_vals

    def time_return(self, lst):
        sorted_vals = []
        results = {}
        for i in range(len(lst)):
            d_f = ('%d.%m.%Y %H:%M')
            time1 = datetime.today().strftime(d_f)
            hp = lst[i][0].split()
            hp[1] = self.month[hp[1]]
            del hp[0]
            hp[0], hp[1], hp[2] = hp[1], hp[0], hp[2]
            time2 = '.'.join(hp) + ' ' + lst[i][1]
            result = datetime.strptime(time2,
                                       d_f) - datetime.strptime(
                time1, d_f)
            result = int(result.total_seconds())
            if result not in results:
                results[result] = []
                results[result].append(lst[i])
            else:
                results[result].append(lst[i])

        for i in results:
            for j in results[i]:
                sorted_vals.append(j)
        return sorted_vals


    def showresults(self):
        a = [self.looklist[i] for i in list(
            filter(lambda x: self.lineEdit_2.text() in x,
                   [i for i in self.looklist]))]
        vals = []
        for i in a:
            for j in i:
                vals.append(j)
        vals = self.key_sorting(vals)
        self.tableWidget.setRowCount(len(vals))
        for i in range(len(vals)):
            for j in range(4):
                locals().update({f'c_b{i + 1}': QCheckBox(self)})
                locals().get(f'c_b{i + 1}').setChecked(
                    self.checkBox.isChecked())
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                cell_widget = QWidget()
                lay_out = QHBoxLayout(cell_widget)
                lay_out.addWidget(locals().get(f'c_b{i + 1}'))
                lay_out.setAlignment(Qt.AlignCenter)
                lay_out.setContentsMargins(0, 0, 0, 0)
                cell_widget.setLayout(lay_out)
                cell_widget.installEventFilter(self)
                self.tableWidget.setCellWidget(i, 0, cell_widget)
                self.tableWidget.setItem(i, j + 1,
                                         QTableWidgetItem(vals[i][j]))


if __name__ == '__main__':
    sys.excepthook = expect_hook
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    work_class = Napominanie('nicolaynemov@mail.ru', 'nick.sqlite3')
    work_class.show()
    work_class.get_dates()
    sys.exit(app.exec())
