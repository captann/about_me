import mimetypes
import pathlib
import smtplib
import os
import sqlite3
from email import encoders
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from tkinter import messagebox, Tk
import xlrd, sys, shutil
import webbrowser
from PyQt5.QtCore import QTimer, QTime
import datetime
import pymorphy2
from PyQt5.QtGui import QFont
from PyQt5.uic.properties import QtWidgets

from interfaces import *
import xlsxwriter
import psutil
from exporting import Exploring
from account import Account
from color import Colors
from for_informatiks import Main as Docx


def expect_hook(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)


from autorisation import *
from napominaia import Napominanie
from slk import Slk
from zametki import ZM, Scrollbar, Text, HORIZONTAL, BOTTOM, X, RIGHT, Y, NONE
from PyQt5.QtWidgets import QMainWindow, QFileDialog, QInputDialog, \
    QTableWidgetItem
from PyQt5.QtWidgets import QCheckBox
from paint import Paint


class Send(QMainWindow, Sendui):
    def __init__(self, obj, emails=[]):
        super().__init__()
        self.setupUi(self)
        self.setWindowIcon(QIcon('icons\icon.png'))
        self.obj = obj
        self.name_email = []
        self.docx = Docx(self)
        self.docx.hide()
        self.emails = emails
        self.comboBox.hide()
        self.pushButton.hide()
        #self.progressBar.hide()
        self.names = []
        self.d = {}
        self.flag = False
        self.datas = []
        self.label_5.setText('')
        self.label_4.hide()
        self.setFixedSize(470, 485)
        self.progressBar.hide()
        self.progressBar.setValue(0)
        self.setWindowTitle('Рассылка')
        self.pushButton_3.clicked.connect(self.addfile)
        self.pushButton_2.clicked.connect(self.send_mail)
        self.pushButton.clicked.connect(self.delet_last)
        self.files = []
        self.menu_2.triggered.connect(self.make_documend)

    def make_documend(self):
        self.flag = True

        self.docx.dates = self.datas
        self.docx.show()

    def personal_document(self, path):
        documents = [path + '\\' + i for i in os.listdir(path)]
        names = self.names
        self.d = {}
        for i in self.name_email:
            for j in documents:
                if [t for t in i][0] in j:
                    if j not in self.d:
                        self.d[j] = []
                        self.d[j].append(i)
                    else:
                        self.d[j].append(i)
        self.comboBox.show()
        self.label_4.show()
        a = []
        if self.flag:
            a.append('Перс...ное')
        a.extend(sorted([os.path.basename(i) for i in self.files]))
        for i in range(len(a)):
            if len(a[i]) > 9 and a[i] != 'Документ, созданный по шаблону':
                a[i] = a[i][:4] + '..' + a[i][-3:]
        self.comboBox.addItems(a)
        self.comboBox.show()
        self.pushButton.show()
        self.label_4.show()
        self.comboBox.clear()
        self.comboBox.addItems(a)
        self.pushButton.show()
        self.pushButton_2.disconnect()
        self.pushButton_2.clicked.connect(self.send_documents)

    def send_documents(self):
        tema = self.lineEdit.text().strip()
        text = (self.plainTextEdit.toPlainText().strip('\n')).strip()
        self.progressBar.show()
        self.setDisabled(True)
        self.setFixedSize(470, 520)
        self.label_5.setText('')
        self.pushButton_2.setDisabled(True)
        self.pushButton_3.setDisabled(True)
        count = 0
        not_send = []
        for i in self.d:
            for j in self.d[i]:
                email = [j[t] for t in j][0]

                count += 1
                message = MIMEMultipart()
                message["Subject"] = str(tema)
                message["From"] = 'shifrovalshchik@list.ru'
                body = text
                data = {}
                path = i
                with open(i,"rb") as f:
                    data[os.path.basename(i)] = f.read()
                for filename, body in data.items():
                    attachment = MIMEBase('application', "octet-stream")
                    attachment.set_payload(body)
                    encoders.encode_base64(attachment)
                    attachment.add_header('Content-Disposition',
                                          'attachment',
                                          # filename=quote(filename))
                                          filename=(
                                          'windows-1251', '', filename))
                    message.attach(attachment)
                for filepath in self.files:
                    ctype, encoding = mimetypes.guess_type(
                        filepath)  # Определяем тип файла на основе его расширения
                    if ctype is None or encoding is not None:  # Если тип файла не определяется
                        ctype = 'application/octet-stream'  # Будем использовать общий тип
                    maintype, subtype = ctype.split('/',
                                                    1)  # Получаем тип и подтип
                    with open(filepath, 'rb') as fp:
                        file = MIMEBase(maintype,
                                        subtype)  # Используем общий MIME-тип
                        file.set_payload(
                            fp.read())  # Добавляем содержимое общего типа (полезную нагрузку)
                        fp.close()
                    encoders.encode_base64(
                        file)  # Содержимое должно кодироваться как Base64
                    file.add_header('Content-Disposition', 'attachment',
                                    filename=os.path.basename(filepath))  # Добавляем заголовки
                    message.attach(file)
                message.attach(MIMEText('', 'plain'))

                try:
                    server = smtplib.SMTP_SSL("smtp.mail.ru", 465)
                    server.login(message["From"], "Zxoiet123")
                    server.sendmail(message["From"], email,
                                    message.as_string())
                except Exception as e:
                    not_send.append(email)
                if int((count / len(self.emails)) * 100) >= 10:
                    self.progressBar.setStyleSheet(
                        'background-color: rgb(224, 235, 250);'
                        'border-color: rgb(18, 18, 18);'
                        'color: rgb(255, 255, 255);'
                        'font: bold 12pt "Arial";')
                if int((count / len(self.emails)) * 100) <= 100:
                    self.progressBar.setValue(int((( count) / len(self.emails)) * 100))
        if not not_send:
            QMessageBox.information(self, 'Рассылка писем',
                                    'Рассыка успешно завершена')
        else:
            QMessageBox.information(self, 'Рассылка писем',
                                    'Рассыка завершена.' + '\n' + 'На следующие адреса не удалось отправить письмо:' + '\n' + '\n'.join(
                                        sorted(not_send)))
        if self.progressBar.value() <= 100:
            self.progressBar.setValue(100)
        self.label_4.setText('Вложения:')
        self.label_4.hide()
        self.comboBox.hide()
        self.pushButton.hide()
        self.progressBar.setValue(0)
        self.personal = False
        self.progressBar.hide()
        self.lineEdit.setText('')
        self.plainTextEdit.setPlainText('')
        self.files = []
        self.flag = False
        self.listWidget.clear()
        self.setDisabled(False)
        self.pushButton_2.setDisabled(False)
        self.pushButton_3.setDisabled(False)
        self.setFixedSize(470, 485)
        self.progressBar.setStyleSheet('background-color: rgb(224, 235, 250);'
                                       'border-color: rgb(18, 18, 18);'
                                       'color: rgb(0, 189, 244);'
                                       'font: bold 12pt "Arial";')
        self.close()










    def update_theme(self, children, name, color_theme, size):
        self.size = size
        self.size = self.obj.color.norm
        if name == 'Windows':
            stl = ''
            for i in color_theme['Windows']:
                stl += i + ': ' + color_theme['Windows'][i]
            children.setStyleSheet(stl)
            return
        a = self.findChildren(children)
        for i in range(len(a)):
            b = a[i].styleSheet()
            b = [j.strip('\n') for j in b.split(';') if j.strip('\n')]
            d = {}
            for j in b:
                try:
                    if j.split(':')[0] not in d:
                        d[j.split(':')[0]] = j.split(':')[1]
                except Exception:
                    return

            d['background-color'] = color_theme[name]['background-color']
            if name == 'LineEdits':
                d['color'] = 'rgb(81, 81, 255);'
            else:
                d['color'] = color_theme[name]['color']
            styles = ''
            if self.obj.color.radioButton_7.isChecked():
                font = 'Arial'
            else:
                font = color_theme['Windows']['font'].split()[2:]
                font[0] = font[0][1:]
                font[-1] = font[-1][:-2]
                font = ' '.join(font)
            if 'font' in d:
                if 'bold' in d['font']:
                    d['font'] = (f'''bold {size[int((d['font'].split())[1][:-2])]}pt "{font}";''')
                else:
                    d['font'] = (
                        f'''bold {size[int((d['font'].split())[0][:-2])]}pt "{font}";''')
            for t in d:
                styles += (t + ':' + d[t] + ';' + '\n')
            a[i].setStyleSheet(styles)
            self.docx.update_theme(children, name, color_theme, size)

    def send_mail(self):
        tema = self.lineEdit.text().strip()
        text = (self.plainTextEdit.toPlainText().strip('\n')).strip()
        if not text.strip() and not tema.strip() and not self.files:
            return

        self.progressBar.show()
        self.setDisabled(True)
        self.setFixedSize(470, 520)
        self.label_5.setText('')
        #self.progressBar.setValue(0)
        self.pushButton_2.setDisabled(True)
        self.pushButton_3.setDisabled(True)
        count = 0

        #self.progressBar.setValue(0)

        #for i in range(18):
        not_send = []
        if True:
            for email in self.emails:
                count += 1
                message = MIMEMultipart()
                message["Subject"] = str(tema)
                message["From"] = 'shifrovalshchik@list.ru'
                body = text
                for filepath in self.files:
                    ctype, encoding = mimetypes.guess_type(
                        filepath)  # Определяем тип файла на основе его расширения
                    if ctype is None or encoding is not None:  # Если тип файла не определяется
                        ctype = 'application/octet-stream'  # Будем использовать общий тип
                    maintype, subtype = ctype.split('/',
                                                    1)  # Получаем тип и подтип
                    with open(filepath, 'rb') as fp:
                        file = MIMEBase(maintype,
                                        subtype)  # Используем общий MIME-тип
                        file.set_payload(
                            fp.read())  # Добавляем содержимое общего типа (полезную нагрузку)
                        fp.close()
                    encoders.encode_base64(
                        file)  # Содержимое должно кодироваться как Base64
                    file.add_header('Content-Disposition', 'attachment',
                                    filename=os.path.basename(filepath))  # Добавляем заголовки
                    message.attach(file)
                message.attach(MIMEText('', 'plain'))
                try:
                    if self.files:
                        server = smtplib.SMTP_SSL("smtp.mail.ru", 465)
                        server.login(message["From"], "Zxoiet123")
                        server.sendmail(message["From"], email, message.as_string())
                    else:
                        a = stuff_mail(tema, text, email)
                        if not a[0]:
                            not_send.append(email)
                except Exception as e:
                    #print(e.args)
                    not_send.append(email)
                #morph = pymorphy2.MorphAnalyzer()
                #delet = morph.parse('письмо')[0]
                if int((count / len(self.emails)) * 100) >= 10:
                    self.progressBar.setStyleSheet(
                        'background-color: rgb(224, 235, 250);'
                        'border-color: rgb(18, 18, 18);'
                        'color: rgb(255, 255, 255);'
                        'font: bold 12pt "Arial";')
                if int((count / len(self.emails)) * 100) <= 100:
                    self.progressBar.setValue(int((( count) / len(self.emails)) * 100))
            if not not_send:
                QMessageBox.information(self, 'Рассылка писем', 'Рассыка успешно завершена')
            else:
                QMessageBox.information(self, 'Рассылка писем',
                                        'Рассыка завершена.' + '\n' + 'На следующие адреса не удалось отправить письмо:' + '\n' + '\n'.join(sorted(not_send)))
            if self.progressBar.value() <= 100:
                self.progressBar.setValue(100)
            self.label_4.setText('Вложения:')
            self.label_4.hide()
            self.comboBox.hide()
            self.pushButton.hide()
            self.progressBar.setValue(0)
            self.personal = False
            self.progressBar.hide()
            self.lineEdit.setText('')
            self.plainTextEdit.setPlainText('')
            self.files = []
            self.listWidget.clear()
            self.setDisabled(False)
            self.pushButton_2.setDisabled(False)
            self.pushButton_3.setChecked(False)
            self.pushButton_3.setDisabled(False)
            self.setFixedSize(470, 485)
            self.progressBar.setStyleSheet('background-color: rgb(224, 235, 250);'
                                    'border-color: rgb(18, 18, 18);'
                                    'color: rgb(0, 189, 244);'
                                    'font: bold 12pt "Arial";')
            self.close()

    def getters(self):
        self.listWidget.clear()
        self.listWidget.addItems(sorted(self.names))

    def addfile(self):
        if self.flag:
            if len(self.files) == 4:
                QMessageBox.critical(self, 'Добавление файла',
                                     'Нельзя отправить более 5 вложений в одном письме')
                return

        if len(self.files) == 5:
            QMessageBox.critical(self, 'Добавление файла',
                                 'Нельзя отправить более 5 вложений в одном письме')
            return
        fname, razr = QFileDialog.getOpenFileName(
            self, 'Добавить файл', '',
            'Все файлы (*)')
        if not fname:
            return
        self.files.append(fname)
        self.comboBox.clear()
        a = []
        if self.flag:
            a.append('Перс...ное')
        a.extend(sorted([os.path.basename(i) for i in self.files]))
        for i in range(len(a)):
            if len(a[i]) > 9 and a[i] != 'Документ, созданный по шаблону':
                a[i] = a[i][:4] + '..' + a[i][-3:]
        self.comboBox.addItems(a)
        self.comboBox.show()
        self.pushButton.show()
        self.label_4.show()

    def closeEvent(self, event):
        self.comboBox.clear()
        self.files = []
        self.plainTextEdit.setPlainText('')
        self.lineEdit.setText('')
        self.obj.setDisabled(False)
        a = self.obj.table.findChildren(QCheckBox)
        for i in range(len(a)):
            a[i].setDisabled(False)
        self.obj.dischcekoxes = False
        if self.flag:
            self.flag = False
            self.docx.close()
            self.docx.destroy()
        self.docx.text.setPlainText('')
        self.docx.boldAction.setChecked(False)
        self.docx.italicAction.setChecked(False)
        self.docx.underlAction.setChecked(False)
        self.docx.strikeAction.setChecked(False)

        self.close()

    def delet_last(self):
        self.pushButton_3.setDisabled(False)
        if self.comboBox.currentText() == 'Перс...ное':
            msg = QMessageBox(self)
            msg.setWindowTitle('Рассылка')
            msg.setText(
                f'Вы действтельно хотите удалить документы, созданные по шаблону?')

            play = msg.addButton(
                'Да', QMessageBox.AcceptRole)
            change = msg.addButton(
                'Нет', QMessageBox.AcceptRole)
            msg.setIcon(QMessageBox.Question)
            msg.setDefaultButton(play)
            msg.exec_()
            msg.deleteLater()
            if msg.clickedButton() is play:
                self.flag = False
                self.pushButton_2.disconnect()
                self.pushButton_2.clicked.connect(self.send_mail)
            else:
                return
        if self.files:
            self.files = self.files[:-1]
        if self.files:
            self.comboBox.clear()
            a = sorted([os.path.basename(i) for i in self.files])
            for i in range(len(a)):
                if len(a[i]) > 9:
                    a[i] = a[i][:4] + '..' + a[i][-3:]
            if self.flag:
                a.insert(0, 'Перс...ное')
            self.comboBox.addItems(a)
        else:
            self.flag = False
            self.comboBox.clear()
            self.comboBox.hide()
            self.pushButton.hide()
            self.label_4.hide()


class Back(QMainWindow, Backui):
    def __init__(self, obj, email, account):
        super().__init__()
        self.setWindowIcon(QIcon('icons\icon.png'))
        self.email = email
        self.setFixedSize(550, 355)
        self.account = account
        self.setupUi(self)
        self.setWindowTitle('Обратная связь')
        self.obj = obj
        self.pushButton.hide()
        self.comboBox_2.hide()
        self.label_4.hide()
        self.files = []
        self.pushButton_3.clicked.connect(self.addfile)
        self.pushButton.clicked.connect(self.delet_last)
        self.comboBox.currentTextChanged.connect(self.label_state)
        self.pushButton_2.clicked.connect(self.send_mail)

    def label_state(self):
        if self.comboBox.currentText() == 'Идея для улучшения':
            self.label_2.setText('Пожалуйста, опишите Вашу идею:')
        if self.comboBox.currentText() == 'Отзыв о программе':
            self.label_2.setText(
                'Пожалуйста, оставьте Ваш отзыв:')
            #self.label_2.setText('Пожалуйста, опишите ошибку как можно подробнее:')
        if self.comboBox.currentText() == 'Сообщение об ошибке':
            self.label_2.setText(
                'Пожалуйста, опишите ошибку как можно подробнее:')
        #print(self.comboBox.currentText())

    def send_mail(self):
        tema = self.comboBox.currentText()
        text = (self.plainTextEdit.toPlainText().strip('\n')).strip()

        if not text:
            return
        self.setDisabled(True)
        for email in ['nicolaynemov@mail.ru']:
            message = MIMEMultipart()
            message["Subject"] = str(tema)
            message["From"] = 'shifrovalshchik@list.ru'
            body = f'от: {self.account}' + '\n' + f'email: {self.email}' + '\n' + 'Текст:\n' + text
            for filepath in self.files:
                ctype, encoding = mimetypes.guess_type(
                    filepath)  # Определяем тип файла на основе его расширения
                if ctype is None or encoding is not None:  # Если тип файла не определяется
                    ctype = 'application/octet-stream'  # Будем использовать общий тип
                maintype, subtype = ctype.split('/',
                                                1)  # Получаем тип и подтип
                with open(filepath, 'rb') as fp:
                    file = MIMEBase(maintype,
                                    subtype)  # Используем общий MIME-тип
                    file.set_payload(
                        fp.read())  # Добавляем содержимое общего типа (полезную нагрузку)
                    fp.close()
                encoders.encode_base64(
                    file)  # Содержимое должно кодироваться как Base64
                file.add_header('Content-Disposition', 'attachment',
                                filename=os.path.basename(
                                    filepath))  # Добавляем заголовки
                message.attach(file)
            message.attach(MIMEText('', 'plain'))
            d = {'Идея для улучшения': 'идею', 'Отзыв о программе': 'отзыв',
                 'Сообщение об ошибке': 'собщение об ошибке'}
            try:
                if self.files:
                    server = smtplib.SMTP_SSL("smtp.mail.ru", 465)
                    server.login(message["From"], "Zxoiet123")
                    server.sendmail(message["From"], email, message.as_string())
                else:
                    a = stuff_mail(tema, text, email)
                    if not a[0]:
                        QMessageBox.critical(self, 'Обратная связь',
                                             f'Не удалось отправить {d[tema]}.' + '\n' + 'Проверьте подключение к интернету')
                        self.label_4.setText('Вложения:')
                        self.label_4.hide()
                        self.comboBox_2.hide()
                        self.pushButton.hide()
                        self.plainTextEdit.setPlainText('')
                        self.files = []
                        self.setDisabled(False)
                        self.destroy()
                        return
                if tema == 'Идея для улучшения':
                    QMessageBox.information(self, 'Обратная связь',
                                            f"{'Идея'} успешно отправлена")
                elif tema == 'Отзыв о программе':
                    QMessageBox.information(self, 'Обратная связь',
                                            f"{'Отзыв'} успешно отправлен")
                else:
                    QMessageBox.information(self, 'Обратная связь',
                                            f"{'Сообщение об ошибке'} успешно отправлено")
            except Exception as e:
                print(e.args)
                QMessageBox.critical(self, 'Обратная связь', f'Не удалось отправить {d[tema]}.' + '\n' + 'Проверьте подключение к интернету')
        self.label_4.setText('Вложения:')
        self.label_4.hide()
        self.comboBox_2.hide()
        self.pushButton.hide()
        self.plainTextEdit.setPlainText('')
        self.files = []
        self.setDisabled(False)
        self.destroy()


    def addfile(self):
        if len(self.files) == 5:
            QMessageBox.critical(self, 'Добавление файла',
                                 'Нельзя отправить более 5 вложений')
            return
        fname, razr = QFileDialog.getOpenFileName(
            self, 'Добавить файл', '',
            'Все файлы (*)')
        if not fname:
            return
        self.files.append(fname)
        self.comboBox_2.clear()
        a = sorted([os.path.basename(i) for i in self.files])
        for i in range(len(a)):
            if len(a[i]) > 9:
                a[i] = a[i][:4] + '..' + a[i][-3:]
        self.comboBox_2.addItems(a)
        self.comboBox_2.show()
        self.pushButton.show()
        self.label_4.show()

    def update_theme(self, children, name, color_theme, size):
        a = (self.plainTextEdit.font())
        self.plainTextEdit.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Windows']['background-color']}color: {self.obj.color.color_theme['PlainTextEdits']['color']}")
        self.plainTextEdit.setFont(a)

        a = self.pushButton.font()
        self.pushButton.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Buttons']['background-color']}color: {self.obj.color.color_theme['Buttons']['color']}")
        self.pushButton.setFont(a)

        a = self.pushButton_2.font()
        self.pushButton_2.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Buttons']['background-color']}color: {self.obj.color.color_theme['Buttons']['color']}")
        self.pushButton_2.setFont(a)

        a = self.label.font()
        self.label.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Labels']['background-color']}color: {self.obj.color.color_theme['Labels']['color']}")
        self.label.setFont(a)

        a = self.label_2.font()
        self.label_2.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Labels']['background-color']}color: {self.obj.color.color_theme['Labels']['color']}")
        self.label_2.setFont(a)

        a = self.label_4.font()
        self.label_4.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Labels']['background-color']}color: {self.obj.color.color_theme['Labels']['color']}")
        self.label_4.setFont(a)

        a = self.pushButton_3.font()
        self.pushButton_3.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Buttons']['background-color']}color: {self.obj.color.color_theme['Buttons']['color']}")
        self.pushButton_3.setFont(a)

        self.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Windows']['background-color']}color: {self.obj.color.color_theme['Windows']['color']}")
        self.pushButton.setFont(a)

        a = self.comboBox.font()
        self.comboBox.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Windows']['background-color']}color: {self.obj.color.color_theme['Windows']['color']}")
        self.comboBox.setFont(a)

        a = self.comboBox_2.font()
        self.comboBox_2.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Windows']['background-color']}color: {self.obj.color.color_theme['Windows']['color']}")
        self.comboBox_2.setFont(a)

    def delet_last(self):
        if self.files:
            self.files = self.files[:-1]
        if self.files:
            self.comboBox_2.clear()
            a = sorted([os.path.basename(i) for i in self.files])
            for i in range(len(a)):
                if len(a[i]) > 9:
                    a[i] = a[i][:4] + '..' + a[i][-3:]
            self.comboBox_2.addItems(a)
        else:
            self.comboBox_2.clear()
            self.comboBox_2.hide()
            self.pushButton.hide()
            self.label_4.hide()

class Big(QMainWindow, Bigui):
    def __init__(self, obj):
        super().__init__()
        self.setupUi(self)
        self.setWindowIcon(QIcon('icons\icon.png'))
        self.obj = obj
        self.setFixedSize(950, 630)
        self.setWindowTitle('Общая информация')
        self.pushButton.clicked.connect(self.ok)
        self.plainTextEdit.setReadOnly(True)

    def ok(self):
        self.destroy()

    def update_theme(self, children, name, color_theme, size):
        a = (self.plainTextEdit.font())
        self.plainTextEdit.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Windows']['background-color']}color: {self.obj.color.color_theme['PlainTextEdits']['color']}")
        self.plainTextEdit.setFont(a)

        a = self.pushButton.font()
        self.pushButton.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Buttons']['background-color']}color: {self.obj.color.color_theme['Buttons']['color']}")
        self.pushButton.setFont(a)
        s = self.font()
        self.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Windows']['background-color']}color: {self.obj.color.color_theme['Windows']['color']}")
        self.pushButton.setFont(a)

class Allpro(QMainWindow, Allproui):
    def __init__(self, obj):
        super().__init__()
        self.setWindowIcon(QIcon('icons\icon.png'))
        self.setupUi(self)
        self.obj = obj
        self.setFixedSize(361, 140)
        self.setWindowTitle('Общая информация')
        self.pushButton.clicked.connect(self.ok)
        self.plainTextEdit.setReadOnly(True)

    def ok(self):
        self.destroy()

    def update_theme(self, children, name, color_theme, size):
        a = (self.plainTextEdit.font())
        self.plainTextEdit.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Windows']['background-color']}color: {self.obj.color.color_theme['PlainTextEdits']['color']}")
        self.plainTextEdit.setFont(a)

        a = self.pushButton.font()
        self.pushButton.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Buttons']['background-color']}color: {self.obj.color.color_theme['Buttons']['color']}")
        self.pushButton.setFont(a)
        s = self.font()
        self.setStyleSheet(
            f"background-color: {self.obj.color.color_theme['Windows']['background-color']}color: {self.obj.color.color_theme['Windows']['color']}")
        self.pushButton.setFont(a)

def srname(object, reverse=False):
    objects = [(i[1].lower(), i) for i in object]
    objects.sort(key=lambda x: x[0])
    objects = [i[1] for i in objects]
    if reverse:
         objects = objects[::-1]
    return objects

def byname(object, reverse=False):
    objects = [(i[0].lower(), i) for i in object]
    objects.sort(key=lambda x: x[0])
    objects = [i[1] for i in objects]
    if reverse:
         objects = objects[::-1]
    return objects

def date(object, reverse=False):
    objects = [(str(i[2]).lower(), i) for i in object]
    objects.sort(key=lambda x: x)
    objects = [i[1] for i in objects]
    if reverse:
         objects = objects[::-1]
    return objects


def male(object, reverse=False, revers2=False):
    objects = [(i[3].lower(), i) for i in object]
    objects.sort(key=lambda x: 'ж' == x[0][0].lower())
    objects = [i[1] for i in objects]
    if reverse:
         objects = objects[::-1]
    if revers2:
        objects = objects[::-1]
    return objects


class Window(QMainWindow, MainWindowui):
    def __init__(self):
        super().__init__()
        self.b = Big(self)
        self.b.hide()
        self.ap = Allpro(self)
        self.ap.hide()
        self.back = Back(self, '', '')
        self.back.hide()
        self.file = ''
        self.dischcekoxes = False
        self.flag3 = True

        self.emails = []
        self.password = ''
        self.modified = []
        self.CONST = 0
        self.already = set()
        self.email = 'None'
        self.classes = {}  # доступные классы
        self.searchdatas = {}
        self.setupUi(self)
        # self.table.itemChanged.connect(self.item_changed)
        self.paint = Paint()
        self.paint.hide()
        self.su = Send(self, [])
        self.su.hide()
        self.exp = Exploring(self.file, self.password, self)
        self.exp.hide()
        self.account_worker = Account('None', 'None', 'None', 'None', 'None', 'None', self, self)
        self.account_worker.hide()
        self.continue_2.clicked.connect(self.se)
        self.zametki = ZM(self.file, self)
        self.zametki.hide()
        self.napominania = Napominanie(self.email, self.file, self)
        self.napominania.hide()
        self.slk = Slk(self.file, self)
        self.slk.hide()
        self.color = Colors(self.file, self)
        self.color.hide()
        self.getname('None')
        self.time = QTimer(self)
        self.time.setInterval(1)
        self.time.timeout.connect(self.show_time)
        self.time.start()
        self.minipaint.clicked.connect(self.openpaint)
        self.mesh.clicked.connect(self.MESH)
        self.pushButton.clicked.connect(self.go_out)
        self.napadd.clicked.connect(self.addnap)
        self.zapshow.clicked.connect(self.addnote)
        self.sladd.clicked.connect(self.addsl)
        self.uchlookedit.textChanged[str].connect(self.showresults)
        self.allok.clicked.connect(self.cbc)
        self.setWindowIcon(QIcon('icons\icon.png'))
        self.reversebox.clicked.connect(self.setclasscombo)
        self.choicesort.currentTextChanged.connect(self.setclasscombo)
        self.choiceclass.currentTextChanged.connect(self.setclasscombo)
        self.calc.clicked.connect(self.calculator)
        header = self.table.horizontalHeader()
        header.setStretchLastSection(True)
        classes = self.menubar.addAction('Классы')
        classes.triggered.connect(self.update)
        self.menu = QtWidgets.QMenu(self.menubar)
        self.menu.setObjectName("menu")
        account = QtWidgets.QAction(self)
        account.setObjectName("account")
        account.setText('Аккаунт')
        self.menu.addAction(account)
        account.triggered.connect(self.updating_and_changing)
        color = QtWidgets.QAction(self)
        color.setObjectName("color")
        color.setText('Внешний вид')
        color.triggered.connect(self.color_show)
        self.menu.addAction(color)
        self.menubar.addAction(self.menu.menuAction())
        self.menu.setTitle('Настройки')

        self.menu2 = QtWidgets.QMenu(self.menubar)
        self.menu2.setObjectName("menu2")
        pro = QtWidgets.QAction(self)
        pro.setObjectName("pro")
        pro.setText('Общая информация')
        self.menu2.addAction(pro)
        pro.triggered.connect(self.propro)
        gen = QtWidgets.QAction(self)
        gen.setObjectName("gen")
        gen.setText('Помощь в работе')
        gen.triggered.connect(self.prohelp)
        self.menu2.addAction(gen)
        self.menubar.addAction(self.menu2.menuAction())
        self.menu2.setTitle('О программе')
        back = QtWidgets.QAction(self)
        back.setObjectName("back")
        back.setText('Обратная связь')
        back.triggered.connect(self.problem)
        self.menu2.addAction(back)
        self.menubar.addAction(self.menu2.menuAction())



        #about.triggered.connect(self.update)

    def problem(self):
        self.back.show()
    def update_theme(self, children, name, color_theme, size):
        self.size = size
        if name == 'Windows':
            stl = ''
            for i in color_theme['Windows']:
                stl += i + ': ' + color_theme['Windows'][i]
            children.setStyleSheet(stl)
            return
        a = self.findChildren(children)
        for i in range(len(a)):
            b = a[i].styleSheet()
            b = [j.strip('\n') for j in b.split(';') if j.strip('\n')]
            d = {}
            for j in b:
                try:
                    if j.split(':')[0] not in d:
                        d[j.split(':')[0]] = j.split(':')[1]
                except Exception:
                    return

            d['background-color'] = color_theme[name]['background-color']
            if name == 'LineEdits':
                d['color'] = 'rgb(81, 81, 255);'
            else:
                d['color'] = color_theme[name]['color']
            styles = ''
            if self.color.radioButton_7.isChecked():
                font = 'Arial'
            else:
                font = color_theme['Windows']['font'].split()[2:]
                font[0] = font[0][1:]
                font[-1] = font[-1][:-2]
                font = ' '.join(font)
            if 'font' in d:
                if 'bold' in d['font']:
                    d['font'] = (f'''bold {size[int((d['font'].split())[1][:-2])]}pt "{font}";''')
                else:
                    d['font'] = (
                        f'''bold {size[int((d['font'].split())[0][:-2])]}pt "{font}";''')
            for t in d:
                styles += (t + ':' + d[t] + ';' + '\n')
            a[i].setStyleSheet(styles)


    def color_show(self):
        self.color.update()
        self.color.show()

    def update(self):
        self.exp.get_datas()
        self.exp.show()

    def updating_and_changing(self, *arg):
        self.account_worker.nick = self.name
        self.account_worker.email = self.email
        self.account_worker.password = self.password
        for i in self.color.name:
            self.exp.update_theme(i[0], i[1], self.color.color_theme, self.color.work_dict)
            #self.exp.update_theme(i[0], i[1], self.color.color_theme, self.color.work_dict)
        if not arg[0]:
            a = get_accounts()
            self.account_worker.nicks = a['account']
            self.account_worker.emails = a['email']
            self.account_worker.passwords = a['password']
            self.account_worker.help_update()
            self.account_worker.show()

    def show_time(self):
        d_f = ('%H:%M')
        time1 = datetime.datetime.today().strftime(d_f)
        #self.lcdNumber.setStyleSheet()
        self.lcdNumber.display(str(time1))
        self.time = QTimer(self)

    def se(self):
        checkboxes = self.table.findChildren(QCheckBox)
        rc = []
        getters = []
        datas = []
        name_emails = []
        for i in range(len(checkboxes)):
            if checkboxes[i].isChecked():
                rc.append(self.table.item(i, 5).text())
                getters.append(self.table.item(i, 1).text() +' ' + self.table.item(i, 2).text())
                name_emails.append({self.table.item(i, 1).text() +' ' + self.table.item(i, 2).text(): self.table.item(i, 5).text()})
                b = []
                for j in range(1, 8):
                    b.append(self.table.item(i, j).text())
                datas.append(b)
        if not rc:
            return
        self.su.emails = rc
        self.su.names = getters
        a = (self.su.font())
        self.su.plainTextEdit.setStyleSheet(f"background-color: {self.color.color_theme['Windows']['background-color']}color: {self.color.color_theme['PlainTextEdits']['color']}")
        self.su.listWidget.setStyleSheet(f"background-color: {self.color.color_theme['Windows']['background-color']}color: {self.color.color_theme['PlainTextEdits']['color']}")
        self.su.name_email = name_emails
        self.su.setFont(a)
        self.su.getters()
        self.setDisabled(True)
        a = self.table.findChildren(QCheckBox)
        for i in range(len(a)):
            a[i].setDisabled(True)
        self.dischcekoxes = True
        self.su.datas = datas
        try:
            self.su.pushButton_2.disconnect()
            self.su.pushButton_2.clicked.connect(self.su.send_mail)
        except Exception as e:
            print(e.args)

        self.su.show()

    def cbc(self):
        checkboxes = self.table.findChildren(QCheckBox)
        for item in checkboxes:
            item.setChecked(self.allok.isChecked())
            item.clicked.connect(self.cbc_update)
        self.flag3 = True
        return

    def cbc_update(self):
        checkboxes = self.table.findChildren(QCheckBox)
        if all([i.isChecked() for i in checkboxes]):
            self.flag3 = False
            self.allok.setChecked(True)
            return
        for item in checkboxes:
            if item.isChecked() != self.allok.isChecked():
                self.flag3 = False
                self.allok.setChecked(False)
                return

    def every_item(self):
        pass

    def showresults(self):
        a = self.choiceclass.currentText()
        if a:
            ## работа с БД
            self.con = sqlite3.connect(self.file)
            cur = self.con.cursor()
            vals = cur.execute("""SELECT * FROM '{}'""".format(self.choiceclass.currentText())).fetchall()
            self.con.close()
            ## конец аботы с БД
        else:
            self.table.setRowCount(0)
            return
        search_datas = [''.join([str(j) for j in i]).lower() for i in vals]
        look_data = self.uchlookedit.text().lower()
        correct_index = []
        for i in range(len(search_datas)):
            if look_data in search_datas[i]:
                correct_index.append(i)
        vals = [vals[i] for i in correct_index]
        if self.choicesort.currentText().lower() =='фамилии':
            vals = srname(vals, self.reversebox.isChecked())
        elif self.choicesort.currentText().lower() =='имени':
            vals = byname(vals, self.reversebox.isChecked())
        elif self.choicesort.currentText().lower() =='полу (мальчики)':
            vals = male(vals, self.reversebox.isChecked(), False)
        elif self.choicesort.currentText().lower() =='полу (девочки)':
            vals = male(vals, self.reversebox.isChecked(), True)

        elif self.choicesort.currentText().lower() =='дате рождения':
            vals = date(vals, self.reversebox.isChecked())


        self.table.setRowCount(len(vals))

        for i in range(len(vals)):
            for j in range(7):
                locals().update({f'c_b{i + 1}': QCheckBox(self)})
                locals().get(f'c_b{i + 1}').setChecked(
                    self.allok.isChecked())
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                cell_widget = QWidget()
                lay_out = QHBoxLayout(cell_widget)
                lay_out.addWidget(locals().get(f'c_b{i + 1}'))
                lay_out.setAlignment(Qt.AlignCenter)
                lay_out.setContentsMargins(0, 0, 0, 0)
                cell_widget.setLayout(lay_out)
                cell_widget.installEventFilter(self)
                self.table.setCellWidget(i, 0, cell_widget)
                self.table.setItem(i, j + 1, QTableWidgetItem(str(vals[i][j])))

    def addclass(self, vals, name):  # добавить класс

        self.choiceclass.clear()
        ## работа с БД
        self.con = sqlite3.connect(self.file)
        cur = self.con.cursor()
        self.choiceclass.addItems(sorted([i[0] for i in cur.execute("""SELECT * FROM classes""").fetchall()]))
        self.choiceclass.setCurrentText(name)
        self.su.docx.clas = name
        self.con.close()
        ## конец аботы с БД
        #sorted(list(set([i[0] for i in cur.execute('SELECT name from sqlite_master where type= "table"').fetchall()]) - {'napominaniya', 'zametki', 'settings', 'slk', 'classes'}))
        if self.choicesort.currentText().lower() == 'фамилии':
            vals = srname(vals, self.reversebox.isChecked())
        elif self.choicesort.currentText().lower() =='имени':
            vals = byname(vals, self.reversebox.isChecked())
        elif self.choicesort.currentText().lower() =='полу (мальчики)':
            vals = male(vals, self.reversebox.isChecked(), False)
        elif self.choicesort.currentText().lower() =='полу (девочки)':
            vals = male(vals, self.reversebox.isChecked(), True)
        elif self.choicesort.currentText().lower() =='дате рождения':
            vals = date(vals, self.reversebox.isChecked())

        self.table.setRowCount(len(vals))
        self.emails = []

        for i in range(len(vals)):
            for j in range(7):
                locals().update({f'c_b{i + 1}': QCheckBox(self)})
                locals().get(f'c_b{i + 1}').setChecked(
                    self.allok.isChecked())
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                cell_widget = QWidget()
                lay_out = QHBoxLayout(cell_widget)
                lay_out.addWidget(locals().get(f'c_b{i + 1}'))
                lay_out.setAlignment(Qt.AlignCenter)
                lay_out.setContentsMargins(0, 0, 0, 0)
                cell_widget.setLayout(lay_out)
                cell_widget.installEventFilter(self)
                self.table.setCellWidget(i, 0, cell_widget)
                if j == 4:
                    self.emails.append(vals[i][j])
                self.table.setItem(i, j + 1, QTableWidgetItem(str(vals[i][j])))
        self.uchlookedit.setDisabled(False)
        self.reversebox.setDisabled(False)
        self.allok.setDisabled(False)
        self.continue_2.setDisabled(False)
        self.choicesort.setDisabled(False)
        self.choiceclass.setDisabled(False)


    def setclasscombo(self):
        ## работа с БД
        self.con = sqlite3.connect(self.file)
        cur = self.con.cursor()
        a = sorted([i[0] for i in cur.execute("""SELECT * FROM classes""").fetchall()])
        self.con.close()
        ## конец аботы с БД
        self.choiceclass.blockSignals(True)
        self.choiceclass.clear()
        self.choiceclass.addItems(a)
        a = self.choiceclass.currentText()
        self.su.docx.clas = a

        if a:
            ## работа с БД
            self.con = sqlite3.connect(self.file)
            cur = self.con.cursor()
            vals = cur.execute("""SELECT * FROM '{}'""".format(self.choiceclass.currentText())).fetchall()
            self.con.close()
            ## конец аботы с БД
        else:
            self.table.setRowCount(0)
            self.uchlookedit.setText('')
            self.reversebox.setChecked(False)
            self.allok.setChecked(False)
            self.uchlookedit.setDisabled(True)
            self.reversebox.setDisabled(True)
            self.allok.setDisabled(True)
            self.continue_2.setDisabled(True)
            self.choicesort.setDisabled(True)
            self.choiceclass.setDisabled(True)
            return
        if self.choicesort.currentText().lower() == 'фамилии':
            vals = srname(vals, self.reversebox.isChecked())
        elif self.choicesort.currentText().lower() =='имени':
            vals = byname(vals, self.reversebox.isChecked())
        elif self.choicesort.currentText().lower() =='полу (мальчики)':
            vals = male(vals, self.reversebox.isChecked(), False)
        elif self.choicesort.currentText().lower() =='полу (девочки)':
            vals = male(vals, self.reversebox.isChecked(), True)
        elif self.choicesort.currentText().lower() =='дате рождения':
            vals = date(vals, self.reversebox.isChecked())

        self.table.setRowCount(len(vals))
        self.emails = []
        for i in range(len(vals)):
            for j in range(7):
                locals().update({f'c_b{i + 1}': QCheckBox(self)})
                locals().get(f'c_b{i + 1}').setChecked(
                    self.allok.isChecked())
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                locals().get(f'c_b{i + 1}').clicked.connect(
                    self.cbc_update)
                cell_widget = QWidget()
                lay_out = QHBoxLayout(cell_widget)
                lay_out.addWidget(locals().get(f'c_b{i + 1}'))
                lay_out.setAlignment(Qt.AlignCenter)
                lay_out.setContentsMargins(0, 0, 0, 0)
                cell_widget.setLayout(lay_out)
                cell_widget.installEventFilter(self)
                self.table.setCellWidget(i, 0, cell_widget)
                if j == 4:
                    self.emails.append(vals[i][j])
                self.table.setItem(i, j + 1, QTableWidgetItem(str(vals[i][j])))





    def eventFilter(self, obj, e):
        if self.dischcekoxes:
            pass
        else:
            if e.type() == 2:
                obj.children()[1].setChecked(not obj.children()[1].isChecked())
                self.cbc_update()
        return super(QMainWindow, self).eventFilter(obj, e)

    def ecsport(self):  # экспортировать
        print('експорт')

    def changeclass(self):  # изменить
        print('cc')

    def declass(self):  # удалить класс
        print('dc')

    def addsl(self):  # добавить ссылку
        self.slk.show()

    def addnap(self):  # добавить напоминание
        self.napominania.show()

    def addnote(self):  # добавить запись
        self.zametki.show()

    def seezam(self):  # посмотреть все заметки
        print('sz')

    def check_cb(self):
        print('done')

    def addfile(self):  # добавить файл
        fname, razr = QFileDialog.getOpenFileName(
            self, 'Добавить файл', '',
            'Все файлы (*)')
        if not fname:
            return
        name, ok_pressed = QInputDialog.getText(self, "Имя файла",
                                                "Введите название файла")
        if not os.path.isdir('Files'):
            os.mkdir('Files')
        os.chdir('Files')
        while not ok_pressed or name in self.classes or os.path.isfile(
                f"{name}.{fname.split('.')[-1]}"):
            country, ok_pressed2 = QInputDialog.getItem(
                self, "Вы не ввели название",
                "Вы не ввели название файла или оно уже занято. Что сделать?",
                ('Ввести имя файла', 'Отменить добавление'), 1, False)
            while not ok_pressed2:
                country, ok_pressed2 = QInputDialog.getItem(
                    self, "Вы не ввели имя файла",
                    "Вы не ввели название файла. Что сделать?",
                    ('Ввести имя файла', 'Отменить добавление'), 1, False)
            if country == 'Ввести имя файла':
                name, ok_pressed = QInputDialog.getText(self, "Имя файла",
                                                        "Введите название файла")
            else:
                return
        shutil.copyfile(f"{fname}", f"{name}.{fname.split('.')[-1]}")
        os.chdir('..')

    def seefiles(self):  # посмотреть все файлы
        print('sf')

    def addtextfile(self):  # добавить текстовый файл
        print('atx')

    def addshablon(self):  # добавить шаблон документа word
        print('awshf')

    def addwordfile(self):  # добавить документ word
        print('aw')

    def setcolor(self):  # изменить цвет
        print('sc')

    def setaccount(self):  # мой аккаунт
        print('sacc')

    def setfont(self):  # изменить шрифт
        print('setfont')

    def setozer(self):  # прочее
        print('setozer')

    def prodinar(self):  # общая информация
        self.ap.show()

    def prohelp(self):  # помощь в работе
        self.b.show()

    def propro(self):  # сообщить о проблеме
        self.ap.show()

    def getname(self, name, email='None', password=''):
        self.name = name
        self.email = email
        self.password = password
        self.exp.password = self.password
        self.file = self.name + '.sqlite3'
        self.napominania.email = email
        self.napominania.file = self.file
        self.zametki.file = self.file
        self.slk.file = self.file
        self.exp.file = self.file
        self.color.file = self.file
        self.back.email = email
        self.back.account = name

    def closeEvent(self, evnt):
        self.hide()
        self.su.close()
        self.su.destroy()
        self.b.close()
        self.b.destroy()
        self.ap.close()
        self.ap.destroy()
        self.color.close()
        self.color.destroy()
        self.napominania.close()
        self.napominania.destroy()
        self.zametki.close()
        self.zametki.destroy()
        self.back.close()
        self.back.destroy()
        self.slk.close()
        self.slk.destroy()
        self.paint.close()
        self.paint.destroy()
        try:
            self.exp.destroy()
            self.exp.close()
        except Exception:
            pass
        try:
            self.account_worker.destroy()
            self.account_worker.close()
        except Exception:
            pass
        try:
            socket.gethostbyaddr("www.yandex.ru")
        except Exception:
            QMessageBox.critical(self, 'Обновление',
                                 'Невозможно загрузить дванные. Проверьте подключение к интернету.')
            sys.exit()
        self.destroy()
        delete_file(self.file)
        add_file(self.file)
        file = pathlib.Path(self.file)
        file.unlink()
        sys.exit()

    def calculator(self):
        try:
            os.system('calc.exe')
        except Exception:
            QMessageBox.critical(self, 'Калькулятор', 'Данная функция недоступна на Вашей операционной системе')

    def openpaint(self):
        self.paint.show()

    def calc(self):
        os.startfile('calc.exe')

    def new_button_color(self, buttons, color):
        buttons = self.findChildren(QPushButton)
        for i in buttons:
            i.setStyleSheet("background-color: rgb(224, 235, 250);")
        buttons = self.napominania.findChildren(QPushButton)
        for i in buttons:
            i.setStyleSheet("background-color: rgb(224, 235, 250);")
        buttons = self.zametki.findChildren(QPushButton)
        for i in buttons:
            i.setStyleSheet("background-color: rgb(224, 235, 250);")
        buttons = self.slk.findChildren(QPushButton)
        for i in buttons:
            i.setStyleSheet("background-color: rgb(224, 235, 250);")
        buttons = self.su.findChildren(QPushButton)
        for i in buttons:
            i.setStyleSheet("background-color: rgb(224, 235, 250);")

    def MESH(self):
        webbrowser.open('https://dnevnik.mos.ru/', new=0, autoraise=True)

    def go_out(self):
        self.hide()
        self.su.close()
        self.su.destroy()
        self.b.close()
        self.b.destroy()
        self.ap.close()
        self.ap.destroy()
        self.color.close()
        self.color.destroy()
        self.napominania.close()
        self.napominania.destroy()
        self.zametki.close()
        self.zametki.destroy()
        self.back.close()
        self.back.destroy()
        self.slk.close()
        self.slk.destroy()
        self.paint.close()
        self.paint.destroy()
        try:
            self.exp.destroy()
            self.exp.close()
        except Exception:
            pass
        try:
            self.account_worker.destroy()
            self.account_worker.close()
        except Exception:
            pass
        try:
            socket.gethostbyaddr("www.yandex.ru")
        except Exception:
            QMessageBox.critical(self, 'Обновление',
                                 'Невозможно загрузить дванные. Проверьте подключение к интернету.')
            sys.exit()
        self.destroy()
        delete_file(self.file)
        add_file(self.file)
        file = pathlib.Path(self.file)
        file.unlink()
        self.auth = Autorisation(Window)
        self.auth.show()

if __name__ == '__main__':
    main(Window)
