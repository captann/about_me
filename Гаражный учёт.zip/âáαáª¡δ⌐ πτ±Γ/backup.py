import json
import vk_api
import sys
import time


def get_tokens() -> dict:
    import json
    with open('tables_tokens.json') as f:
        tokens = json.load(f)
    return tokens


def send(token: str, msg: str) -> tuple:
    try:
        vk_session = vk_api.VkApi(token=token)
        vk = vk_session.get_api()
        vk.messages.send(
            user_id=user_id,
            message=msg, random_id=0)
        return True, True
    except Exception as e:
        return False, str(e.args)


class Backup_functions:
    def __init__(self):
        pass

    def add_operation(self, operation):
        send(token=get_tokens()['operations'], msg=URS.join([str(i) for i in
                                                             [operation[
                                                                  'operation'],
                                                              operation[
                                                                  'user_id'],
                                                              operation[
                                                                  'is_deleted'],
                                                              operation[
                                                                  'period']]]))

    def add_post(self, post):
        send(token=get_tokens()['posts'], msg=URS.join([str(i) for i in
                                                        [post["post_id"],
                                                         post["operation"],
                                                         post["date"],
                                                         post["car_id"],
                                                         post["user_id"],
                                                         post["note"],
                                                         post["file_url"],
                                                         post["file_name"],
                                                         post["distance"],
                                                         post["is_deleted"]]]))

    def add_user(self, user):
        send(token=get_tokens()['users'], msg=URS.join([str(i) for i in
                                                        [user["id"],
                                                         user["name"],
                                                         user["email"],
                                                         user["password"],
                                                         user["time"]]]))

    def add_car(self, car):
        send(token=get_tokens()['cars'], msg=URS.join([str(i) for i in
                                                       [car['car_id'],
                                                        car['user_id'],
                                                        car['car_name'],
                                                        car['description'],
                                                        car['distance'],
                                                        car['is_deleted'],
                                                        car['number']]]))


print(
    "You have to clean with your hands VK DB. If you dont, the server will crash.")
time.sleep(5)
q = input("To submit backup, press capitalized Y... ")
if q != "Y":
    print("Cancelled.")
    sys.exit(0)
URS = "[+[X]-]"
vk = Backup_functions()



with open(input("Input the abs path where backup is /with extinction/... "), "r", encoding="utf-8") as f:
    data = json.load(f)
operations = data.get('operations')
users = data.get('users')
cars = data.get('cars')
posts = data.get('posts')

for operation in operations:
    vk.add_operation(operation)

for user in users:
    vk.add_user(user)
    user_id = user['id']
    u_cars = cars[user_id]
    u_posts = posts[user_id]
    for car in u_cars:
        vk.add_car(car)
    for post in u_posts:
        vk.add_post(post)
